# WatchNexus v2.6.0
./start.sh then http://localhost:8001
