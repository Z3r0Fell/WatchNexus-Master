# WatchNexus v2.6.0

## Requirements
- Python 3.9+ with venv support
- Linux: `sudo apt install python3 python3-venv python3-pip`

## Quick Start
```bash
./start.sh
```
Then open http://localhost:8001 in your browser.

## What's New
- OS-aware file browser (Linux/macOS/Windows)
- 5 Gadgets: Weather, Podcasts, Radio, Photos, Web Video
- Single-click folder navigation
