@echo off
cd /d "%~dp0server"
python --version >nul 2>&1 || (echo Python 3 required & pause & exit /b 1)
if not exist "venv" python -m venv venv
call venv\Scripts\activate.bat
pip install -r requirements.txt -q || (echo pip install failed & pause & exit /b 1)
echo Starting... http://localhost:8001
python server.py
