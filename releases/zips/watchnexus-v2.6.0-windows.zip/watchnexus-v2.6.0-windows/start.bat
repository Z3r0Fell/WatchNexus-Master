@echo off
cd /d "%~dp0server"

echo === WatchNexus v2.6.0 Setup ===

python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python 3 is required.
    echo Download from https://python.org
    pause
    exit /b 1
)

if not exist "venv" (
    echo Creating virtual environment...
    python -m venv venv
)

call venv\Scripts\activate.bat

echo Installing dependencies...
pip install -r requirements.txt --quiet
if errorlevel 1 (
    echo ERROR: Failed to install dependencies
    pause
    exit /b 1
)

echo.
echo ==========================================
echo   WatchNexus v2.6.0
echo   Starting server...
echo   Open http://localhost:8001 in browser
echo ==========================================
echo.

python server.py
pause
