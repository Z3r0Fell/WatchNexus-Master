#!/bin/bash
set -e  # Exit on error

cd "$(dirname "$0")/server"

echo "=== WatchNexus v2.6.0 Setup ==="

# Check Python
if ! command -v python3 &>/dev/null; then
    echo "ERROR: Python 3 is required."
    echo "Install with: sudo apt install python3 python3-venv python3-pip"
    exit 1
fi

# Create venv if needed
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

# Activate venv
source venv/bin/activate

# Install dependencies
echo "Installing dependencies..."
if ! pip install -r requirements.txt --quiet; then
    echo "ERROR: Failed to install dependencies"
    exit 1
fi

echo ""
echo "=========================================="
echo "  WatchNexus v2.6.0"
echo "  Starting server..."
echo "  Open http://localhost:8001 in browser"
echo "=========================================="
echo ""

python3 server.py
