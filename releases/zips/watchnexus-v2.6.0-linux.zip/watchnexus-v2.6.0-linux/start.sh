#!/bin/bash
set -e
cd "$(dirname "$0")/server"
echo "=== WatchNexus v2.6.0 ==="
command -v python3 &>/dev/null || { echo "Python 3 required"; exit 1; }
[ ! -d "venv" ] && python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt -q || { echo "pip install failed"; exit 1; }
echo "Starting... http://localhost:8001"
python3 server.py
