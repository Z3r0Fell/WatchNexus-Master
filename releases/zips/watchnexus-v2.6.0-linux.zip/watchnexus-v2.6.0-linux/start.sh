#!/bin/bash
cd "$(dirname "$0")/server"
command -v python3 &>/dev/null || { echo "Python 3 required"; exit 1; }
[ ! -d "venv" ] && python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt --quiet
echo "WatchNexus v2.6.0 - http://localhost:8001"
python3 server.py
