# WatchNexus v2.6.0
Run: ./start.sh then open http://localhost:8001
