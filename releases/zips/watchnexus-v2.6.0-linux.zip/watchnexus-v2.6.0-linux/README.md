# WatchNexus v2.6.0
Run: ./start.sh
Open: http://localhost:8001
