<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_GB" sourcelanguage="en_US">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>default</name>
    <message>
        <source>192.168.1.100:8096 or https://example.com/jellyfin</source>
        <translation>192.168.1.100:8096 or https://example.com/jellyfin</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <source>Connect to Server</source>
        <translation>Connect to Server</translation>
    </message>
    <message>
        <source>Ends at %1</source>
        <translation>Ends at %1</translation>
    </message>
    <message>
        <source>Enter Configuration</source>
        <translation>Enter Configuration</translation>
    </message>
    <message>
        <source>Favorite</source>
        <translation>Favourite</translation>
    </message>
    <message>
        <source>Loading...</source>
        <translation>Loading…</translation>
    </message>
    <message>
        <source>Login attempt failed.</source>
        <translation>Login attempt failed.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Options</translation>
    </message>
    <message>
        <source>Play</source>
        <translation>Play</translation>
    </message>
    <message>
        <source>Please sign in</source>
        <translation>Please sign in</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Search</translation>
    </message>
    <message>
        <source>Server not found, is it online?</source>
        <translation>Server not found, is it online?</translation>
    </message>
    <message>
        <source>Shuffle</source>
        <translation>Shuffle</translation>
    </message>
    <message>
        <source>Sign In</source>
        <translation>Sign In</translation>
    </message>
    <message>
        <source>Submit</source>
        <translation>Submit</translation>
    </message>
    <message>
        <source>Watched</source>
        <translation>Watched</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Change Server</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Sign Out</translation>
    </message>
    <message>
        <source>Add User</source>
        <translation>Add User</translation>
    </message>
    <message>
        <source>Profile</source>
        <translation>Profile</translation>
    </message>
    <message>
        <source>My Media</source>
        <translation>My Media</translation>
    </message>
    <message>
        <source>Continue Watching</source>
        <translation>Continue Watching</translation>
    </message>
    <message>
        <source>Next Up</source>
        <translation>Next Up</translation>
    </message>
    <message>
        <source>Latest in</source>
        <translation>Latest in</translation>
    </message>
    <message>
        <source>Home</source>
        <translation>Home</translation>
    </message>
    <message>
        <source>Enter a username</source>
        <translation>Enter a username</translation>
    </message>
    <message>
        <source>Enter a password</source>
        <translation>Enter a password</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Sort Order</source>
        <translation>Sort Order</translation>
    </message>
    <message>
        <source>Descending</source>
        <translation>Descending</translation>
    </message>
    <message>
        <source>Ascending</source>
        <translation>Ascending</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Password</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Username</translation>
    </message>
    <message>
        <source>Genres</source>
        <translation>Genres</translation>
    </message>
    <message>
        <source>Director</source>
        <translation>Director</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Server</source>
        <translation>Server</translation>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Error Retrieving Content</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Error During Playback</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>There was an error retrieving the data for this item from the server.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>An error was encountered while playing this item.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Loading Channel Data</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Error loading Channel Data</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Unable to load Channel Data from the server</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>This %1 contains no items</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Rating</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Critics Rating</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Date Added</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Date Played</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Parental Rating</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Play Count</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Release Date</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Runtime</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>View</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sort</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <source>today</source>
        <translation>today</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>yesterday</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>tomorrow</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sunday</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Monday</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Tuesday</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Wednesday</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Thursday</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Friday</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Saturday</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Started at</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Started</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Starts at</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Starts</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Ended at</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Ends at</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Repeat</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Channels</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV Guide</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Connecting to Server</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Not found</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>The requested content does not exist on the server</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Episodes</source>
        <translation>Episodes</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Save Credentials?</translation>
    </message>
    <message>
        <source>Go to episode</source>
        <translation>Go to episode</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Cancel Series Recording</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Enter the server name or IP address</source>
        <translation>Enter the server name or IP address</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>An error was encountered while playing this item. Server did not provide required transcoding data.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>Set Favourite</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>You can search for Titles, People, Live TV Channels and more</source>
        <translation>You can search for Titles, People, Live TV Channels and more</translation>
        <extracomment>Help text in search results</extracomment>
    </message>
    <message>
        <source>MPEG-2</source>
        <translation>MPEG-2</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Options for TV Shows.</source>
        <translation>Options for TV Shows.</translation>
        <extracomment>Description for TV Shows user settings.</extracomment>
    </message>
    <message>
        <source>Go directly to the episode list if a TV series has only one season.</source>
        <translation>If enabled, selecting a TV series with only one season will go straight to the episode list rather than the show details and season list.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Use generated splashscreen image as WatchNexus&apos;s home background. WatchNexus will need to be closed and reopened for change to take effect.</source>
        <translation>Use generated splashscreen image as WatchNexus&apos;s home background. WatchNexus will need to be closed and reopened for change to take effect.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Blur Unwatched Episodes</source>
        <translation>Blur Unwatched Episodes</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Age</source>
        <translation>Age</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Died</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Cancel Recording</translation>
    </message>
    <message>
        <source>Additional Parts</source>
        <translation>Additional Parts</translation>
        <extracomment>Additional parts of a video</extracomment>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation>Quick Connect</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>On Now</translation>
    </message>
    <message>
        <source>Extras</source>
        <translation>Extras</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Born</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Cast &amp; Crew</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Delete Saved</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>More Like This</translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>Press &apos;OK&apos; to Close</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Special Features</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Movies</translation>
    </message>
    <message>
        <source>Movies (Presentation)</source>
        <translation>Movies (Presentation)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>Movies (Grid)</source>
        <translation>Movies (Grid)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>TV Shows</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Record</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Record Series</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unknown</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Pick a WatchNexus server from the local network</source>
        <translation>Select an available WatchNexus server from your local network:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Playback</source>
        <translation>Playback</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Codec Support</source>
        <translation>Codec Support</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>MPEG-4</source>
        <translation>MPEG-4</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Support Direct Play of MPEG-4 content. This may need to be disabled for playback of DIVX encoded video files.</source>
        <translation>Support Direct Play of MPEG-4 content. This may need to be disabled for playback of DIVX encoded video files.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Disabled</translation>
    </message>
    <message>
        <source>User Interface</source>
        <translation>User Interface</translation>
        <extracomment>Title for User Interface section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Media Grid</source>
        <translation>Media Grid</translation>
        <extracomment>UI -&gt; Media Grid section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Item Count</source>
        <translation>Item Count</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Count in user setting screen.</extracomment>
    </message>
    <message>
        <source>Show item count in the library and index of selected item.</source>
        <translation>Show item count in the library and index of selected item.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>Set Watched</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>Go to series</source>
        <translation>Go to series</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Series Detail Page</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation>Go to season</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>%1 of %2</source>
        <translation>%1 of %2</translation>
        <extracomment>Item position and count. %1 = current item. %2 = total number of items</extracomment>
    </message>
    <message>
        <source>(Dialog will close automatically)</source>
        <translation>(Dialog will close automatically)</translation>
    </message>
    <message>
        <source>There was an error authenticating via Quick Connect.</source>
        <translation>There was an error authenticating via Quick Connect.</translation>
    </message>
    <message>
        <source>Networks</source>
        <translation>Networks</translation>
    </message>
    <message>
        <source>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</source>
        <translation>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Hide Taglines</source>
        <translation>Hide Taglines</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Hides tagline text on details pages.</source>
        <translation>Hides tagline text on details pages.</translation>
    </message>
    <message>
        <source>Skip Details for Single Seasons</source>
        <translation>Skip Details for Single Seasons</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Studios</source>
        <translation>Studios</translation>
    </message>
    <message>
        <source>Options that alter the design of WatchNexus.</source>
        <translation>Options that alter the design of WatchNexus.</translation>
        <extracomment>Description for Design Elements user settings.</extracomment>
    </message>
    <message>
        <source>Return to Top</source>
        <translation>Return to Top</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Blur images of unwatched episodes.</source>
        <translation>Blur images of unwatched episodes.</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>View Channel</translation>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>If no server is listed above, you may also enter the server URL manually:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Error Getting Playback Information</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Media Grid options.</source>
        <translation>Media Grid options.</translation>
    </message>
    <message>
        <source>Use voice remote to search</source>
        <translation>Use voice remote to search</translation>
        <extracomment>Help text in search voice text box</extracomment>
    </message>
    <message>
        <source>Here is your Quick Connect code:</source>
        <translation>Here is your Quick Connect code:</translation>
    </message>
    <message>
        <source>Cinema Mode</source>
        <translation>Cinema Mode</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Use Splashscreen as Home Background</source>
        <translation>Use Splashscreen as Home Background</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Design Elements</source>
        <translation>Design Elements</translation>
    </message>
    <message>
        <source>Search now</source>
        <translation>Search now</translation>
        <extracomment>Help text in search Box</extracomment>
    </message>
    <message>
        <source>Shows</source>
        <translation>Shows</translation>
    </message>
    <message>
        <source>Enable or disable Direct Play for optional codecs</source>
        <translation>Enable or disable Direct Play for optional codecs</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</source>
        <translation>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content but uses significantly more bandwidth.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Enabled</translation>
    </message>
    <message>
        <source>Next episode</source>
        <translation>Next episode</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>Reason</translation>
    </message>
    <message>
        <source>Slideshow Resumed</source>
        <translation>Slideshow Resumed</translation>
    </message>
    <message>
        <source>Random Off</source>
        <translation>Random Off</translation>
    </message>
    <message>
        <source>Albums</source>
        <translation>Albums</translation>
    </message>
    <message>
        <source>Total Bitrate</source>
        <translation>Total Bitrate</translation>
    </message>
    <message>
        <source>Artists (Grid)</source>
        <translation>Artists (Grid)</translation>
    </message>
    <message>
        <source>Always Hide</source>
        <translation>Always Hide</translation>
    </message>
    <message>
        <source>Album Artists (Presentation)</source>
        <translation>Album Artists (Presentation)</translation>
    </message>
    <message>
        <source>Attempt Direct Play for H.264 media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation>Attempt Direct Play for H.264 media with unsupported profile levels before falling back to transcoding if it fails.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Bring the theater experience straight to your living room with the ability to play custom intros before the main feature.</source>
        <translation>Bring the theatre experience straight to your living room with the ability to play custom intros before the main feature.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Attempt Direct Play for HEVC media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation>Attempt Direct Play for HEVC media with unsupported profile levels before falling back to transcoding if it fails.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Settings relating to the appearance of pages in TV Libraries.</source>
        <translation>Settings relating to the appearance of pages in TV Libraries.</translation>
    </message>
    <message>
        <source>Unable to find any albums or songs belonging to this artist</source>
        <translation>Unable to find any albums or songs belonging to this artist</translation>
        <extracomment>Popup message when we find no audio data for an artist</extracomment>
    </message>
    <message>
        <source>Replace Roku&apos;s default subtitle functions with custom functions that support CJK fonts. Fallback fonts must be configured and enabled on the server for CJK rendering to work.</source>
        <translation>Replace Roku&apos;s default subtitle functions with custom functions that support CJK fonts. Fallback fonts must be configured and enabled on the server for CJK rendering to work.</translation>
        <extracomment>Description of a setting - custom subtitles that support CJK fonts</extracomment>
    </message>
    <message>
        <source>Settings relating to the appearance of the Home screen and the program in general.</source>
        <translation>Settings relating to the appearance of the Home screen and the program in general.</translation>
    </message>
    <message>
        <source>Show What&apos;s New popup when WatchNexus is updated to a new version.</source>
        <translation>Show What&apos;s New popup when WatchNexus is updated to a new version.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Default view for Movie Libraries.</source>
        <translation>Default view for Movie Libraries.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Hide the star and community rating for episodes of a TV show. This is to prevent spoilers of an upcoming good/bad episode.</source>
        <translation>Hide the star and community rating for episodes of a TV show. This is to prevent spoilers of an upcoming good/bad episode.</translation>
    </message>
    <message>
        <source>Set the maximum bitrate in Mbps. Set to 0 to use Roku&apos;s specifications. This setting must be enabled to take effect.</source>
        <translation>Set the maximum bitrate in Mbps. Set to 0 to use Roku&apos;s specifications. This setting must be enabled to take effect.</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of pages in Movie Libraries.</source>
        <translation>Settings relating to the appearance of pages in Movie Libraries.</translation>
    </message>
    <message>
        <source>Loading trailer</source>
        <translation>Loading trailer</translation>
        <extracomment>Dialog title in Main.brs</extracomment>
    </message>
    <message>
        <source>Value</source>
        <translation>Value</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Set how many seconds before the end of an episode the Next Episode button should appear. Set to 0 to disable.</source>
        <translation>If no Outro media segment exists, set how many seconds before the end of an episode the Skip Outro button should appear. Set to 0 to disable.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Use the selected audio codec for transcodes. If the device or stream does not support it, a fallback codec will be used.</source>
        <translation>Use the selected audio codec for transcodes. If the device or stream does not support it, a fallback codec will be used.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Disable the HEVC codec on this device. This may improve playback for some devices (ultra).</source>
        <translation>Disable the HEVC codec on this device. This may improve playback for some devices (ultra).</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Remember Me?</source>
        <translation>Remember Me?</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Make the arrangement of the Roku home view sections match the web client&apos;s home screen. WatchNexus will need to be closed and reopened for change to take effect.</source>
        <translation>Make the arrangement of the Roku home view sections match the web client&apos;s home screen. WatchNexus will need to be closed and reopened for change to take effect.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Codec Tag</source>
        <translation>Codec Tag</translation>
    </message>
    <message>
        <source>Preferred Audio Codec</source>
        <translation>Preferred Audio Codec</translation>
        <extracomment>Settings Menu - Title of option</extracomment>
    </message>
    <message>
        <source>Use system settings</source>
        <translation>Use system settings</translation>
        <extracomment>User Setting - Option title</extracomment>
    </message>
    <message>
        <source>... (Press * to read more)</source>
        <translation>... (Press * to read more)</translation>
        <extracomment>Ellipsis Text for when text overflows its container</extracomment>
    </message>
    <message>
        <source>Hide Clock</source>
        <translation>Hide Clock</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Hide all clocks in WatchNexus. WatchNexus will need to be closed and reopened for changes to take effect.</source>
        <translation>Hide all clocks in WatchNexus. WatchNexus will need to be closed and reopened for changes to take effect.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Play Trailer</source>
        <translation>Play Trailer</translation>
    </message>
    <message>
        <source>H.264</source>
        <translation>H.264</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Settings relating to playback and supported codec and media types.</source>
        <translation>Settings relating to playback and supported codec and media types.</translation>
    </message>
    <message>
        <source>Settings relating to how the application looks.</source>
        <translation>Settings relating to how the application looks.</translation>
    </message>
    <message>
        <source>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it.</source>
        <translation>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Playback Information</source>
        <translation>Playback Information</translation>
    </message>
    <message>
        <source>Transcoding Information</source>
        <translation>Transcoding Information</translation>
    </message>
    <message>
        <source>Video Codec</source>
        <translation>Video Codec</translation>
    </message>
    <message>
        <source>Audio Codec</source>
        <translation>Audio Codec</translation>
    </message>
    <message>
        <source>Audio Channels</source>
        <translation>Audio Channels</translation>
    </message>
    <message>
        <source>Stream Information</source>
        <translation>Stream Information</translation>
    </message>
    <message>
        <source>Codec</source>
        <translation>Codec</translation>
    </message>
    <message>
        <source>Bit Rate</source>
        <translation>Bit Rate</translation>
        <extracomment>Video streaming bit rate</extracomment>
    </message>
    <message>
        <source>Container</source>
        <translation>Container</translation>
        <extracomment>Video streaming container</extracomment>
    </message>
    <message>
        <source>WxH</source>
        <translation>WxH</translation>
        <extracomment>Video width x height</extracomment>
    </message>
    <message>
        <source>Custom Subtitles</source>
        <translation>Custom Subtitles</translation>
        <extracomment>Name of a setting - custom subtitles that support CJK fonts</extracomment>
    </message>
    <message>
        <source>Only display text subtitles to minimize transcoding.</source>
        <translation>Only display text subtitles to minimise transcoding.</translation>
        <extracomment>Description of a setting - should we hide subtitles that might transcode</extracomment>
    </message>
    <message>
        <source>all</source>
        <translation>all</translation>
        <extracomment>all will reset the searchTerm so all data will be availible</extracomment>
    </message>
    <message>
        <source>Slideshow On</source>
        <translation>Slideshow On</translation>
    </message>
    <message>
        <source>Slideshow Paused</source>
        <translation>Slideshow Paused</translation>
    </message>
    <message>
        <source>Years</source>
        <translation>Years</translation>
        <extracomment>Used in Filter menu</extracomment>
    </message>
    <message>
        <source>Parental Ratings</source>
        <translation>Parental Ratings</translation>
        <extracomment>Used in Filter menu</extracomment>
    </message>
    <message>
        <source>Show What&apos;s New Popup</source>
        <translation>Show What&apos;s New Popup</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Unplayed</source>
        <translation>Unplayed</translation>
    </message>
    <message>
        <source>Played</source>
        <translation>Played</translation>
    </message>
    <message>
        <source>Resumable</source>
        <translation>Resumable</translation>
    </message>
    <message>
        <source>Movie Library Default View</source>
        <translation>Movie Library Default View</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Select when to show titles.</source>
        <translation>Select when to show titles.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Always Show</source>
        <translation>Always Show</translation>
    </message>
    <message>
        <source>Artists (Presentation)</source>
        <translation>Artists (Presentation)</translation>
    </message>
    <message>
        <source>Song</source>
        <translation>Song</translation>
    </message>
    <message>
        <source>Songs</source>
        <translation>Songs</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>Album</translation>
    </message>
    <message>
        <source>Disable Community Rating for Episodes</source>
        <translation>Disable Community Rating for Episodes</translation>
    </message>
    <message>
        <source>Configure the maximum playback bitrate.</source>
        <translation>Configure the maximum playback bitrate.</translation>
    </message>
    <message>
        <source>Biographical information for this person is not currently available.</source>
        <translation>Biographical information for this person is not currently available.</translation>
    </message>
    <message>
        <source>Enable Limit</source>
        <translation>Enable Limit</translation>
    </message>
    <message>
        <source>Enable or disable the &apos;Maximum Bitrate&apos; setting.</source>
        <translation>Enable or disable the &apos;Maximum Bitrate&apos; setting.</translation>
    </message>
    <message>
        <source>Libraries</source>
        <translation>Libraries</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of Library pages</source>
        <translation>Settings relating to the appearance of Library pages</translation>
    </message>
    <message>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <source>Settings that apply when Grid views are enabled.</source>
        <translation>Settings that apply when Grid views are enabled.</translation>
    </message>
    <message>
        <source>Presentation</source>
        <translation>Presentation</translation>
        <extracomment>Title of an option - name of presentation view</extracomment>
    </message>
    <message>
        <source>Disable Unwatched Episode Count</source>
        <translation>Disable Unwatched Episode Count</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>If enabled, the number of unwatched episodes in a series/season will be removed.</source>
        <translation>If enabled, the number of unwatched episodes in a series/season will be removed.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Next Episode Button Time</source>
        <translation>Next Episode Button Time</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>The source file is entirely compatible with this client and the session is receiving the file without modifications.</source>
        <translation>The source file is entirely compatible with this client and the session is receiving the file without modifications.</translation>
        <extracomment>Direct play info box text in GetPlaybackInfoTask.brs</extracomment>
    </message>
    <message>
        <source>Maximum Resolution</source>
        <translation>Maximum Resolution</translation>
        <extracomment>User Setting - Title</extracomment>
    </message>
    <message>
        <source>Off - Attempt to play all resolutions</source>
        <translation>Off - Attempt to play all resolutions</translation>
        <extracomment>User Setting - Option title</extracomment>
    </message>
    <message>
        <source>Configure the maximum resolution when playing video files on this device.</source>
        <translation>Configure the maximum resolution when playing video files on this device.</translation>
        <extracomment>User Setting - Description</extracomment>
    </message>
    <message>
        <source>All files</source>
        <translation>All files</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Only transcoded files</source>
        <translation>Only transcoded files</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Compatibility</source>
        <translation>Compatibility</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Attempt to prevent playback failures.</source>
        <translation>Attempt to prevent playback failures.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Global settings that affect everyone that uses this Roku device.</source>
        <translation>Global settings that affect everyone that uses this Roku device.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Use Web Client&apos;s Home Section Arrangement</source>
        <translation>Use Web Client&apos;s Home Section Arrangement</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>No Chapter Data Found</source>
        <translation>No Chapter Data Found</translation>
        <extracomment>Message shown in OSD when no chapter data is returned by the API</extracomment>
    </message>
    <message>
        <source>Remember the currently logged in user and try to log them in again next time you start the WatchNexus app.</source>
        <translation type="unfinished">Remember the currently logged in user and try to log them in again next time you start the WatchNexus app.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Random</source>
        <translation>Random</translation>
        <extracomment>General use word when we want to randomize data</extracomment>
    </message>
    <message>
        <source>What&apos;s New?</source>
        <translation>What&apos;s New?</translation>
        <extracomment>Popup title - Popup displays all the major changes to the app since the last version</extracomment>
    </message>
    <message>
        <source>Size</source>
        <translation>Size</translation>
        <extracomment>Video size</extracomment>
    </message>
    <message>
        <source>Pixel format</source>
        <translation>Pixel format</translation>
        <extracomment>Video pixel format</extracomment>
    </message>
    <message>
        <source>Aired</source>
        <translation>Aired</translation>
        <extracomment>Aired date label</extracomment>
    </message>
    <message>
        <source>View All</source>
        <translation>View All</translation>
    </message>
    <message>
        <source>Maximum Bitrate</source>
        <translation>Maximum Bitrate</translation>
    </message>
    <message>
        <source>Mode</source>
        <translation>Mode</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Disable HEVC</source>
        <translation>Disable HEVC</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Show On Hover</source>
        <translation>Show On Hover</translation>
    </message>
    <message>
        <source>Grid View Settings</source>
        <translation>Grid View Settings</translation>
    </message>
    <message>
        <source>direct</source>
        <translation>direct</translation>
    </message>
    <message>
        <source>Bitrate Limit</source>
        <translation>Bitrate Limit</translation>
    </message>
    <message>
        <source>Max Days Next Up</source>
        <translation>Max Days Next Up</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Text Subtitles Only</source>
        <translation>Text Subtitles Only</translation>
        <extracomment>Name of a setting - should we hide subtitles that might transcode</extracomment>
    </message>
    <message>
        <source>Slideshow Off</source>
        <translation>Slideshow Off</translation>
    </message>
    <message>
        <source>Item Titles</source>
        <translation>Item Titles</translation>
        <extracomment>Title of a setting - when should we show the title text of a grid item</extracomment>
    </message>
    <message>
        <source>Grid</source>
        <translation>Grid</translation>
        <extracomment>Title of an option - name of grid view</extracomment>
    </message>
    <message>
        <source>Set the maximum resolution when playing video files on this device.</source>
        <translation>Set the maximum resolution when playing video files on this device.</translation>
        <extracomment>User Setting - Description</extracomment>
    </message>
    <message>
        <source>Apply max resolution to all files or only transcoded files.</source>
        <translation>Apply max resolution to all files or only transcoded files.</translation>
        <extracomment>User Setting - Description</extracomment>
    </message>
    <message>
        <source>HEVC</source>
        <translation>HEVC</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Video range type</source>
        <translation>Video range type</translation>
    </message>
    <message>
        <source>Level</source>
        <translation>Level</translation>
        <extracomment>Video profile level</extracomment>
    </message>
    <message>
        <source>Random On</source>
        <translation>Random On</translation>
    </message>
    <message>
        <source>MPEG-4 Support</source>
        <translation>MPEG-4 Support</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Album Artists (Grid)</source>
        <translation>Album Artists (Grid)</translation>
    </message>
    <message>
        <source>Auto - Use TV resolution</source>
        <translation>Auto - Use TV resolution</translation>
        <extracomment>User Setting - Option title</extracomment>
    </message>
    <message>
        <source>Global</source>
        <translation>Global</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Direct playing</source>
        <translation>Direct playing</translation>
    </message>
    <message>
        <source>Community and Critical Ratings</source>
        <translation>Community and Critical Ratings</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Ratings for how good a movie is</source>
        <translation>Community and critic review ratings from Rotten Tomatoes.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Rewatching Next Up</source>
        <translation>Rewatching Next Up</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Welcome to version</source>
        <translation>Welcome to version</translation>
        <extracomment>WhatsNewDialog title - Welcome to version 2.0.0</extracomment>
    </message>
    <message>
        <source>To view a complete list of changes visit</source>
        <translation>To view a complete list of changes visit</translation>
        <extracomment>WhatsNewDialog body text preceding the changelog URL</extracomment>
    </message>
    <message>
        <source>Show already watched episodes in &apos;Next Up&apos; sections.</source>
        <translation>Show already watched episodes in &apos;Next Up&apos; sections.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>View All Next Up</source>
        <translation>View All Next Up</translation>
        <extracomment>Title for viewing all episodes available in the Next Up section</extracomment>
    </message>
    <message>
        <source>Episode Images Next Up</source>
        <translation>Episode Images Next Up</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>What type of images to use for Episodes shown in the &apos;Next Up&apos; and &apos;Continue Watching&apos; sections.</source>
        <translation>What type of images to use for Episodes shown in the &apos;Next Up&apos; and &apos;Continue Watching&apos; sections.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Use Web Client Setting</source>
        <translation>Use Web Client Setting</translation>
        <extracomment>User Setting - Setting option title</extracomment>
    </message>
    <message>
        <source>Use Episode Image</source>
        <translation>Use Episode Image</translation>
        <extracomment>User Setting - Setting option title</extracomment>
    </message>
    <message>
        <source>Use Show Image</source>
        <translation>Use Show Image</translation>
        <extracomment>User Setting - Setting option title</extracomment>
    </message>
    <message>
        <source>Autoplay Episode Limit</source>
        <translation>Autoplay Episode Limit</translation>
    </message>
    <message>
        <source>Recently Added in</source>
        <translation>Recently Added in</translation>
    </message>
    <message>
        <source>Community Rating</source>
        <translation>Community Rating</translation>
    </message>
    <message>
        <source>Album Artist</source>
        <translation>Album Artist</translation>
    </message>
    <message>
        <source>Change User</source>
        <translation>Change User</translation>
    </message>
    <message>
        <source>Unable to get playback information</source>
        <translation>Unable to get playback information</translation>
    </message>
    <message>
        <source>Date Episode Added</source>
        <translation>Date Episode Added</translation>
    </message>
    <message>
        <source>Favorited</source>
        <translation>Favourited</translation>
    </message>
    <message>
        <source>Mark As Favorite</source>
        <translation>Mark As Favourite</translation>
    </message>
    <message>
        <source>Resume playing at </source>
        <translation>Resume playing at </translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Settings</translation>
    </message>
    <message>
        <source>Date Show Added</source>
        <translation>Date Show Added</translation>
    </message>
    <message>
        <source>Folders</source>
        <translation>Folders</translation>
    </message>
    <message>
        <source>Go To Artist</source>
        <translation>Go To Artist</translation>
    </message>
    <message>
        <source>CH</source>
        <translation>CH</translation>
    </message>
    <message>
        <source>Start over from the beginning.</source>
        <translation>Start over from the beginning.</translation>
    </message>
    <message>
        <source>Playback Options</source>
        <translation>Playback Options</translation>
    </message>
    <message>
        <source>Force Transcoding setting is enabled</source>
        <translation>Force Transcoding setting is enabled</translation>
    </message>
    <message>
        <source>Force Transcode option is enabled</source>
        <translation>Force Transcode option is enabled</translation>
    </message>
    <message>
        <source>All</source>
        <translation>All</translation>
    </message>
    <message>
        <source>(Favorites)</source>
        <translation>(Favourites)</translation>
    </message>
    <message>
        <source>Favorites</source>
        <translation>Favourites</translation>
    </message>
    <message>
        <source>Artists</source>
        <translation>Artists</translation>
    </message>
    <message>
        <source>Delete Playlist</source>
        <translation>Delete Playlist</translation>
    </message>
    <message>
        <source>Collections</source>
        <translation>Collections</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Playlists</translation>
    </message>
    <message>
        <source>No items found. Try adjusting your selected filters.</source>
        <translation>No items found. Try adjusting your selected filters.</translation>
    </message>
    <message>
        <source>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it. Maximum value is 1000 days.</source>
        <translation>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it. Maximum value is 1000 days.</translation>
    </message>
    <message>
        <source>Grid View Item Titles</source>
        <translation>Grid View Item Titles</translation>
    </message>
    <message>
        <source>Select when to show titles in grid view.</source>
        <translation>Select when to show titles in grid view.</translation>
    </message>
    <message>
        <source>The number of episodes that will play automatically after the selected episode. Requires &apos;Play next episode automatically&apos; server setting to be enabled.</source>
        <translation>The number of episodes that will play automatically after the selected episode. Requires &apos;Play next episode automatically&apos; server setting to be enabled.</translation>
    </message>
    <message>
        <source>Video Codec Support</source>
        <translation>Video Codec Support</translation>
    </message>
    <message>
        <source>Enable or disable Direct Play support for certain codecs.</source>
        <translation>Enable or disable Direct Play support for certain codecs.</translation>
    </message>
</context>
<context>
    <name></name>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>...or enter server URL manually:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Pick a WatchNexus server from the local network</source>
        <translation>Select an available WatchNexus server from your local network:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Enter the server name or ip address</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>If no server is listed above, you may also enter the server URL manually:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Error Getting Playback Information</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>An error was encountered while playing this item. Server did not provide required transcoding data.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>An error was encountered while playing this item. Server did not provide required transcoding data.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Error Getting Playback Information</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>…or enter server URL manually:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Pick a WatchNexus server from the local network</source>
        <translation>Pick a WatchNexus server from the local network</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Enter the server name or ip address</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>An error was encountered while playing this item. Server did not provide required transcoding data.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Error Getting Playback Information</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>...or enter server URL manually:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Pick a WatchNexus server from the local network</source>
        <translation>Pick a WatchNexus server from the local network</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Enter the server name or IP address</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>On Now</source>
        <translation>On Now</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Delete Saved</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Save Credentials?</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>An error was encountered while playing this item. Server did not provide required transcoding data.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Error Getting Playback Information</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>…or enter server URL manually:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Pick a WatchNexus server from the local network</source>
        <translation>Pick a WatchNexus server from the local network</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Enter the server name or ip address</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Cancel Series Recording</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Cancel Recording</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Record Series</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Record</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>View Channel</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>On Now</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Delete Saved</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Save Credentials?</translation>
    </message>
    <message>
        <source>There was an error authenticating via Quick Connect.</source>
        <translation>There was an error authenticating via Quick Connect.</translation>
    </message>
    <message>
        <source>(Dialog will close automatically)</source>
        <translation>(Dialogue will close automatically)</translation>
    </message>
    <message>
        <source>Here is your Quick Connect code:</source>
        <translation>Here is your Quick Connect code:</translation>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation>Quick Connect</translation>
    </message>
    <message>
        <source>%1 of %2</source>
        <translation>%1 of %2</translation>
        <extracomment>Item position and count. %1 = current item. %2 = total number of items</extracomment>
    </message>
    <message>
        <source>Go to episode</source>
        <translation>Go to episode</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation>Go to season</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>Go to series</source>
        <translation>Go to series</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Series Detail Page</extracomment>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>Set Watched</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>Set Favourite</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>Show item count in the library, and index of selected item.</source>
        <translation>Show item count in the library, and index of the selected item.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Item Count</source>
        <translation>Item Count</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Count in user setting screen.</extracomment>
    </message>
    <message>
        <source>Always show the titles below the poster images. (If disabled, title will be shown under hilighted item only)</source>
        <translation>Always show the titles below the poster images. (If disabled, title will be shown under highlighted item only)</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Item Titles</source>
        <translation>Item Titles</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Media Grid Options</source>
        <translation>Media Grid Options</translation>
    </message>
    <message>
        <source>Media Grid</source>
        <translation>Media Grid</translation>
        <extracomment>UI -&gt; Media Grid section in user setting screen.</extracomment>
    </message>
    <message>
        <source>User Interface</source>
        <translation>User Interface</translation>
        <extracomment>Title for User Interface section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Disabled</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Enabled</translation>
    </message>
    <message>
        <source>Support direct play of MPEG 2 content (e.g. Live TV). This will prevent transcoding of MPEG 2 content, but uses significantly more bandwidth</source>
        <translation>Support direct play of MPEG 2 content (e.g. Live TV). This will prevent transcoding of MPEG 2 content but uses significantly more bandwidth</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>MPEG 2 Support</source>
        <translation>MPEG 2 Support</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Playback</source>
        <translation>Playback</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>An error was encountered while playing this item. The server did not provide the required transcoding data.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Error Getting Playback Information</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>…or enter server URL manually:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Pick a WatchNexus server from the local network</source>
        <translation>Pick a WatchNexus server from the local network</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Enter the server name or IP address</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unknown</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Close</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Cancel Series Recording</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Cancel Recording</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Record Series</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Record</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>View Channel</translation>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>TV Shows</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Films</translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>Press &apos;OK&apos; to Close</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Special Features</translation>
        <message>
            <source>Press &apos;OK&apos; to Close</source>
            <translation>Press &apos;OK&apos; to Close</translation>
        </message>
    </message>
    <message>
        <source>More Like This</source>
        <translation>More Like This</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Cast &amp; Crew</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Age</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Died</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Born</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>On Now</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Delete Saved</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Save Credentials?</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation type="unfinished">An error was encountered while playing this item. Server did not provide required transcoding data.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Error Getting Playback Information</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>…or enter server URL manually:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Pick a WatchNexus server from the local network</source>
        <translation>Pick a WatchNexus server from the local network</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Enter the server name or IP address</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unknown</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Close</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Cancel Series Recording</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Cancel Recording</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Record Series</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Record</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>View Channel</translation>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>TV Shows</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Films</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Special Features</translation>
        <message>
            <source>Press &apos;OK&apos; to Close</source>
            <translation>Press &apos;OK&apos; to Close</translation>
        </message>
    </message>
    <message>
        <source>More Like This</source>
        <translation>More Like This</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Cast &amp; Crew</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Age</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Died</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Born</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>On Now</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Delete Saved</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Save Credentials?</translation>
    </message>
    <message>
        <source>Playback</source>
        <translation>Playback</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Save Credentials?</translation>
    </message>
    <message>
        <source>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it.</source>
        <translation>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Max Days Next Up</source>
        <translation>Max Days Next Up</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Options for Home Page.</source>
        <translation>Options for Home Page.</translation>
        <extracomment>Description for Home Page user settings.</extracomment>
    </message>
    <message>
        <source>Home Page</source>
        <translation>Home Page</translation>
    </message>
    <message>
        <source>Settings relating to how the application looks.</source>
        <translation>Settings relating to how the application looks.</translation>
    </message>
    <message>
        <source>Settings relating to playback and supported codec and media types.</source>
        <translation>Settings relating to playback and supported codec and media types.</translation>
    </message>
    <message>
        <source>Play Trailer</source>
        <translation>Play Trailer</translation>
    </message>
    <message>
        <source>Skip Intro</source>
        <translation>Skip Intro</translation>
    </message>
    <message>
        <source>Hides all clocks in WatchNexus. WatchNexus will need to be closed and reopened for change to take effect.</source>
        <translation>Hides all clocks in WatchNexus. WatchNexus will need to be closed and reopened for change to take effect.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Hide Clock</source>
        <translation>Hide Clock</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Cinema Mode brings the theater experience straight to your living room with the ability to play custom intros before the main feature.</source>
        <translation>Cinema Mode brings the theatre experience straight to your living room with the ability to play custom intros before the main feature.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Cinema Mode</source>
        <translation>Cinema Mode</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Use generated splashscreen image as WatchNexus&apos;s home background. WatchNexus will need to be closed and reopened for change to take effect.</source>
        <translation>Use generated splashscreen image as WatchNexus&apos;s home background. WatchNexus will need to be closed and reopened for change to take effect.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Use Splashscreen as Home Background</source>
        <translation>Use Splashscreen as Home Background</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Options that alter the design of WatchNexus.</source>
        <translation>Options that alter the design of WatchNexus.</translation>
        <extracomment>Description for Design Elements user settings.</extracomment>
    </message>
    <message>
        <source>Design Elements</source>
        <translation>Design Elements</translation>
    </message>
    <message>
        <source>Use generated splashscreen image as WatchNexus&apos;s screensaver background. WatchNexus will need to be closed and reopened for change to take effect.</source>
        <translation>Use generated splashscreen image as WatchNexus&apos;s screensaver background. WatchNexus will need to be closed and reopened for change to take effect.</translation>
    </message>
    <message>
        <source>Use Splashscreen as Screensaver Background</source>
        <translation>Use Splashscreen as Screensaver Background</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Options for WatchNexus&apos;s screensaver.</source>
        <translation>Options for WatchNexus&apos;s screensaver.</translation>
        <extracomment>Description for Screensaver user settings.</extracomment>
    </message>
    <message>
        <source>Screensaver</source>
        <translation>Screensaver</translation>
    </message>
    <message>
        <source>If enabled, images of unwatched episodes will be blurred.</source>
        <translation>If enabled, images of unwatched episodes will be blurred.</translation>
    </message>
    <message>
        <source>Blur Unwatched Episodes</source>
        <translation>Blur Unwatched Episodes</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Options for TV Shows.</source>
        <translation>Options for TV Shows.</translation>
        <extracomment>Description for TV Shows user settings.</extracomment>
    </message>
    <message>
        <source>Hides tagline text on details pages.</source>
        <translation>Hides tagline text on details pages.</translation>
    </message>
    <message>
        <source>Hide Taglines</source>
        <translation>Hide Taglines</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Options for Details pages.</source>
        <translation>Options for Details pages.</translation>
        <extracomment>Description for Details page user settings.</extracomment>
    </message>
    <message>
        <source>Details Page</source>
        <translation>Details Page</translation>
    </message>
    <message>
        <source>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</source>
        <translation>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Return to Top</source>
        <translation>Return to Top</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Shows</source>
        <translation>Shows</translation>
    </message>
    <message>
        <source>Studios</source>
        <translation>Studios</translation>
    </message>
    <message>
        <source>Networks</source>
        <translation>Networks</translation>
    </message>
    <message>
        <source>There was an error authenticating via Quick Connect.</source>
        <translation>There was an error authenticating via Quick Connect.</translation>
    </message>
    <message>
        <source>(Dialog will close automatically)</source>
        <translation>(Dialog will close automatically)</translation>
    </message>
    <message>
        <source>Here is your Quick Connect code:</source>
        <translation>Here is your Quick Connect code:</translation>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation>Quick Connect</translation>
    </message>
    <message>
        <source>%1 of %2</source>
        <translation>%1 of %2</translation>
        <extracomment>Item position and count. %1 = current item. %2 = total number of items</extracomment>
    </message>
    <message>
        <source>You can search for Titles, People, Live TV Channels and more</source>
        <translation>You can search for Titles, People, Live TV Channels and more</translation>
        <extracomment>Help text in search results</extracomment>
    </message>
    <message>
        <source>Search now</source>
        <translation>Search now</translation>
        <extracomment>Help text in search Box</extracomment>
    </message>
    <message>
        <source>Use voice remote to search</source>
        <translation>Use voice remote to search</translation>
        <extracomment>Help text in search voice text box</extracomment>
    </message>
    <message>
        <source>Go to episode</source>
        <translation>Go to episode</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation>Go to season</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>Go to series</source>
        <translation>Go to series</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Series Detail Page</extracomment>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>Set Watched</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>Set Favourite</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>Show item count in the library and index of selected item.</source>
        <translation>Show item count in the library and index of selected item.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Item Count</source>
        <translation>Item Count</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Count in user setting screen.</extracomment>
    </message>
    <message>
        <source>Always show the titles below the poster images. (If disabled, the title will be shown under the highlighted item only).</source>
        <translation>Always show the titles below the poster images. (If disabled, the title will be shown under the highlighted item only).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Item Titles</source>
        <translation>Item Titles</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Media Grid options.</source>
        <translation>Media Grid options.</translation>
    </message>
    <message>
        <source>Media Grid</source>
        <translation>Media Grid</translation>
        <extracomment>UI -&gt; Media Grid section in user setting screen.</extracomment>
    </message>
    <message>
        <source>User Interface</source>
        <translation>User Interface</translation>
        <extracomment>Title for User Interface section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Disabled</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Enabled</translation>
    </message>
    <message>
        <source>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</source>
        <translation>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>MPEG-2 Support</source>
        <translation>MPEG-2 Support</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Playback</source>
        <translation>Playback</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>An error was encountered while playing this item. Server did not provide required transcoding data.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Error Getting Playback Information</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>If no server is listed above, you may also enter the server URL manually:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Pick a WatchNexus server from the local network</source>
        <translation>Select an available WatchNexus server from your local network:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Enter the server name or ip address</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unknown</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Close</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Cancel Series Recording</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Cancel Recording</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Record Series</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Record</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>View Channel</translation>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>TV Shows</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Movies</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Special Features</translation>
        <message>
            <source>Press &apos;OK&apos; to Close</source>
            <translation>Press &apos;OK&apos; to Close</translation>
        </message>
    </message>
    <message>
        <source>More Like This</source>
        <translation>More Like This</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Cast &amp; Crew</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Age</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Died</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Born</translation>
    </message>
    <message>
        <source>Enter a value...</source>
        <translation>Enter a value...</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>On Now</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Delete Saved</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Save Credentials?</translation>
    </message>
    <message>
        <source>WxH</source>
        <translation>WxH</translation>
        <extracomment>Video width x height</extracomment>
    </message>
    <message>
        <source>Pixel format</source>
        <translation>Pixel format</translation>
        <extracomment>Video pixel format</extracomment>
    </message>
    <message>
        <source>Video range type</source>
        <translation>Video range type</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Size</translation>
        <extracomment>Video size</extracomment>
    </message>
    <message>
        <source>Container</source>
        <translation>Container</translation>
        <extracomment>Video streaming container</extracomment>
    </message>
    <message>
        <source>Bit Rate</source>
        <translation>Bit Rate</translation>
        <extracomment>Video streaming bit rate</extracomment>
    </message>
    <message>
        <source>Level</source>
        <translation>Level</translation>
        <extracomment>Video profile level</extracomment>
    </message>
    <message>
        <source>Codec Tag</source>
        <translation>Codec Tag</translation>
    </message>
    <message>
        <source>Codec</source>
        <translation>Codec</translation>
    </message>
    <message>
        <source>Stream Information</source>
        <translation>Stream Information</translation>
    </message>
    <message>
        <source>Audio Channels</source>
        <translation>Audio Channels</translation>
    </message>
    <message>
        <source>Total Bitrate</source>
        <translation>Total Bitrate</translation>
    </message>
    <message>
        <source>direct</source>
        <translation>direct</translation>
    </message>
    <message>
        <source>Audio Codec</source>
        <translation>Audio Codec</translation>
    </message>
    <message>
        <source>Video Codec</source>
        <translation>Video Codec</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>Reason</translation>
    </message>
    <message>
        <source>Transcoding Information</source>
        <translation>Transcoding Information</translation>
    </message>
    <message>
        <source>Playback Information</source>
        <translation>Playback Information</translation>
    </message>
    <message>
        <source>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it.</source>
        <translation>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Max Days Next Up</source>
        <translation>Max Days Next Up</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Options for Home Page.</source>
        <translation>Options for Home Page.</translation>
        <extracomment>Description for Home Page user settings.</extracomment>
    </message>
    <message>
        <source>Home Page</source>
        <translation>Home Page</translation>
    </message>
    <message>
        <source>Settings relating to how the application looks.</source>
        <translation>Settings relating to how the application looks.</translation>
    </message>
    <message>
        <source>Settings relating to playback and supported codec and media types.</source>
        <translation>Settings relating to playback and supported codec and media types.</translation>
    </message>
    <message>
        <source>Play Trailer</source>
        <translation>Play Trailer</translation>
    </message>
    <message>
        <source>Hides all clocks in WatchNexus. WatchNexus will need to be closed and reopened for change to take effect.</source>
        <translation>Hides all clocks in WatchNexus. WatchNexus will need to be closed and reopened for change to take effect.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Hide Clock</source>
        <translation>Hide Clock</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Cinema Mode brings the theater experience straight to your living room with the ability to play custom intros before the main feature.</source>
        <translation>Cinema Mode brings the theatre experience straight to your living room with the ability to play custom intros before the main feature.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Cinema Mode</source>
        <translation>Cinema Mode</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Use generated splashscreen image as WatchNexus&apos;s home background. WatchNexus will need to be closed and reopened for change to take effect.</source>
        <translation>Use generated splashscreen image as WatchNexus&apos;s home background. WatchNexus will need to be closed and reopened for change to take effect.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Use Splashscreen as Home Background</source>
        <translation>Use Splashscreen as Home Background</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Options that alter the design of WatchNexus.</source>
        <translation>Options that alter the design of WatchNexus.</translation>
        <extracomment>Description for Design Elements user settings.</extracomment>
    </message>
    <message>
        <source>Design Elements</source>
        <translation>Design Elements</translation>
    </message>
    <message>
        <source>Use generated splashscreen image as WatchNexus&apos;s screensaver background. WatchNexus will need to be closed and reopened for change to take effect.</source>
        <translation>Use generated splashscreen image as WatchNexus&apos;s screensaver background. WatchNexus will need to be closed and reopened for change to take effect.</translation>
    </message>
    <message>
        <source>Use Splashscreen as Screensaver Background</source>
        <translation>Use Splashscreen as Screensaver Background</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Options for WatchNexus&apos;s screensaver.</source>
        <translation>Options for WatchNexus&apos;s screensaver.</translation>
        <extracomment>Description for Screensaver user settings.</extracomment>
    </message>
    <message>
        <source>Screensaver</source>
        <translation>Screensaver</translation>
    </message>
    <message>
        <source>If enabled, images of unwatched episodes will be blurred.</source>
        <translation>If enabled, images of unwatched episodes will be blurred.</translation>
    </message>
    <message>
        <source>Blur Unwatched Episodes</source>
        <translation>Blur Unwatched Episodes</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Options for TV Shows.</source>
        <translation>Options for TV Shows.</translation>
        <extracomment>Description for TV Shows user settings.</extracomment>
    </message>
    <message>
        <source>Hides tagline text on details pages.</source>
        <translation>Hides tagline text on details pages.</translation>
    </message>
    <message>
        <source>Hide Taglines</source>
        <translation>Hide Taglines</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Options for Details pages.</source>
        <translation>Options for Details pages.</translation>
        <extracomment>Description for Details page user settings.</extracomment>
    </message>
    <message>
        <source>Details Page</source>
        <translation>Details Page</translation>
    </message>
    <message>
        <source>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</source>
        <translation>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Return to Top</source>
        <translation>Return to Top</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Shows</source>
        <translation>Shows</translation>
    </message>
    <message>
        <source>Studios</source>
        <translation>Studios</translation>
    </message>
    <message>
        <source>Networks</source>
        <translation>Networks</translation>
    </message>
    <message>
        <source>There was an error authenticating via Quick Connect.</source>
        <translation>There was an error authenticating via Quick Connect.</translation>
    </message>
    <message>
        <source>(Dialog will close automatically)</source>
        <translation>(Dialog will close automatically)</translation>
    </message>
    <message>
        <source>Here is your Quick Connect code:</source>
        <translation>Here is your Quick Connect code:</translation>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation>Quick Connect</translation>
    </message>
    <message>
        <source>%1 of %2</source>
        <translation>%1 of %2</translation>
        <extracomment>Item position and count. %1 = current item. %2 = total number of items</extracomment>
    </message>
    <message>
        <source>You can search for Titles, People, Live TV Channels and more</source>
        <translation>You can search for Titles, People, Live TV Channels and more</translation>
        <extracomment>Help text in search results</extracomment>
    </message>
    <message>
        <source>Search now</source>
        <translation>Search now</translation>
        <extracomment>Help text in search Box</extracomment>
    </message>
    <message>
        <source>Use voice remote to search</source>
        <translation>Use voice remote to search</translation>
        <extracomment>Help text in search voice text box</extracomment>
    </message>
    <message>
        <source>Go to episode</source>
        <translation>Go to episode</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation>Go to season</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>Go to series</source>
        <translation>Go to series</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Series Detail Page</extracomment>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>Set Watched</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>Set Favourite</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>Show item count in the library and index of selected item.</source>
        <translation>Show item count in the library and index of selected item.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Item Count</source>
        <translation>Item Count</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Count in user setting screen.</extracomment>
    </message>
    <message>
        <source>Always show the titles below the poster images. (If disabled, the title will be shown under the highlighted item only).</source>
        <translation>Always show the titles below the poster images. (If disabled, the title will be shown under the highlighted item only).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Item Titles</source>
        <translation>Item Titles</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Media Grid options.</source>
        <translation>Media Grid options.</translation>
    </message>
    <message>
        <source>Media Grid</source>
        <translation>Media Grid</translation>
        <extracomment>UI -&gt; Media Grid section in user setting screen.</extracomment>
    </message>
    <message>
        <source>User Interface</source>
        <translation>User Interface</translation>
        <extracomment>Title for User Interface section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Disabled</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Enabled</translation>
    </message>
    <message>
        <source>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</source>
        <translation>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>MPEG-2 Support</source>
        <translation>MPEG-2 Support</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Playback</source>
        <translation>Playback</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>An error was encountered while playing this item. Server did not provide required transcoding data.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Error Getting Playback Information</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>If no server is listed above, you may also enter the server URL manually:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Pick a WatchNexus server from the local network</source>
        <translation>Select an available WatchNexus server from your local network:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Enter the server name or IP address</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unknown</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Close</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Cancel Series Recording</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Cancel Recording</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Record Series</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Record</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>View Channel</translation>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>TV Shows</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Movies</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Special Features</translation>
        <message>
            <source>Press &apos;OK&apos; to Close</source>
            <translation>Press &apos;OK&apos; to Close</translation>
        </message>
    </message>
    <message>
        <source>More Like This</source>
        <translation>More Like This</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Cast &amp; Crew</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Age</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Died</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Born</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>On Now</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Delete Saved</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Save Credentials?</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Item Titles</source>
        <translation>Item Titles</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Save Credentials?</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Born</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Age</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>More Like This</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Special Features</translation>
        <message>
            <source>Press &apos;OK&apos; to Close</source>
            <translation>Press &apos;OK&apos; to Close</translation>
        </message>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>TV Shows</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>View Channel</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Record</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Record Series</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Cancel Recording</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unknown</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Enter the server name or IP address</source>
        <translation>Enter the server name or IP address</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Cast &amp; Crew</translation>
    </message>
    <message>
        <source>Pick a WatchNexus server from the local network</source>
        <translation>Select an available WatchNexus server from your local network:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Error Getting Playback Information</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>An error was encountered while playing this item. Server did not provide required transcoding data.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Playback</source>
        <translation>Playback</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>MPEG-2 Support</source>
        <translation>MPEG-2 Support</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</source>
        <translation>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>User Interface</source>
        <translation>User Interface</translation>
        <extracomment>Title for User Interface section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Media Grid</source>
        <translation>Media Grid</translation>
        <extracomment>UI -&gt; Media Grid section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Media Grid options.</source>
        <translation>Media Grid options.</translation>
    </message>
    <message>
        <source>Always show the titles below the poster images. (If disabled, the title will be shown under the highlighted item only).</source>
        <translation>Always show the titles below the poster images. (If disabled, the title will be shown under the highlighted item only).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Item Count</source>
        <translation>Item Count</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Count in user setting screen.</extracomment>
    </message>
    <message>
        <source>Show item count in the library and index of selected item.</source>
        <translation>Show item count in the library and index of selected item.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>Set Favourite</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>Set Watched</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>Go to series</source>
        <translation>Go to series</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Series Detail Page</extracomment>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Delete Saved</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Films</translation>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Cancel Series Recording</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>On Now</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Died</translation>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>If no server is listed above, you may also enter the server URL manually:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Enabled</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Disabled</translation>
    </message>
    <message>
        <source>Use voice remote to search</source>
        <translation>Use voice remote to search</translation>
        <extracomment>Help text in search voice text box</extracomment>
    </message>
    <message>
        <source>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</source>
        <translation>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Options for TV Shows.</source>
        <translation>Options for TV Shows.</translation>
        <extracomment>Description for TV Shows user settings.</extracomment>
    </message>
    <message>
        <source>Cinema Mode brings the theater experience straight to your living room with the ability to play custom intros before the main feature.</source>
        <translation>Cinema Mode brings the cinema experience straight to your living room with the ability to play custom intros before the main feature.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Hides all clocks in WatchNexus. WatchNexus will need to be closed and reopened for change to take effect.</source>
        <translation>Hides all clocks in WatchNexus. WatchNexus will need to be closed and reopened for change to take effect.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Settings relating to playback and supported codec and media types.</source>
        <translation>Settings relating to playback and supported codec and media types.</translation>
    </message>
    <message>
        <source>Settings relating to how the application looks.</source>
        <translation>Settings relating to how the application looks.</translation>
    </message>
    <message>
        <source>Studios</source>
        <translation>Studios</translation>
    </message>
    <message>
        <source>Return to Top</source>
        <translation>Return to Top</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Details Page</source>
        <translation>Details Page</translation>
    </message>
    <message>
        <source>Hide Taglines</source>
        <translation>Hide Taglines</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Use Splashscreen as Screensaver Background</source>
        <translation>Use Splashscreen as Screensaver Background</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Playback Information</source>
        <translation>Playback Information</translation>
    </message>
    <message>
        <source>Transcoding Information</source>
        <translation>Transcoding Information</translation>
    </message>
    <message>
        <source>Video Codec</source>
        <translation>Video Codec</translation>
    </message>
    <message>
        <source>Audio Codec</source>
        <translation>Audio Codec</translation>
    </message>
    <message>
        <source>direct</source>
        <translation>direct</translation>
    </message>
    <message>
        <source>Level</source>
        <translation>Level</translation>
        <extracomment>Video profile level</extracomment>
    </message>
    <message>
        <source>Bit Rate</source>
        <translation>Bit Rate</translation>
        <extracomment>Video streaming bit rate</extracomment>
    </message>
    <message>
        <source>Size</source>
        <translation>Size</translation>
        <extracomment>Video size</extracomment>
    </message>
    <message>
        <source>WxH</source>
        <translation>WxH</translation>
        <extracomment>Video width x height</extracomment>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation>Quick Connect</translation>
    </message>
    <message>
        <source>Here is your Quick Connect code:</source>
        <translation>Here is your Quick Connect code:</translation>
    </message>
    <message>
        <source>(Dialog will close automatically)</source>
        <translation>(Dialogue will close automatically)</translation>
    </message>
    <message>
        <source>Play Trailer</source>
        <translation>Play Trailer</translation>
    </message>
    <message>
        <source>Home Page</source>
        <translation>Home Page</translation>
    </message>
    <message>
        <source>Options for Home Page.</source>
        <translation>Options for Home Page.</translation>
        <extracomment>Description for Home Page user settings.</extracomment>
    </message>
    <message>
        <source>Cinema Mode</source>
        <translation>Cinema Mode</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Use Splashscreen as Home Background</source>
        <translation>Use Splashscreen as Home Background</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Design Elements</source>
        <translation>Design Elements</translation>
    </message>
    <message>
        <source>Screensaver</source>
        <translation>Screensaver</translation>
    </message>
    <message>
        <source>Search now</source>
        <translation>Search now</translation>
        <extracomment>Help text in search Box</extracomment>
    </message>
    <message>
        <source>Go to episode</source>
        <translation>Go to episode</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation>Go to season</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>You can search for Titles, People, Live TV Channels and more</source>
        <translation>You can search for Titles, People, Live TV Channels and more</translation>
        <extracomment>Help text in search results</extracomment>
    </message>
    <message>
        <source>%1 of %2</source>
        <translation>%1 of %2</translation>
        <extracomment>Item position and count. %1 = current item. %2 = total number of items</extracomment>
    </message>
    <message>
        <source>There was an error authenticating via Quick Connect.</source>
        <translation>There was an error authenticating via Quick Connect.</translation>
    </message>
    <message>
        <source>Networks</source>
        <translation>Networks</translation>
    </message>
    <message>
        <source>Shows</source>
        <translation>Shows</translation>
    </message>
    <message>
        <source>Options for Details pages.</source>
        <translation>Options for Details pages.</translation>
        <extracomment>Description for Details page user settings.</extracomment>
    </message>
    <message>
        <source>Hides tagline text on details pages.</source>
        <translation>Hides tagline text on details pages.</translation>
    </message>
    <message>
        <source>Blur Unwatched Episodes</source>
        <translation>Blur Unwatched Episodes</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>If enabled, images of unwatched episodes will be blurred.</source>
        <translation>If enabled, images of unwatched episodes will be blurred.</translation>
    </message>
    <message>
        <source>Options for WatchNexus&apos;s screensaver.</source>
        <translation>Options for WatchNexus&apos;s screensaver.</translation>
        <extracomment>Description for Screensaver user settings.</extracomment>
    </message>
    <message>
        <source>Use generated splashscreen image as WatchNexus&apos;s screensaver background. WatchNexus will need to be closed and reopened for change to take effect.</source>
        <translation>Use generated splashscreen image as WatchNexus&apos;s screensaver background. WatchNexus will need to be closed and reopened for change to take effect.</translation>
    </message>
    <message>
        <source>Options that alter the design of WatchNexus.</source>
        <translation>Options that alter the design of WatchNexus.</translation>
        <extracomment>Description for Design Elements user settings.</extracomment>
    </message>
    <message>
        <source>Use generated splashscreen image as WatchNexus&apos;s home background. WatchNexus will need to be closed and reopened for change to take effect.</source>
        <translation>Use generated splashscreen image as WatchNexus&apos;s home background. WatchNexus will need to be closed and reopened for change to take effect.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Hide Clock</source>
        <translation>Hide Clock</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Max Days Next Up</source>
        <translation>Max Days Next Up</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it.</source>
        <translation>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Reason</source>
        <translation>Reason</translation>
    </message>
    <message>
        <source>Total Bitrate</source>
        <translation>Total Bitrate</translation>
    </message>
    <message>
        <source>Audio Channels</source>
        <translation>Audio Channels</translation>
    </message>
    <message>
        <source>Stream Information</source>
        <translation>Stream Information</translation>
    </message>
    <message>
        <source>Codec</source>
        <translation>Codec</translation>
    </message>
    <message>
        <source>Codec Tag</source>
        <translation>Codec Tag</translation>
    </message>
    <message>
        <source>Container</source>
        <translation>Container</translation>
        <extracomment>Video streaming container</extracomment>
    </message>
    <message>
        <source>Video range type</source>
        <translation>Video range type</translation>
    </message>
    <message>
        <source>Pixel format</source>
        <translation>Pixel format</translation>
        <extracomment>Video pixel format</extracomment>
    </message>
    <message>
        <source>Unable to find any albums or songs belonging to this artist</source>
        <translation>Unable to find any albums or songs belonging to this artist</translation>
        <extracomment>Popup message when we find no audio data for an artist</extracomment>
    </message>
    <message>
        <source>On Now</source>
        <translation>On Now</translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>Press &apos;OK&apos; to Close</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>View Channel</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Record</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Age</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Cast &amp; Crew</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Save Credentials?</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Delete Saved</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Died</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>More Like This</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Special Features</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Born</translation>
    </message>
    <message>
        <source>Additional Parts</source>
        <translation>Additional Parts</translation>
        <extracomment>Additional parts of a video</extracomment>
    </message>
    <message>
        <source>Movies</source>
        <translation>Films</translation>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>TV Shows</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Record Series</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Cancel Recording</translation>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Cancel Series Recording</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Save Credentials?</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Delete Saved</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>On Now</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Age</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Died</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Born</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Cast &amp; Crew</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>More Like This</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Delete Saved</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>More Like This</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Cast &amp; Crew</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Age</translation>
    </message>
    <message>
        <source>Additional Parts</source>
        <translation>Additional Parts</translation>
        <extracomment>Additional parts of a video</extracomment>
    </message>
    <message>
        <source>Died</source>
        <translation>Died</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Born</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Save Credentials?</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>On Now</translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>Press &apos;OK&apos; to Close</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Special Features</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Delete Saved</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Special Features</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>More Like This</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Age</translation>
    </message>
    <message>
        <source>Additional Parts</source>
        <translation>Additional Parts</translation>
        <extracomment>Additional parts of a video</extracomment>
    </message>
    <message>
        <source>Died</source>
        <translation>Died</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Born</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Save Credentials?</translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>Press &apos;OK&apos; to Close</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>On Now</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Cast &amp; Crew</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Delete Saved</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>On Now</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>More Like This</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Age</translation>
    </message>
    <message>
        <source>Additional Parts</source>
        <translation>Additional Parts</translation>
        <extracomment>Additional parts of a video</extracomment>
    </message>
    <message>
        <source>Died</source>
        <translation>Died</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Born</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Special Features</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Save Credentials?</translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>Press &apos;OK&apos; to Close</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Cast &amp; Crew</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Delete Saved</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>On Now</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Age</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Died</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Born</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Save Credentials?</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Cast &amp; Crew</translation>
    </message>
    <message>
        <source>Additional Parts</source>
        <translation>Additional Parts</translation>
        <extracomment>Additional parts of a video</extracomment>
    </message>
    <message>
        <source>More Like This</source>
        <translation>More Like This</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Special Features</translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>Press &apos;OK&apos; to Close</translation>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>TV Shows</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>View Channel</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Record</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Cancel Recording</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Record Series</translation>
    </message>
    <message>
        <source>Enter the server name or IP address</source>
        <translation>Enter the server name or IP address</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>Pick a WatchNexus server from the local network</source>
        <translation>Select an available WatchNexus server from your local network:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Error Getting Playback Information</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>An error was encountered while playing this item. Server did not provide required transcoding data.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</source>
        <translation>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>MPEG-4</source>
        <translation>MPEG-4</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Support Direct Play of MPEG-4 content. This may need to be disabled for playback of DIVX encoded video files.</source>
        <translation>Support Direct Play of MPEG-4 content. This may need to be disabled for playback of DIVX encoded video files.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>AV1</source>
        <translation>AV1</translation>
        <extracomment>Name of a setting - should we try to direct play experimental av1 codec</extracomment>
    </message>
    <message>
        <source>You can search for Titles, People, Live TV Channels and more</source>
        <translation>You can search for Titles, People, Live TV Channels and more</translation>
        <extracomment>Help text in search results</extracomment>
    </message>
    <message>
        <source>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</source>
        <translation>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>If enabled, selecting a TV series with only one season will go straight to the episode list rather than the show details and season list.</source>
        <translation>If enabled, selecting a TV series with only one season will go straight to the episode list rather than the show details and season list.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>If enabled, images of unwatched episodes will be blurred.</source>
        <translation>If enabled, images of unwatched episodes will be blurred.</translation>
    </message>
    <message>
        <source>Options for WatchNexus&apos;s screensaver.</source>
        <translation>Options for WatchNexus&apos;s screensaver.</translation>
        <extracomment>Description for Screensaver user settings.</extracomment>
    </message>
    <message>
        <source>Use Splashscreen as Screensaver Background</source>
        <translation>Use Splashscreen as Screensaver Background</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Use generated splashscreen image as WatchNexus&apos;s screensaver background. WatchNexus will need to be closed and reopened for change to take effect.</source>
        <translation>Use generated splashscreen image as WatchNexus&apos;s screensaver background. WatchNexus will need to be closed and reopened for change to take effect.</translation>
    </message>
    <message>
        <source>Use generated splashscreen image as WatchNexus&apos;s home background. WatchNexus will need to be closed and reopened for change to take effect.</source>
        <translation>Use generated splashscreen image as WatchNexus&apos;s home background. WatchNexus will need to be closed and reopened for change to take effect.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Hide Clock</source>
        <translation>Hide Clock</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Hides all clocks in WatchNexus. WatchNexus will need to be closed and reopened for change to take effect.</source>
        <translation>Hides all clocks in WatchNexus. WatchNexus will need to be closed and reopened for change to take effect.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Options for Home Page.</source>
        <translation>Options for Home Page.</translation>
        <extracomment>Description for Home Page user settings.</extracomment>
    </message>
    <message>
        <source>direct</source>
        <translation>direct</translation>
    </message>
    <message>
        <source>Details Page</source>
        <translation>Details Page</translation>
    </message>
    <message>
        <source>Video Codec</source>
        <translation>Video Codec</translation>
    </message>
    <message>
        <source>Level</source>
        <translation>Level</translation>
        <extracomment>Video profile level</extracomment>
    </message>
    <message>
        <source>Size</source>
        <translation>Size</translation>
        <extracomment>Video size</extracomment>
    </message>
    <message>
        <source>WxH</source>
        <translation>WxH</translation>
        <extracomment>Video width x height</extracomment>
    </message>
    <message>
        <source>Codec Tag</source>
        <translation>Codec Tag</translation>
    </message>
    <message>
        <source>Movies (Presentation)</source>
        <translation>Movies (Presentation)</translation>
    </message>
    <message>
        <source>Movies (Grid)</source>
        <translation>Movies (Grid)</translation>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Cancel Series Recording</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unknown</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>If no server is listed above, you may also enter the server URL manually:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Media Grid</source>
        <translation>Media Grid</translation>
        <extracomment>UI -&gt; Media Grid section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Media Grid options.</source>
        <translation>Media Grid options.</translation>
    </message>
    <message>
        <source>Always show the titles below the poster images. (If disabled, the title will be shown under the highlighted item only).</source>
        <translation>Always show the titles below the poster images. (If disabled, the title will be shown under the highlighted item only).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Show item count in the library and index of selected item.</source>
        <translation>Show item count in the library and index of selected item.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Use voice remote to search</source>
        <translation>Use voice remote to search</translation>
        <extracomment>Help text in search voice text box</extracomment>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation>Quick Connect</translation>
    </message>
    <message>
        <source>(Dialog will close automatically)</source>
        <translation>(Dialogue will close automatically)</translation>
    </message>
    <message>
        <source>Return to Top</source>
        <translation>Return to Top</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Max Days Next Up</source>
        <translation>Max Days Next Up</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it.</source>
        <translation>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Playback Information</source>
        <translation>Playback Information</translation>
    </message>
    <message>
        <source>Audio Codec</source>
        <translation>Audio Codec</translation>
    </message>
    <message>
        <source>Total Bitrate</source>
        <translation>Total Bitrate</translation>
    </message>
    <message>
        <source>Bit Rate</source>
        <translation>Bit Rate</translation>
        <extracomment>Video streaming bit rate</extracomment>
    </message>
    <message>
        <source>Pixel format</source>
        <translation>Pixel format</translation>
        <extracomment>Video pixel format</extracomment>
    </message>
    <message>
        <source>Unable to find any albums or songs belonging to this artist</source>
        <translation>Unable to find any albums or songs belonging to this artist</translation>
        <extracomment>Popup message when we find no audio data for an artist</extracomment>
    </message>
    <message>
        <source>Movies</source>
        <translation>Films</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Playback</source>
        <translation>Playback</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>User Interface</source>
        <translation>User Interface</translation>
        <extracomment>Title for User Interface section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Item Count</source>
        <translation>Item Count</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Count in user setting screen.</extracomment>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>Set Watched</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>Here is your Quick Connect code:</source>
        <translation>Here is your Quick Connect code:</translation>
    </message>
    <message>
        <source>Networks</source>
        <translation>Networks</translation>
    </message>
    <message>
        <source>Options that alter the design of WatchNexus.</source>
        <translation>Options that alter the design of WatchNexus.</translation>
        <extracomment>Description for Design Elements user settings.</extracomment>
    </message>
    <message>
        <source>Play Trailer</source>
        <translation>Play Trailer</translation>
    </message>
    <message>
        <source>Settings relating to playback and supported codec and media types.</source>
        <translation>Settings relating to playback and supported codec and media types.</translation>
    </message>
    <message>
        <source>Home Page</source>
        <translation>Home Page</translation>
    </message>
    <message>
        <source>Transcoding Information</source>
        <translation>Transcoding Information</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>Reason</translation>
    </message>
    <message>
        <source>Audio Channels</source>
        <translation>Audio Channels</translation>
    </message>
    <message>
        <source>Codec Support</source>
        <translation>Codec Support</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>MPEG-2</source>
        <translation>MPEG-2</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Enable or disable Direct Play for optional codecs</source>
        <translation>Enable or disable Direct Play for optional codecs</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Disabled</translation>
    </message>
    <message>
        <source>** EXPERIMENTAL** Support Direct Play of AV1 content if this Roku device supports it.</source>
        <translation>** EXPERIMENTAL** Support Direct Play of AV1 content if this Roku device supports it.</translation>
        <extracomment>Description of a setting - should we try to direct play experimental av1 codec</extracomment>
    </message>
    <message>
        <source>Item Titles</source>
        <translation>Item Titles</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>Set Favourite</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>Go to series</source>
        <translation>Go to series</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Series Detail Page</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation>Go to season</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>%1 of %2</source>
        <translation>%1 of %2</translation>
        <extracomment>Item position and count. %1 = current item. %2 = total number of items</extracomment>
    </message>
    <message>
        <source>There was an error authenticating via Quick Connect.</source>
        <translation>There was an error authenticating via Quick Connect.</translation>
    </message>
    <message>
        <source>Studios</source>
        <translation>Studios</translation>
    </message>
    <message>
        <source>Options for Details pages.</source>
        <translation>Options for Details pages.</translation>
        <extracomment>Description for Details page user settings.</extracomment>
    </message>
    <message>
        <source>Hide Taglines</source>
        <translation>Hide Taglines</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Hides tagline text on details pages.</source>
        <translation>Hides tagline text on details pages.</translation>
    </message>
    <message>
        <source>Options for TV Shows.</source>
        <translation>Options for TV Shows.</translation>
        <extracomment>Description for TV Shows user settings.</extracomment>
    </message>
    <message>
        <source>Skip Details for Single Seasons</source>
        <translation>Skip Details for Single Seasons</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Blur Unwatched Episodes</source>
        <translation>Blur Unwatched Episodes</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Cinema Mode brings the theater experience straight to your living room with the ability to play custom intros before the main feature.</source>
        <translation>Cinema Mode brings the cinema experience straight to your living room with the ability to play custom intros before the main feature.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Settings relating to how the application looks.</source>
        <translation>Settings relating to how the application looks.</translation>
    </message>
    <message>
        <source>Stream Information</source>
        <translation>Stream Information</translation>
    </message>
    <message>
        <source>Codec</source>
        <translation>Codec</translation>
    </message>
    <message>
        <source>Container</source>
        <translation>Container</translation>
        <extracomment>Video streaming container</extracomment>
    </message>
    <message>
        <source>Video range type</source>
        <translation>Video range type</translation>
    </message>
    <message>
        <source>Cinema Mode</source>
        <translation>Cinema Mode</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Use Splashscreen as Home Background</source>
        <translation>Use Splashscreen as Home Background</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Design Elements</source>
        <translation>Design Elements</translation>
    </message>
    <message>
        <source>Screensaver</source>
        <translation>Screensaver</translation>
    </message>
    <message>
        <source>Search now</source>
        <translation>Search now</translation>
        <extracomment>Help text in search Box</extracomment>
    </message>
    <message>
        <source>Go to episode</source>
        <translation>Go to episode</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Shows</source>
        <translation>Shows</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Enabled</translation>
    </message>
    <message>
        <source>Text Subtitles Only</source>
        <translation>Text Subtitles Only</translation>
        <extracomment>Name of a setting - should we hide subtitles that might transcode</extracomment>
    </message>
    <message>
        <source>Attempt Direct Play for H.264 media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation type="unfinished">Attempt Direct Play for H.264 media with unsupported profile levels before falling back to transcoding if it fails.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Next episode</source>
        <translation>Next episode</translation>
    </message>
    <message>
        <source>HEVC</source>
        <translation>HEVC</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>H.264</source>
        <translation type="unfinished">H.264</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Attempt Direct Play for H.264 media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation>Attempt Direct Play for H.264 media with unsupported profile levels before falling back to transcoding if it fails.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Attempt Direct Play for HEVC media with unsupported profile levels before falling back to trancoding if it fails.</source>
        <translation>Attempt Direct Play for HEVC media with unsupported profile levels before falling back to transcoding if it fails.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Only display text subtitles to minimize transcoding.</source>
        <translation>Only display text subtitles to minimise transcoding.</translation>
        <extracomment>Description of a setting - should we hide subtitles that might transcode</extracomment>
    </message>
    <message>
        <source>Aired</source>
        <translation>Aired</translation>
        <extracomment>Aired date label</extracomment>
    </message>
    <message>
        <source>Slideshow Off</source>
        <translation>Slideshow Off</translation>
    </message>
    <message>
        <source>Show What&apos;s New Popup</source>
        <translation>Show What&apos;s New Popup</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Show What&apos;s New popup when WatchNexus is updated to a new version.</source>
        <translation>Show What&apos;s New popup when WatchNexus is updated to a new version.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Unplayed</source>
        <translation>Unplayed</translation>
    </message>
    <message>
        <source>Resumable</source>
        <translation>Resumable</translation>
    </message>
    <message>
        <source>Slideshow On</source>
        <translation>Slideshow On</translation>
    </message>
    <message>
        <source>Slideshow Resumed</source>
        <translation>Slideshow Resumed</translation>
    </message>
    <message>
        <source>Random On</source>
        <translation>Random On</translation>
    </message>
    <message>
        <source>Random Off</source>
        <translation>Random Off</translation>
    </message>
    <message>
        <source>all</source>
        <translation>all</translation>
        <extracomment>all will reset the searchTerm so all data will be availible</extracomment>
    </message>
    <message>
        <source>Slideshow Paused</source>
        <translation>Slideshow Paused</translation>
    </message>
    <message>
        <source>MPEG-4 Support</source>
        <translation>MPEG-4 Support</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Played</source>
        <translation>Played</translation>
    </message>
    <message>
        <source>If enabled, the star and community rating for episodes of a TV show will be removed. This is to prevent spoilers of an upcoming good/bad episode.</source>
        <translation>If enabled, the star and community rating for episodes of a TV show will be removed. This is to prevent spoilers of an upcoming good/bad episode.</translation>
    </message>
    <message>
        <source>H.264</source>
        <translation>H.264</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Disable Community Rating for Episodes</source>
        <translation>Disable Community Rating for Episodes</translation>
    </message>
    <message>
        <source>View All</source>
        <translation>View All</translation>
    </message>
    <message>
        <source>Select when to show titles.</source>
        <translation>Select when to show titles.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Show On Hover</source>
        <translation>Show On Hover</translation>
    </message>
    <message>
        <source>Always Show</source>
        <translation>Always Show</translation>
    </message>
    <message>
        <source>Always Hide</source>
        <translation>Always Hide</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>Album</translation>
    </message>
    <message>
        <source>Artists (Grid)</source>
        <translation>Artists (Grid)</translation>
    </message>
    <message>
        <source>Song</source>
        <translation>Song</translation>
    </message>
    <message>
        <source>Artists (Presentation)</source>
        <translation>Artists (Presentation)</translation>
    </message>
    <message>
        <source>Songs</source>
        <translation>Songs</translation>
    </message>
    <message>
        <source>Albums</source>
        <translation>Albums</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Delete Saved</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>On Now</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Age</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Died</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>More Like This</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Born</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Special Features</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Save Credentials?</translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>Press &apos;OK&apos; to Close</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Cast &amp; Crew</translation>
    </message>
    <message>
        <source>Pick a WatchNexus server from the local network</source>
        <translation>Select an available WatchNexus server from your local network:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or IP address</source>
        <translation>Enter the server name or IP address</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>TV Shows</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Cancel Recording</translation>
    </message>
    <message>
        <source>Additional Parts</source>
        <translation>Additional Parts</translation>
        <extracomment>Additional parts of a video</extracomment>
    </message>
    <message>
        <source>View Channel</source>
        <translation>View Channel</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Record</translation>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Cancel Series Recording</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unknown</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Record Series</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Delete Saved</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Save Credentials?</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>On Now</translation>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>TV Shows</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Died</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>More Like This</translation>
    </message>
    <message>
        <source>Additional Parts</source>
        <translation>Additional Parts</translation>
        <extracomment>Additional parts of a video</extracomment>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Delete Saved</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Born</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Special Features</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Save Credentials?</translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>Press &apos;OK&apos; to Close</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Cast &amp; Crew</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Age</translation>
    </message>
    <message>
        <source>Pick a WatchNexus server from the local network</source>
        <translation>Select an available WatchNexus server from your local network:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Record</source>
        <translation>Record</translation>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Cancel Series Recording</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unknown</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Enter the server name or IP address</source>
        <translation>Enter the server name or IP address</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Cancel Recording</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>View Channel</translation>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>If no server is listed above, you may also enter the server URL manually:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Error Getting Playback Information</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Record Series</translation>
    </message>
    <message>
        <source>Set how many seconds before the end of an episode the Next Episode button should appear. Set to 0 to disable.</source>
        <translation>Set how many seconds before the end of an episode the Next Episode button should appear. Set to 0 to disable.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Age</source>
        <translation>Age</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Cast &amp; Crew</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Died</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>More Like This</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>On Now</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Age</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Died</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Delete Saved</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Born</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Save Credentials?</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>More Like This</translation>
    </message>
    <message>
        <source>Additional Parts</source>
        <translation>Additional Parts</translation>
        <extracomment>Additional parts of a video</extracomment>
    </message>
    <message>
        <source>Record</source>
        <translation>Record</translation>
    </message>
    <message>
        <source>Enter the server name or IP address</source>
        <translation>Enter the server name or IP address</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>If no server is listed above, you may also enter the server URL manually:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Error Getting Playback Information</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>An error was encountered while playing this item. Server did not provide required transcoding data.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>MPEG-4</source>
        <translation>MPEG-4</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Cancel Series Recording</translation>
    </message>
    <message>
        <source>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</source>
        <translation>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Support Direct Play of MPEG-4 content. This may need to be disabled for playback of DIVX encoded video files.</source>
        <translation>Support Direct Play of MPEG-4 content. This may need to be disabled for playback of DIVX encoded video files.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Media Grid</source>
        <translation>Media Grid</translation>
        <extracomment>UI -&gt; Media Grid section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Show item count in the library and index of selected item.</source>
        <translation>Show item count in the library and index of selected item.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Use voice remote to search</source>
        <translation>Use voice remote to search</translation>
        <extracomment>Help text in search voice text box</extracomment>
    </message>
    <message>
        <source>AV1</source>
        <translation>AV1</translation>
        <extracomment>Name of a setting - should we try to direct play experimental av1 codec</extracomment>
    </message>
    <message>
        <source>You can search for Titles, People, Live TV Channels and more</source>
        <translation>You can search for Titles, People, Live TV Channels and more</translation>
        <extracomment>Help text in search results</extracomment>
    </message>
    <message>
        <source>(Dialog will close automatically)</source>
        <translation>(Dialogue will close automatically)</translation>
    </message>
    <message>
        <source>Blur Unwatched Episodes</source>
        <translation>Blur Unwatched Episodes</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</source>
        <translation>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Options for TV Shows.</source>
        <translation>Options for TV Shows.</translation>
        <extracomment>Description for TV Shows user settings.</extracomment>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Cast &amp; Crew</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Special Features</translation>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>TV Shows</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unknown</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Pick a WatchNexus server from the local network</source>
        <translation>Select an available WatchNexus server from your local network:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Cancel Recording</translation>
    </message>
    <message>
        <source>If enabled, selecting a TV series with only one season will go straight to the episode list rather than the show details and season list.</source>
        <translation>If enabled, selecting a TV series with only one season will go straight to the episode list rather than the show details and season list.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Use generated splashscreen image as WatchNexus&apos;s screensaver background. WatchNexus will need to be closed and reopened for change to take effect.</source>
        <translation>Use generated splashscreen image as WatchNexus&apos;s screensaver background. WatchNexus will need to be closed and reopened for change to take effect.</translation>
    </message>
    <message>
        <source>Set how many seconds before the end of an episode the Next Episode button should appear. Set to 0 to disable.</source>
        <translation>Set how many seconds before the end of an episode the Next Episode button should appear. Set to 0 to disable.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation>Quick Connect</translation>
    </message>
    <message>
        <source>Return to Top</source>
        <translation>Return to Top</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Media Grid options.</source>
        <translation>Media Grid options.</translation>
    </message>
    <message>
        <source>Studios</source>
        <translation>Studios</translation>
    </message>
    <message>
        <source>Hides tagline text on details pages.</source>
        <translation>Hides tagline text on details pages.</translation>
    </message>
    <message>
        <source>If enabled, images of unwatched episodes will be blurred.</source>
        <translation>If enabled, images of unwatched episodes will be blurred.</translation>
    </message>
    <message>
        <source>Options for WatchNexus&apos;s screensaver.</source>
        <translation>Options for WatchNexus&apos;s screensaver.</translation>
        <extracomment>Description for Screensaver user settings.</extracomment>
    </message>
    <message>
        <source>Use Splashscreen as Screensaver</source>
        <translation>Use Splashscreen as Screensaver</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Record Series</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Playback</source>
        <translation>Playback</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>User Interface</source>
        <translation>User Interface</translation>
        <extracomment>Title for User Interface section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Item Count</source>
        <translation>Item Count</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Count in user setting screen.</extracomment>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>Set Watched</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>Here is your Quick Connect code:</source>
        <translation>Here is your Quick Connect code:</translation>
    </message>
    <message>
        <source>Networks</source>
        <translation>Networks</translation>
    </message>
    <message>
        <source>Codec Support</source>
        <translation>Codec Support</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>MPEG-2</source>
        <translation>MPEG-2</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>** EXPERIMENTAL** Support Direct Play of AV1 content if this Roku device supports it.</source>
        <translation>** EXPERIMENTAL** Support Direct Play of AV1 content if this Roku device supports it.</translation>
        <extracomment>Description of a setting - should we try to direct play experimental av1 codec</extracomment>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Disabled</translation>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>Set Favourite</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>Go to series</source>
        <translation>Go to series</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Series Detail Page</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation>Go to season</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>%1 of %2</source>
        <translation>%1 of %2</translation>
        <extracomment>Item position and count. %1 = current item. %2 = total number of items</extracomment>
    </message>
    <message>
        <source>There was an error authenticating via Quick Connect.</source>
        <translation>There was an error authenticating via Quick Connect.</translation>
    </message>
    <message>
        <source>Hide Taglines</source>
        <translation>Hide Taglines</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Skip Details for Single Seasons</source>
        <translation>Skip Details for Single Seasons</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>Press &apos;OK&apos; to Close</translation>
    </message>
    <message>
        <source>Screensaver</source>
        <translation>Screensaver</translation>
    </message>
    <message>
        <source>Search now</source>
        <translation>Search now</translation>
        <extracomment>Help text in search Box</extracomment>
    </message>
    <message>
        <source>Go to episode</source>
        <translation>Go to episode</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Shows</source>
        <translation>Shows</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Enabled</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Save Credentials?</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Age</translation>
    </message>
    <message>
        <source>Additional Parts</source>
        <translation>Additional Parts</translation>
        <extracomment>Additional parts of a video</extracomment>
    </message>
    <message>
        <source>On Now</source>
        <translation>On Now</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Cast &amp; Crew</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>More Like This</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Died</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Delete Saved</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Born</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Special Features</translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>Press &apos;OK&apos; to Close</translation>
    </message>
    <message>
        <source>Set how many seconds before the end of an episode the Next Episode button should appear. Set to 0 to disable.</source>
        <translation>Set how many seconds before the end of an episode the Next Episode button should appear. Set to 0 to disable.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Movies (Presentation)</source>
        <translation>Films (Presentation)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>Series</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Record</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Cancel Recording</translation>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation type="unfinished">Cancel Series Recording</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unknown</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Enter the server name or IP address</source>
        <translation>Enter the server name or IP address</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Error Getting Playback Information</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>An error was encountered while playing this item. Server did not provide required transcoding data.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Movies (Grid)</source>
        <translation>Films (Grid)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>View Channel</source>
        <translation>View Channel</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Films</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Record Series</translation>
    </message>
    <message>
        <source>Pick a WatchNexus server from the local network</source>
        <translation>Select an available WatchNexus server from your local network:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>If no server is listed above, you may also enter the server URL manually:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Playback</source>
        <translation>Playback</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Age</source>
        <translation>Age</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Died</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>On Now</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Delete Saved</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Born</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Save Credentials?</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>More Like This</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Cast &amp; Crew</translation>
    </message>
    <message>
        <source>Movies (Grid)</source>
        <translation>Movies (Grid)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>TV Shows</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>View Channel</translation>
    </message>
    <message>
        <source>Additional Parts</source>
        <translation>Additional Parts</translation>
        <extracomment>Additional parts of a video</extracomment>
    </message>
    <message>
        <source>Movies (Presentation)</source>
        <translation>Movies (Presentation)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Special Features</translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>Press &apos;OK&apos; to Close</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Record</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>An error was encountered while playing this item. Server did not provide required transcoding data.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Playback</source>
        <translation>Playback</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Cancel Series Recording</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unknown</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Cancel Recording</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Record Series</translation>
    </message>
    <message>
        <source>Enter the server name or IP address</source>
        <translation>Enter the server name or IP address</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>Pick a WatchNexus server from the local network</source>
        <translation>Select an available WatchNexus server from your local network:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>If no server is listed above, you may also enter the server URL manually:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Error Getting Playback Information</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>Codec Support</source>
        <translation>Codec Support</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>Enable or disable Direct Play for optional codecs</source>
        <translation>Enable or disable Direct Play for optional codecs</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</source>
        <translation>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>MPEG-4</source>
        <translation>MPEG-4</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>** EXPERIMENTAL** Support Direct Play of AV1 content if this Roku device supports it.</source>
        <translation>** EXPERIMENTAL** Support Direct Play of AV1 content if this Roku device supports it.</translation>
        <extracomment>Description of a setting - should we try to direct play experimental av1 codec</extracomment>
    </message>
    <message>
        <source>Show item count in the library and index of selected item.</source>
        <translation>Show item count in the library and index of the selected item.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>Set Watched</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>AV1</source>
        <translation>AV1</translation>
        <extracomment>Name of a setting - should we try to direct play experimental av1 codec</extracomment>
    </message>
    <message>
        <source>Media Grid options.</source>
        <translation>Media Grid options.</translation>
    </message>
    <message>
        <source>Support Direct Play of MPEG-4 content. This may need to be disabled for playback of DIVX encoded video files.</source>
        <translation>Support Direct Play of MPEG-4 content. This may need to be disabled for playback of DIVX encoded video files.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Media Grid</source>
        <translation>Media Grid</translation>
        <extracomment>UI -&gt; Media Grid section in user setting screen.</extracomment>
    </message>
    <message>
        <source>User Interface</source>
        <translation>User Interface</translation>
        <extracomment>Title for User Interface section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Item Count</source>
        <translation>Item Count</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Count in user setting screen.</extracomment>
    </message>
    <message>
        <source>MPEG-2</source>
        <translation>MPEG-2</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Disabled</translation>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>Set Favourite</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>Go to series</source>
        <translation>Go to series</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Series Detail Page</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation>Go to season</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>Go to episode</source>
        <translation>Go to episode</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Enabled</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>On Now</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Delete Saved</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Save Credentials?</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Age</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Died</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>More Like This</translation>
    </message>
    <message>
        <source>Additional Parts</source>
        <translation>Additional Parts</translation>
        <extracomment>Additional parts of a video</extracomment>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Cast &amp; Crew</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>On Now</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Delete Saved</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Born</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Special Features</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Save Credentials?</translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>Press &apos;OK&apos; to Close</translation>
    </message>
    <message>
        <source>The source file is entirely compatible with this client and the session is receiving the file without modifications.</source>
        <translation>The source file is entirely compatible with this client and the session is receiving the file without modifications.</translation>
        <extracomment>Direct play info box text in GetPlaybackInfoTask.brs</extracomment>
    </message>
    <message>
        <source>Movies (Grid)</source>
        <translation>Movies (Grid)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>TV Shows</translation>
    </message>
    <message>
        <source>Movies (Presentation)</source>
        <translation>Movies (Presentation)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>Movies</source>
        <translation>Movies</translation>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>If no server is listed above, you may also enter the server URL manually:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Replace Roku&apos;s default subtitle functions with custom functions that support CJK fonts. Fallback fonts must be configured and enabled on the server for CJK rendering to work.</source>
        <translation>Replace Roku&apos;s default subtitle functions with custom functions that support CJK fonts. Fallback fonts must be configured and enabled on the server for CJK rendering to work.</translation>
        <extracomment>Description of a setting - custom subtitles that support CJK fonts</extracomment>
    </message>
    <message>
        <source>Settings that apply when Grid views are enabled.</source>
        <translation>Settings that apply when Grid views are enabled.</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of pages in Movie Libraries.</source>
        <translation>Settings relating to the appearance of pages in Movie Libraries.</translation>
    </message>
    <message>
        <source>Set how many seconds before the end of an episode the Next Episode button should appear. Set to 0 to disable.</source>
        <translation>Set how many seconds before the end of an episode the Next Episode button should appear. Set to 0 to disable.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unknown</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Pick a WatchNexus server from the local network</source>
        <translation>Select an available WatchNexus server from your local network:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Slideshow Off</source>
        <translation>Slideshow Off</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>An error was encountered while playing this item. Server did not provide required transcoding data.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Aired</source>
        <translation>Aired</translation>
        <extracomment>Aired date label</extracomment>
    </message>
    <message>
        <source>Select when to show titles.</source>
        <translation>Select when to show titles.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Use voice remote to search</source>
        <translation>Use voice remote to search</translation>
        <extracomment>Help text in search voice text box</extracomment>
    </message>
    <message>
        <source>Blur Unwatched Episodes</source>
        <translation>Blur Unwatched Episodes</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Song</source>
        <translation>Song</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>View Channel</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Record</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Cancel Recording</translation>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Error Getting Playback Information</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>Playback</source>
        <translation>Playback</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Album Artists (Presentation)</source>
        <translation>Album Artists (Presentation)</translation>
    </message>
    <message>
        <source>Album Artists (Grid)</source>
        <translation>Album Artists (Grid)</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>Album</translation>
    </message>
    <message>
        <source>Albums</source>
        <translation>Albums</translation>
    </message>
    <message>
        <source>View All</source>
        <translation>View All</translation>
    </message>
    <message>
        <source>Disable Community Rating for Episodes</source>
        <translation>Disable Community Rating for Episodes</translation>
    </message>
    <message>
        <source>Hide the star and community rating for episodes of a TV show. This is to prevent spoilers of an upcoming good/bad episode.</source>
        <translation>Hide the star and community rating for episodes of a TV show. This is to prevent spoilers of an upcoming good/bad episode.</translation>
    </message>
    <message>
        <source>Biographical information for this person is not currently available.</source>
        <translation>Biographical information for this person is not currently available.</translation>
    </message>
    <message>
        <source>Maximum Bitrate</source>
        <translation>Maximum Bitrate</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of the Home screen and the program in general.</source>
        <translation>Settings relating to the appearance of the Home screen and the program in general.</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation>Grid</translation>
        <extracomment>Title of an option - name of grid view</extracomment>
    </message>
    <message>
        <source>Disable Unwatched Episode Count</source>
        <translation>Disable Unwatched Episode Count</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Video Codec</source>
        <translation>Video Codec</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Size</translation>
        <extracomment>Video size</extracomment>
    </message>
    <message>
        <source>Enable or disable the &apos;Maximum Bitrate&apos; setting.</source>
        <translation>Enable or disable the &apos;Maximum Bitrate&apos; setting.</translation>
    </message>
    <message>
        <source>Options for TV Shows.</source>
        <translation>Options for TV Shows.</translation>
        <extracomment>Description for TV Shows user settings.</extracomment>
    </message>
    <message>
        <source>Codec Tag</source>
        <translation>Codec Tag</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Libraries</source>
        <translation>Libraries</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of Library pages</source>
        <translation>Settings relating to the appearance of Library pages</translation>
    </message>
    <message>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <source>Loading trailer</source>
        <translation>Loading trailer</translation>
        <extracomment>Dialog title in Main.brs</extracomment>
    </message>
    <message>
        <source>(Dialog will close automatically)</source>
        <translation>(Dialog will close automatically)</translation>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation>Quick Connect</translation>
    </message>
    <message>
        <source>Return to Top</source>
        <translation>Return to Top</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Max Days Next Up</source>
        <translation>Max Days Next Up</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Pixel format</source>
        <translation>Pixel format</translation>
        <extracomment>Video pixel format</extracomment>
    </message>
    <message>
        <source>Bit Rate</source>
        <translation>Bit Rate</translation>
        <extracomment>Video streaming bit rate</extracomment>
    </message>
    <message>
        <source>Unplayed</source>
        <translation>Unplayed</translation>
    </message>
    <message>
        <source>Media Grid options.</source>
        <translation>Media Grid options.</translation>
    </message>
    <message>
        <source>Studios</source>
        <translation>Studios</translation>
    </message>
    <message>
        <source>Hides tagline text on details pages.</source>
        <translation>Hides tagline text on details pages.</translation>
    </message>
    <message>
        <source>Use generated splashscreen image as WatchNexus&apos;s home background. WatchNexus will need to be closed and reopened for change to take effect.</source>
        <translation>Use generated splashscreen image as WatchNexus&apos;s home background. WatchNexus will need to be closed and reopened for change to take effect.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Hide Clock</source>
        <translation>Hide Clock</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>WxH</source>
        <translation>WxH</translation>
        <extracomment>Video width x height</extracomment>
    </message>
    <message>
        <source>Default view for Movie Libraries.</source>
        <translation>Default view for Movie Libraries.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Show On Hover</source>
        <translation>Show On Hover</translation>
    </message>
    <message>
        <source>Grid View Settings</source>
        <translation>Grid View Settings</translation>
    </message>
    <message>
        <source>Presentation</source>
        <translation>Presentation</translation>
        <extracomment>Title of an option - name of presentation view</extracomment>
    </message>
    <message>
        <source>Next Episode Button Time</source>
        <translation>Next Episode Button Time</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Record Series</translation>
    </message>
    <message>
        <source>Support Direct Play of MPEG-4 content. This may need to be disabled for playback of DIVX encoded video files.</source>
        <translation>Support Direct Play of MPEG-4 content. This may need to be disabled for playback of DIVX encoded video files.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Media Grid</source>
        <translation>Media Grid</translation>
        <extracomment>UI -&gt; Media Grid section in user setting screen.</extracomment>
    </message>
    <message>
        <source>You can search for Titles, People, Live TV Channels and more</source>
        <translation>You can search for Titles, People, Live TV Channels and more</translation>
        <extracomment>Help text in search results</extracomment>
    </message>
    <message>
        <source>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</source>
        <translation>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Go directly to the episode list if a TV series has only one season.</source>
        <translation>Go directly to the episode list if a TV series has only one season.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Blur images of unwatched episodes.</source>
        <translation>Blur images of unwatched episodes.</translation>
    </message>
    <message>
        <source>Bring the theater experience straight to your living room with the ability to play custom intros before the main feature.</source>
        <translation>Bring the theater experience straight to your living room with the ability to play custom intros before the main feature.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>User Interface</source>
        <translation>User Interface</translation>
        <extracomment>Title for User Interface section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Hide all clocks in WatchNexus. WatchNexus will need to be closed and reopened for changes to take effect.</source>
        <translation>Hide all clocks in WatchNexus. WatchNexus will need to be closed and reopened for changes to take effect.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Attempt Direct Play for H.264 media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation>Attempt Direct Play for H.264 media with unsupported profile levels before falling back to transcoding if it fails.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Attempt Direct Play for HEVC media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation>Attempt Direct Play for HEVC media with unsupported profile levels before falling back to transcoding if it fails.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Item Count</source>
        <translation>Item Count</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Count in user setting screen.</extracomment>
    </message>
    <message>
        <source>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it.</source>
        <translation>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Playback Information</source>
        <translation>Playback Information</translation>
    </message>
    <message>
        <source>Transcoding Information</source>
        <translation>Transcoding Information</translation>
    </message>
    <message>
        <source>Audio Codec</source>
        <translation>Audio Codec</translation>
    </message>
    <message>
        <source>direct</source>
        <translation>direct</translation>
    </message>
    <message>
        <source>Total Bitrate</source>
        <translation>Total Bitrate</translation>
    </message>
    <message>
        <source>Codec</source>
        <translation>Codec</translation>
    </message>
    <message>
        <source>Level</source>
        <translation>Level</translation>
        <extracomment>Video profile level</extracomment>
    </message>
    <message>
        <source>Unable to find any albums or songs belonging to this artist</source>
        <translation>Unable to find any albums or songs belonging to this artist</translation>
        <extracomment>Popup message when we find no audio data for an artist</extracomment>
    </message>
    <message>
        <source>Custom Subtitles</source>
        <translation>Custom Subtitles</translation>
        <extracomment>Name of a setting - custom subtitles that support CJK fonts</extracomment>
    </message>
    <message>
        <source>Text Subtitles Only</source>
        <translation>Text Subtitles Only</translation>
        <extracomment>Name of a setting - should we hide subtitles that might transcode</extracomment>
    </message>
    <message>
        <source>Only display text subtitles to minimize transcoding.</source>
        <translation>Only display text subtitles to minimize transcoding.</translation>
        <extracomment>Description of a setting - should we hide subtitles that might transcode</extracomment>
    </message>
    <message>
        <source>Here is your Quick Connect code:</source>
        <translation>Here is your Quick Connect code:</translation>
    </message>
    <message>
        <source>Random On</source>
        <translation>Random On</translation>
    </message>
    <message>
        <source>Networks</source>
        <translation>Networks</translation>
    </message>
    <message>
        <source>MPEG-4 Support</source>
        <translation>MPEG-4 Support</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Parental Ratings</source>
        <translation>Parental Ratings</translation>
        <extracomment>Used in Filter menu</extracomment>
    </message>
    <message>
        <source>Years</source>
        <translation>Years</translation>
        <extracomment>Used in Filter menu</extracomment>
    </message>
    <message>
        <source>Show What&apos;s New Popup</source>
        <translation>Show What&apos;s New Popup</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Show What&apos;s New popup when WatchNexus is updated to a new version.</source>
        <translation>Show What&apos;s New popup when WatchNexus is updated to a new version.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Played</source>
        <translation>Played</translation>
    </message>
    <message>
        <source>Resumable</source>
        <translation>Resumable</translation>
    </message>
    <message>
        <source>Movie Library Default View</source>
        <translation>Movie Library Default View</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Item Titles</source>
        <translation>Item Titles</translation>
        <extracomment>Title of a setting - when should we show the title text of a grid item</extracomment>
    </message>
    <message>
        <source>Always Show</source>
        <translation>Always Show</translation>
    </message>
    <message>
        <source>Always Hide</source>
        <translation>Always Hide</translation>
    </message>
    <message>
        <source>Artists (Presentation)</source>
        <translation>Artists (Presentation)</translation>
    </message>
    <message>
        <source>Songs</source>
        <translation>Songs</translation>
    </message>
    <message>
        <source>Configure the maximum playback bitrate.</source>
        <translation>Configure the maximum playback bitrate.</translation>
    </message>
    <message>
        <source>Enable Limit</source>
        <translation>Enable Limit</translation>
    </message>
    <message>
        <source>Bitrate Limit</source>
        <translation>Bitrate Limit</translation>
    </message>
    <message>
        <source>Set the maximum bitrate in Mbps. Set to 0 to use Roku&apos;s specifications. This setting must be enabled to take effect.</source>
        <translation>Set the maximum bitrate in Mbps. Set to 0 to use Roku&apos;s specifications. This setting must be enabled to take effect.</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of pages in TV Libraries.</source>
        <translation>Settings relating to the appearance of pages in TV Libraries.</translation>
    </message>
    <message>
        <source>If enabled, the number of unwatched episodes in a series/season will be removed.</source>
        <translation>If enabled, the number of unwatched episodes in a series/season will be removed.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Options that alter the design of WatchNexus.</source>
        <translation>Options that alter the design of WatchNexus.</translation>
        <extracomment>Description for Design Elements user settings.</extracomment>
    </message>
    <message>
        <source>Next episode</source>
        <translation>Next episode</translation>
    </message>
    <message>
        <source>Play Trailer</source>
        <translation>Play Trailer</translation>
    </message>
    <message>
        <source>Settings relating to playback and supported codec and media types.</source>
        <translation>Settings relating to playback and supported codec and media types.</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>Reason</translation>
    </message>
    <message>
        <source>Audio Channels</source>
        <translation>Audio Channels</translation>
    </message>
    <message>
        <source>Slideshow On</source>
        <translation>Slideshow On</translation>
    </message>
    <message>
        <source>Slideshow Resumed</source>
        <translation>Slideshow Resumed</translation>
    </message>
    <message>
        <source>Random Off</source>
        <translation>Random Off</translation>
    </message>
    <message>
        <source>Artists (Grid)</source>
        <translation>Artists (Grid)</translation>
    </message>
    <message>
        <source>Codec Support</source>
        <translation>Codec Support</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>MPEG-2</source>
        <translation>MPEG-2</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Disabled</translation>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>Set Favorite</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>Go to series</source>
        <translation>Go to series</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Series Detail Page</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation>Go to season</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>%1 of %2</source>
        <translation>%1 of %2</translation>
        <extracomment>Item position and count. %1 = current item. %2 = total number of items</extracomment>
    </message>
    <message>
        <source>There was an error authenticating via Quick Connect.</source>
        <translation>There was an error authenticating via Quick Connect.</translation>
    </message>
    <message>
        <source>Hide Taglines</source>
        <translation>Hide Taglines</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Skip Details for Single Seasons</source>
        <translation>Skip Details for Single Seasons</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>HEVC</source>
        <translation>HEVC</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>H.264</source>
        <translation>H.264</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Settings relating to how the application looks.</source>
        <translation>Settings relating to how the application looks.</translation>
    </message>
    <message>
        <source>Stream Information</source>
        <translation>Stream Information</translation>
    </message>
    <message>
        <source>Video range type</source>
        <translation>Video range type</translation>
    </message>
    <message>
        <source>Container</source>
        <translation>Container</translation>
        <extracomment>Video streaming container</extracomment>
    </message>
    <message>
        <source>all</source>
        <translation>all</translation>
        <extracomment>all will reset the searchTerm so all data will be availible</extracomment>
    </message>
    <message>
        <source>Slideshow Paused</source>
        <translation>Slideshow Paused</translation>
    </message>
    <message>
        <source>Cinema Mode</source>
        <translation>Cinema Mode</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Use Splashscreen as Home Background</source>
        <translation>Use Splashscreen as Home Background</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Design Elements</source>
        <translation>Design Elements</translation>
    </message>
    <message>
        <source>Search now</source>
        <translation>Search now</translation>
        <extracomment>Help text in search Box</extracomment>
    </message>
    <message>
        <source>Go to episode</source>
        <translation>Go to episode</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Shows</source>
        <translation>Shows</translation>
    </message>
    <message>
        <source>Enable or disable Direct Play for optional codecs</source>
        <translation>Enable or disable Direct Play for optional codecs</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</source>
        <translation>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>MPEG-4</source>
        <translation>MPEG-4</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>** EXPERIMENTAL** Support Direct Play of AV1 content if this Roku device supports it.</source>
        <translation>** EXPERIMENTAL** Support Direct Play of AV1 content if this Roku device supports it.</translation>
        <extracomment>Description of a setting - should we try to direct play experimental av1 codec</extracomment>
    </message>
    <message>
        <source>Show item count in the library and index of selected item.</source>
        <translation>Show item count in the library and index of selected item.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>Set Watched</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>AV1</source>
        <translation>AV1</translation>
        <extracomment>Name of a setting - should we try to direct play experimental av1 codec</extracomment>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Enabled</translation>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Cancel Series Recording</translation>
    </message>
    <message>
        <source>Enter the server name or IP address</source>
        <translation>Enter the server name or IP address</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>Direct playing</source>
        <translation>Direct playing</translation>
    </message>
    <message>
        <source>Additional Parts</source>
        <translation>Additional Parts</translation>
        <extracomment>Additional parts of a video</extracomment>
    </message>
    <message>
        <source>Movies (Grid)</source>
        <translation>Movies (Grid)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>TV Shows</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>View Channel</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unknown</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Pick a WatchNexus server from the local network</source>
        <translation>Select an available WatchNexus server from your local network:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>If no server is listed above, you may also enter the server URL manually:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Grid</source>
        <translation>Grid</translation>
        <extracomment>Title of an option - name of grid view</extracomment>
    </message>
    <message>
        <source>Disable Unwatched Episode Count</source>
        <translation>Disable Unwatched Episode Count</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Error Getting Playback Information</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>Slideshow Off</source>
        <translation>Slideshow Off</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>An error was encountered while playing this item. Server did not provide required transcoding data.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Media Grid options.</source>
        <translation>Media Grid options.</translation>
    </message>
    <message>
        <source>Show item count in the library and index of selected item.</source>
        <translation>Show item count in the library and index of selected item.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation>Quick Connect</translation>
    </message>
    <message>
        <source>Options for TV Shows.</source>
        <translation>Options for TV Shows.</translation>
        <extracomment>Description for TV Shows user settings.</extracomment>
    </message>
    <message>
        <source>Use voice remote to search</source>
        <translation>Use voice remote to search</translation>
        <extracomment>Help text in search voice text box</extracomment>
    </message>
    <message>
        <source>Use generated splashscreen image as WatchNexus&apos;s home background. WatchNexus will need to be closed and reopened for change to take effect.</source>
        <translation>Use generated splashscreen image as WatchNexus&apos;s home background. WatchNexus will need to be closed and reopened for change to take effect.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Bring the theater experience straight to your living room with the ability to play custom intros before the main feature.</source>
        <translation>Bring the theatre experience straight to your living room with the ability to play custom intros before the main feature.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Hide Clock</source>
        <translation>Hide Clock</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Attempt Direct Play for H.264 media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation>Attempt Direct Play for H.264 media with unsupported profile levels before falling back to transcoding if it fails.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Attempt Direct Play for HEVC media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation>Attempt Direct Play for HEVC media with unsupported profile levels before falling back to transcoding if it fails.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Video Codec</source>
        <translation>Video Codec</translation>
    </message>
    <message>
        <source>Bit Rate</source>
        <translation>Bit Rate</translation>
        <extracomment>Video streaming bit rate</extracomment>
    </message>
    <message>
        <source>Replace Roku&apos;s default subtitle functions with custom functions that support CJK fonts. Fallback fonts must be configured and enabled on the server for CJK rendering to work.</source>
        <translation>Replace Roku&apos;s default subtitle functions with custom functions that support CJK fonts. Fallback fonts must be configured and enabled on the server for CJK rendering to work.</translation>
        <extracomment>Description of a setting - custom subtitles that support CJK fonts</extracomment>
    </message>
    <message>
        <source>Item Titles</source>
        <translation>Item Titles</translation>
        <extracomment>Title of a setting - when should we show the title text of a grid item</extracomment>
    </message>
    <message>
        <source>Disable Community Rating for Episodes</source>
        <translation>Disable Community Rating for Episodes</translation>
    </message>
    <message>
        <source>Biographical information for this person is not currently available.</source>
        <translation>Biographical information for this person is not currently available.</translation>
    </message>
    <message>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of the Home screen and the program in general.</source>
        <translation>Settings relating to the appearance of the Home screen and the program in general.</translation>
    </message>
    <message>
        <source>If enabled, the number of unwatched episodes in a series/season will be removed.</source>
        <translation>If enabled, the number of unwatched episodes in a series/season will be removed.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Age</source>
        <translation>Age</translation>
    </message>
    <message>
        <source>The source file is entirely compatible with this client and the session is receiving the file without modifications.</source>
        <translation>The source file is entirely compatible with this client and the session is receiving the file without modifications.</translation>
        <extracomment>Direct play info box text in GetPlaybackInfoTask.brs</extracomment>
    </message>
    <message>
        <source>Configure the maximum resolution when playing video files on this device.</source>
        <translation>Configure the maximum resolution when playing video files on this device.</translation>
        <extracomment>User Setting - Description</extracomment>
    </message>
    <message>
        <source>Apply max resolution to all files or only transcoded files.</source>
        <translation>Apply max resolution to all files or only transcoded files.</translation>
        <extracomment>User Setting - Description</extracomment>
    </message>
    <message>
        <source>All files</source>
        <translation>All files</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Only transcoded files</source>
        <translation>Only transcoded files</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Compatibility</source>
        <translation>Compatibility</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Choose your preferred audio codec when transcoding multichannel audio.</source>
        <translation>Choose your preferred audio codec when transcoding multichannel audio.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Died</source>
        <translation>Died</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Cancel Recording</translation>
    </message>
    <message>
        <source>Playback</source>
        <translation>Playback</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Album Artists (Presentation)</source>
        <translation>Album Artists (Presentation)</translation>
    </message>
    <message>
        <source>Force all transcodes to use DTS instead of the default EAC3. The device must support DTS for this setting to have an effect.</source>
        <translation>Force all transcodes to use DTS instead of the default EAC3. The device must support DTS for this setting to have an effect.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Audio Codec Support</source>
        <translation>Audio Codec Support</translation>
        <extracomment>Settings Menu - Title of option</extracomment>
    </message>
    <message>
        <source>Set the maximum resolution when playing video files on this device.</source>
        <translation>Set the maximum resolution when playing video files on this device.</translation>
        <extracomment>User Setting - Description</extracomment>
    </message>
    <message>
        <source>MPEG-4</source>
        <translation>MPEG-4</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Movies (Presentation)</source>
        <translation>Movies (Presentation)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>Codec Tag</source>
        <translation>Codec Tag</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Cast &amp; Crew</translation>
    </message>
    <message>
        <source>Extras</source>
        <translation>Extras</translation>
    </message>
    <message>
        <source>Episodes</source>
        <translation>Episodes</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>More Like This</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Record</translation>
    </message>
    <message>
        <source>Studios</source>
        <translation>Studios</translation>
    </message>
    <message>
        <source>Blur Unwatched Episodes</source>
        <translation>Blur Unwatched Episodes</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Size</source>
        <translation>Size</translation>
        <extracomment>Video size</extracomment>
    </message>
    <message>
        <source>Pixel format</source>
        <translation>Pixel format</translation>
        <extracomment>Video pixel format</extracomment>
    </message>
    <message>
        <source>WxH</source>
        <translation>WxH</translation>
        <extracomment>Video width x height</extracomment>
    </message>
    <message>
        <source>Aired</source>
        <translation>Aired</translation>
        <extracomment>Aired date label</extracomment>
    </message>
    <message>
        <source>Unplayed</source>
        <translation>Unplayed</translation>
    </message>
    <message>
        <source>Default view for Movie Libraries.</source>
        <translation>Default view for Movie Libraries.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Select when to show titles.</source>
        <translation>Select when to show titles.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>View All</source>
        <translation>View All</translation>
    </message>
    <message>
        <source>Enable or disable the &apos;Maximum Bitrate&apos; setting.</source>
        <translation>Enable or disable the &apos;Maximum Bitrate&apos; setting.</translation>
    </message>
    <message>
        <source>Maximum Bitrate</source>
        <translation>Maximum Bitrate</translation>
    </message>
    <message>
        <source>Libraries</source>
        <translation>Libraries</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of pages in Movie Libraries.</source>
        <translation>Settings relating to the appearance of pages in Movie Libraries.</translation>
    </message>
    <message>
        <source>Loading trailer</source>
        <translation>Loading trailer</translation>
        <extracomment>Dialog title in Main.brs</extracomment>
    </message>
    <message>
        <source>Mode</source>
        <translation>Mode</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Attempt to prevent playback failures.</source>
        <translation>Attempt to prevent playback failures.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Disable HEVC</source>
        <translation>Disable HEVC</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>(Dialog will close automatically)</source>
        <translation>(Dialog will close automatically)</translation>
    </message>
    <message>
        <source>Return to Top</source>
        <translation>Return to Top</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Hides tagline text on details pages.</source>
        <translation>Hides tagline text on details pages.</translation>
    </message>
    <message>
        <source>Show On Hover</source>
        <translation>Show On Hover</translation>
    </message>
    <message>
        <source>Grid View Settings</source>
        <translation>Grid View Settings</translation>
    </message>
    <message>
        <source>Presentation</source>
        <translation>Presentation</translation>
        <extracomment>Title of an option - name of presentation view</extracomment>
    </message>
    <message>
        <source>On Now</source>
        <translation>On Now</translation>
    </message>
    <message>
        <source>Next Episode Button Time</source>
        <translation>Next Episode Button Time</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Movies</source>
        <translation>Movies</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Delete Saved</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Born</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Special Features</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Record Series</translation>
    </message>
    <message>
        <source>Support Direct Play of MPEG-4 content. This may need to be disabled for playback of DIVX encoded video files.</source>
        <translation>Support Direct Play of MPEG-4 content. This may need to be disabled for playback of DIVX encoded video files.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Media Grid</source>
        <translation>Media Grid</translation>
        <extracomment>UI -&gt; Media Grid section in user setting screen.</extracomment>
    </message>
    <message>
        <source>You can search for Titles, People, Live TV Channels and more</source>
        <translation>You can search for Titles, People, Live TV Channels and more</translation>
        <extracomment>Help text in search results</extracomment>
    </message>
    <message>
        <source>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</source>
        <translation>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Go directly to the episode list if a TV series has only one season.</source>
        <translation>Go directly to the episode list if a TV series has only one season.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Blur images of unwatched episodes.</source>
        <translation>Blur images of unwatched episodes.</translation>
    </message>
    <message>
        <source>User Interface</source>
        <translation>User Interface</translation>
        <extracomment>Title for User Interface section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Item Count</source>
        <translation>Item Count</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Count in user setting screen.</extracomment>
    </message>
    <message>
        <source>Playback Information</source>
        <translation>Playback Information</translation>
    </message>
    <message>
        <source>Audio Codec</source>
        <translation>Audio Codec</translation>
    </message>
    <message>
        <source>direct</source>
        <translation>direct</translation>
    </message>
    <message>
        <source>Total Bitrate</source>
        <translation>Total Bitrate</translation>
    </message>
    <message>
        <source>Codec</source>
        <translation>Codec</translation>
    </message>
    <message>
        <source>Unable to find any albums or songs belonging to this artist</source>
        <translation>Unable to find any albums or songs belonging to this artist</translation>
        <extracomment>Popup message when we find no audio data for an artist</extracomment>
    </message>
    <message>
        <source>Text Subtitles Only</source>
        <translation>Text Subtitles Only</translation>
        <extracomment>Name of a setting - should we hide subtitles that might transcode</extracomment>
    </message>
    <message>
        <source>Here is your Quick Connect code:</source>
        <translation>Here is your Quick Connect code:</translation>
    </message>
    <message>
        <source>Networks</source>
        <translation>Networks</translation>
    </message>
    <message>
        <source>Parental Ratings</source>
        <translation>Parental Ratings</translation>
        <extracomment>Used in Filter menu</extracomment>
    </message>
    <message>
        <source>Years</source>
        <translation>Years</translation>
        <extracomment>Used in Filter menu</extracomment>
    </message>
    <message>
        <source>Show What&apos;s New Popup</source>
        <translation>Show What&apos;s New Popup</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Played</source>
        <translation>Played</translation>
    </message>
    <message>
        <source>Show What&apos;s New popup when WatchNexus is updated to a new version.</source>
        <translation>Show What&apos;s New popup when WatchNexus is updated to a new version.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Resumable</source>
        <translation>Resumable</translation>
    </message>
    <message>
        <source>Movie Library Default View</source>
        <translation>Movie Library Default View</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Songs</source>
        <translation>Songs</translation>
    </message>
    <message>
        <source>Configure the maximum playback bitrate.</source>
        <translation>Configure the maximum playback bitrate.</translation>
    </message>
    <message>
        <source>Enable Limit</source>
        <translation>Enable Limit</translation>
    </message>
    <message>
        <source>Bitrate Limit</source>
        <translation>Bitrate Limit</translation>
    </message>
    <message>
        <source>Set the maximum bitrate in Mbps. Set to 0 to use Roku&apos;s specifications. This setting must be enabled to take effect.</source>
        <translation>Set the maximum bitrate in Mbps. Set to 0 to use Roku&apos;s specifications. This setting must be enabled to take effect.</translation>
    </message>
    <message>
        <source>Options that alter the design of WatchNexus.</source>
        <translation>Options that alter the design of WatchNexus.</translation>
        <extracomment>Description for Design Elements user settings.</extracomment>
    </message>
    <message>
        <source>Next episode</source>
        <translation>Next episode</translation>
    </message>
    <message>
        <source>Play Trailer</source>
        <translation>Play Trailer</translation>
    </message>
    <message>
        <source>Settings relating to playback and supported codec and media types.</source>
        <translation>Settings relating to playback and supported codec and media types.</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>Reason</translation>
    </message>
    <message>
        <source>Audio Channels</source>
        <translation>Audio Channels</translation>
    </message>
    <message>
        <source>Slideshow On</source>
        <translation>Slideshow On</translation>
    </message>
    <message>
        <source>Slideshow Resumed</source>
        <translation>Slideshow Resumed</translation>
    </message>
    <message>
        <source>Random Off</source>
        <translation>Random Off</translation>
    </message>
    <message>
        <source>Artists (Grid)</source>
        <translation>Artists (Grid)</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Save Credentials?</translation>
    </message>
    <message>
        <source>Codec Support</source>
        <translation>Codec Support</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>MPEG-2</source>
        <translation>MPEG-2</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Disabled</translation>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>Set Favourite</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>Go to series</source>
        <translation>Go to series</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Series Detail Page</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation>Go to season</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>%1 of %2</source>
        <translation>%1 of %2</translation>
        <extracomment>Item position and count. %1 = current item. %2 = total number of items</extracomment>
    </message>
    <message>
        <source>There was an error authenticating via Quick Connect.</source>
        <translation>There was an error authenticating via Quick Connect.</translation>
    </message>
    <message>
        <source>Hide Taglines</source>
        <translation>Hide Taglines</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Skip Details for Single Seasons</source>
        <translation>Skip Details for Single Seasons</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>HEVC</source>
        <translation>HEVC</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>H.264</source>
        <translation>H.264</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Settings relating to how the application looks.</source>
        <translation>Settings relating to how the application looks.</translation>
    </message>
    <message>
        <source>Stream Information</source>
        <translation>Stream Information</translation>
    </message>
    <message>
        <source>Video range type</source>
        <translation>Video range type</translation>
    </message>
    <message>
        <source>Container</source>
        <translation>Container</translation>
        <extracomment>Video streaming container</extracomment>
    </message>
    <message>
        <source>all</source>
        <translation>all</translation>
        <extracomment>all will reset the searchTerm so all data will be availible</extracomment>
    </message>
    <message>
        <source>Slideshow Paused</source>
        <translation>Slideshow Paused</translation>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>Set Watched</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>Hide all clocks in WatchNexus. WatchNexus will need to be closed and reopened for changes to take effect.</source>
        <translation>Hide all clocks in WatchNexus. WatchNexus will need to be closed and reopened for changes to take effect.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it.</source>
        <translation>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Max Days Next Up</source>
        <translation>Max Days Next Up</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Level</source>
        <translation>Level</translation>
        <extracomment>Video profile level</extracomment>
    </message>
    <message>
        <source>Custom Subtitles</source>
        <translation>Custom Subtitles</translation>
        <extracomment>Name of a setting - custom subtitles that support CJK fonts</extracomment>
    </message>
    <message>
        <source>Transcoding Information</source>
        <translation>Transcoding Information</translation>
    </message>
    <message>
        <source>Random On</source>
        <translation>Random On</translation>
    </message>
    <message>
        <source>MPEG-4 Support</source>
        <translation>MPEG-4 Support</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Always Show</source>
        <translation>Always Show</translation>
    </message>
    <message>
        <source>Only display text subtitles to minimize transcoding.</source>
        <translation>Only display text subtitles to minimise transcoding.</translation>
        <extracomment>Description of a setting - should we hide subtitles that might transcode</extracomment>
    </message>
    <message>
        <source>Artists (Presentation)</source>
        <translation>Artists (Presentation)</translation>
    </message>
    <message>
        <source>Album Artists (Grid)</source>
        <translation>Album Artists (Grid)</translation>
    </message>
    <message>
        <source>Song</source>
        <translation>Song</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>Album</translation>
    </message>
    <message>
        <source>Always Hide</source>
        <translation>Always Hide</translation>
    </message>
    <message>
        <source>Albums</source>
        <translation>Albums</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of Library pages</source>
        <translation>Settings relating to the appearance of Library pages</translation>
    </message>
    <message>
        <source>Settings that apply when Grid views are enabled.</source>
        <translation>Settings that apply when Grid views are enabled.</translation>
    </message>
    <message>
        <source>Hide the star and community rating for episodes of a TV show. This is to prevent spoilers of an upcoming good/bad episode.</source>
        <translation>Hide the star and community rating for episodes of a TV show. This is to prevent spoilers of an upcoming good/bad episode.</translation>
    </message>
    <message>
        <source>Set how many seconds before the end of an episode the Next Episode button should appear. Set to 0 to disable.</source>
        <translation>Set how many seconds before the end of an episode the Next Episode button should appear. Set to 0 to disable.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Settings relating to the appearance of pages in TV Libraries.</source>
        <translation>Settings relating to the appearance of pages in TV Libraries.</translation>
    </message>
    <message>
        <source>Maximum Resolution</source>
        <translation>Maximum Resolution</translation>
        <extracomment>User Setting - Title</extracomment>
    </message>
    <message>
        <source>Value</source>
        <translation>Value</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Off - Attempt to play all resolutions</source>
        <translation>Off - Attempt to play all resolutions</translation>
        <extracomment>User Setting - Option title</extracomment>
    </message>
    <message>
        <source>Auto - Use TV resolution</source>
        <translation>Auto - Use TV resolution</translation>
        <extracomment>User Setting - Option title</extracomment>
    </message>
    <message>
        <source>Global</source>
        <translation>Global</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Disable the HEVC codec on this device. This may improve playback for some devices (ultra).</source>
        <translation>Disable the HEVC codec on this device. This may improve playback for some devices (ultra).</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Remember Me?</source>
        <translation>Remember Me?</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Global settings that affect everyone that uses this Roku device.</source>
        <translation>Global settings that affect everyone that uses this Roku device.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Remember the currently logged in user and try to log them in again next time you start the WatchNexus app.</source>
        <translation>Remember the currently logged in user and try to log them in again next time you start the WatchNexus app.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>Press &apos;OK&apos; to Close</translation>
    </message>
    <message>
        <source>Cinema Mode</source>
        <translation>Cinema Mode</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Use Splashscreen as Home Background</source>
        <translation>Use Splashscreen as Home Background</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Design Elements</source>
        <translation>Design Elements</translation>
    </message>
    <message>
        <source>Search now</source>
        <translation>Search now</translation>
        <extracomment>Help text in search Box</extracomment>
    </message>
    <message>
        <source>Go to episode</source>
        <translation>Go to episode</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Shows</source>
        <translation>Shows</translation>
    </message>
    <message>
        <source>Enable or disable Direct Play for optional codecs</source>
        <translation>Enable or disable Direct Play for optional codecs</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</source>
        <translation>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Enabled</translation>
    </message>
    <message>
        <source>Direct playing</source>
        <translation>Direct playing</translation>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Cancel Series Recording</translation>
    </message>
    <message>
        <source>Enter the server name or IP address</source>
        <translation>Enter the server name or IP address</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>On Now</source>
        <translation type="unfinished">On Now</translation>
    </message>
    <message>
        <source>Extras</source>
        <translation type="unfinished">Extras</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation type="unfinished">Cast &amp; Crew</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation type="unfinished">More Like This</translation>
    </message>
    <message>
        <source>Movies (Presentation)</source>
        <translation type="unfinished">Movies (Presentation)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>Age</source>
        <translation type="unfinished">Age</translation>
    </message>
    <message>
        <source>Died</source>
        <translation type="unfinished">Died</translation>
    </message>
    <message>
        <source>Additional Parts</source>
        <translation type="unfinished">Additional Parts</translation>
        <extracomment>Additional parts of a video</extracomment>
    </message>
    <message>
        <source>TV Shows</source>
        <translation type="unfinished">TV Shows</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation type="unfinished">Movies</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation type="unfinished">Delete Saved</translation>
    </message>
    <message>
        <source>Born</source>
        <translation type="unfinished">Born</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation type="unfinished">Special Features</translation>
    </message>
    <message>
        <source>Episodes</source>
        <translation type="unfinished">Episodes</translation>
    </message>
    <message>
        <source>Movies (Grid)</source>
        <translation type="unfinished">Movies (Grid)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation type="unfinished">Save Credentials?</translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation type="unfinished">Press &apos;OK&apos; to Close</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Cast &amp; Crew</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>More Like This</translation>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>TV Shows</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Save Credentials?</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Delete Saved</translation>
    </message>
    <message>
        <source>Episodes</source>
        <translation>Episodes</translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>Press &apos;OK&apos; to Close</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Special Features</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Record Series</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unknown</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Pick a WatchNexus server from the local network</source>
        <translation>Select an available WatchNexus server from your local network:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>An error was encountered while playing this item. Server did not provide required transcoding data.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Codec Support</source>
        <translation>Codec Support</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>MPEG-2</source>
        <translation>MPEG-2</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>MPEG-4</source>
        <translation>MPEG-4</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Support Direct Play of MPEG-4 content. This may need to be disabled for playback of DIVX encoded video files.</source>
        <translation>Support Direct Play of MPEG-4 content. This may need to be disabled for playback of DIVX encoded video files.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Disabled</translation>
    </message>
    <message>
        <source>User Interface</source>
        <translation>User Interface</translation>
        <extracomment>Title for User Interface section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Media Grid</source>
        <translation>Media Grid</translation>
        <extracomment>UI -&gt; Media Grid section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Item Count</source>
        <translation>Item Count</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Count in user setting screen.</extracomment>
    </message>
    <message>
        <source>Show item count in the library and index of selected item.</source>
        <translation>Show item count in the library and index of selected item.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>Set Favourite</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>Set Watched</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>Go to series</source>
        <translation>Go to series</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Series Detail Page</extracomment>
    </message>
    <message>
        <source>You can search for Titles, People, Live TV Channels and more</source>
        <translation>You can search for Titles, People, Live TV Channels and more</translation>
        <extracomment>Help text in search results</extracomment>
    </message>
    <message>
        <source>%1 of %2</source>
        <translation>%1 of %2</translation>
        <extracomment>Item position and count. %1 = current item. %2 = total number of items</extracomment>
    </message>
    <message>
        <source>Close</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Age</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Died</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Cancel Recording</translation>
    </message>
    <message>
        <source>Additional Parts</source>
        <translation>Additional Parts</translation>
        <extracomment>Additional parts of a video</extracomment>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation>Quick Connect</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>On Now</translation>
    </message>
    <message>
        <source>Extras</source>
        <translation>Extras</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Born</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Record</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>View Channel</translation>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>If no server is listed above, you may also enter the server URL manually:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Error Getting Playback Information</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Playback</source>
        <translation>Playback</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Media Grid options.</source>
        <translation>Media Grid options.</translation>
    </message>
    <message>
        <source>Use voice remote to search</source>
        <translation>Use voice remote to search</translation>
        <extracomment>Help text in search voice text box</extracomment>
    </message>
    <message>
        <source>Search now</source>
        <translation>Search now</translation>
        <extracomment>Help text in search Box</extracomment>
    </message>
    <message>
        <source>Go to episode</source>
        <translation>Go to episode</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Enable or disable Direct Play for optional codecs</source>
        <translation>Enable or disable Direct Play for optional codecs</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</source>
        <translation>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content but uses significantly more bandwidth.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Enabled</translation>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Cancel Series Recording</translation>
    </message>
    <message>
        <source>Enter the server name or IP address</source>
        <translation>Enter the server name or IP address</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>(Dialog will close automatically)</source>
        <translation>(Dialog will close automatically)</translation>
    </message>
    <message>
        <source>Movies (Presentation)</source>
        <translation>Movies (Presentation)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>There was an error authenticating via Quick Connect.</source>
        <translation>There was an error authenticating via Quick Connect.</translation>
    </message>
    <message>
        <source>Networks</source>
        <translation>Networks</translation>
    </message>
    <message>
        <source>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</source>
        <translation>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Hide Taglines</source>
        <translation>Hide Taglines</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Go directly to the episode list if a TV series has only one season.</source>
        <translation>Go directly to the episode list if a TV series has only one season.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Options that alter the design of WatchNexus.</source>
        <translation>Options that alter the design of WatchNexus.</translation>
        <extracomment>Description for Design Elements user settings.</extracomment>
    </message>
    <message>
        <source>Use generated splashscreen image as WatchNexus&apos;s home background. WatchNexus will need to be closed and reopened for change to take effect.</source>
        <translation>Use generated splashscreen image as WatchNexus&apos;s home background. WatchNexus will need to be closed and reopened for change to take effect.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Bring the theater experience straight to your living room with the ability to play custom intros before the main feature.</source>
        <translation>Bring the theater experience straight to your living room with the ability to play custom intros before the main feature.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Hide all clocks in WatchNexus. WatchNexus will need to be closed and reopened for changes to take effect.</source>
        <translation>Hide all clocks in WatchNexus. WatchNexus will need to be closed and reopened for changes to take effect.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Movies</source>
        <translation>Movies</translation>
    </message>
    <message>
        <source>Next episode</source>
        <translation>Next episode</translation>
    </message>
    <message>
        <source>H.264</source>
        <translation>H.264</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Settings relating to playback and supported codec and media types.</source>
        <translation>Settings relating to playback and supported codec and media types.</translation>
    </message>
    <message>
        <source>Settings relating to how the application looks.</source>
        <translation>Settings relating to how the application looks.</translation>
    </message>
    <message>
        <source>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it.</source>
        <translation>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Playback Information</source>
        <translation>Playback Information</translation>
    </message>
    <message>
        <source>Transcoding Information</source>
        <translation>Transcoding Information</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>Reason</translation>
    </message>
    <message>
        <source>Audio Codec</source>
        <translation>Audio Codec</translation>
    </message>
    <message>
        <source>Audio Channels</source>
        <translation>Audio Channels</translation>
    </message>
    <message>
        <source>Stream Information</source>
        <translation>Stream Information</translation>
    </message>
    <message>
        <source>Container</source>
        <translation>Container</translation>
        <extracomment>Video streaming container</extracomment>
    </message>
    <message>
        <source>Unable to find any albums or songs belonging to this artist</source>
        <translation>Unable to find any albums or songs belonging to this artist</translation>
        <extracomment>Popup message when we find no audio data for an artist</extracomment>
    </message>
    <message>
        <source>Replace Roku&apos;s default subtitle functions with custom functions that support CJK fonts. Fallback fonts must be configured and enabled on the server for CJK rendering to work.</source>
        <translation>Replace Roku&apos;s default subtitle functions with custom functions that support CJK fonts. Fallback fonts must be configured and enabled on the server for CJK rendering to work.</translation>
        <extracomment>Description of a setting - custom subtitles that support CJK fonts</extracomment>
    </message>
    <message>
        <source>Only display text subtitles to minimize transcoding.</source>
        <translation>Only display text subtitles to minimize transcoding.</translation>
        <extracomment>Description of a setting - should we hide subtitles that might transcode</extracomment>
    </message>
    <message>
        <source>all</source>
        <translation>all</translation>
        <extracomment>all will reset the searchTerm so all data will be availible</extracomment>
    </message>
    <message>
        <source>Slideshow On</source>
        <translation>Slideshow On</translation>
    </message>
    <message>
        <source>Slideshow Paused</source>
        <translation>Slideshow Paused</translation>
    </message>
    <message>
        <source>Slideshow Resumed</source>
        <translation>Slideshow Resumed</translation>
    </message>
    <message>
        <source>Random Off</source>
        <translation>Random Off</translation>
    </message>
    <message>
        <source>Parental Ratings</source>
        <translation>Parental Ratings</translation>
        <extracomment>Used in Filter menu</extracomment>
    </message>
    <message>
        <source>Years</source>
        <translation>Years</translation>
        <extracomment>Used in Filter menu</extracomment>
    </message>
    <message>
        <source>Show What&apos;s New Popup</source>
        <translation>Show What&apos;s New Popup</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Show What&apos;s New popup when WatchNexus is updated to a new version.</source>
        <translation>Show What&apos;s New popup when WatchNexus is updated to a new version.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Played</source>
        <translation>Played</translation>
    </message>
    <message>
        <source>Resumable</source>
        <translation>Resumable</translation>
    </message>
    <message>
        <source>Artists (Presentation)</source>
        <translation>Artists (Presentation)</translation>
    </message>
    <message>
        <source>Songs</source>
        <translation>Songs</translation>
    </message>
    <message>
        <source>Albums</source>
        <translation>Albums</translation>
    </message>
    <message>
        <source>Hide the star and community rating for episodes of a TV show. This is to prevent spoilers of an upcoming good/bad episode.</source>
        <translation>Hide the star and community rating for episodes of a TV show. This is to prevent spoilers of an upcoming good/bad episode.</translation>
    </message>
    <message>
        <source>Configure the maximum playback bitrate.</source>
        <translation>Configure the maximum playback bitrate.</translation>
    </message>
    <message>
        <source>Enable Limit</source>
        <translation>Enable Limit</translation>
    </message>
    <message>
        <source>Enable or disable the &apos;Maximum Bitrate&apos; setting.</source>
        <translation>Enable or disable the &apos;Maximum Bitrate&apos; setting.</translation>
    </message>
    <message>
        <source>Set the maximum bitrate in Mbps. Set to 0 to use Roku&apos;s specifications. This setting must be enabled to take effect.</source>
        <translation>Set the maximum bitrate in Mbps. Set to 0 to use Roku&apos;s specifications. This setting must be enabled to take effect.</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of Library pages</source>
        <translation>Settings relating to the appearance of Library pages</translation>
    </message>
    <message>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of the Home screen and the program in general.</source>
        <translation>Settings relating to the appearance of the Home screen and the program in general.</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of pages in Movie Libraries.</source>
        <translation>Settings relating to the appearance of pages in Movie Libraries.</translation>
    </message>
    <message>
        <source>Presentation</source>
        <translation>Presentation</translation>
        <extracomment>Title of an option - name of presentation view</extracomment>
    </message>
    <message>
        <source>If enabled, the number of unwatched episodes in a series/season will be removed.</source>
        <translation>If enabled, the number of unwatched episodes in a series/season will be removed.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Loading trailer</source>
        <translation>Loading trailer</translation>
        <extracomment>Dialog title in Main.brs</extracomment>
    </message>
    <message>
        <source>Next Episode Button Time</source>
        <translation>Next Episode Button Time</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Set how many seconds before the end of an episode the Next Episode button should appear. Set to 0 to disable.</source>
        <translation>Set how many seconds before the end of an episode the Next Episode button should appear. Set to 0 to disable.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Force all transcodes to use DTS instead of the default EAC3. The device must support DTS for this setting to have an effect.</source>
        <translation>Force all transcodes to use DTS instead of the default EAC3. The device must support DTS for this setting to have an effect.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>The source file is entirely compatible with this client and the session is receiving the file without modifications.</source>
        <translation>The source file is entirely compatible with this client and the session is receiving the file without modifications.</translation>
        <extracomment>Direct play info box text in GetPlaybackInfoTask.brs</extracomment>
    </message>
    <message>
        <source>Maximum Resolution</source>
        <translation>Maximum Resolution</translation>
        <extracomment>User Setting - Title</extracomment>
    </message>
    <message>
        <source>Off - Attempt to play all resolutions</source>
        <translation>Off - Attempt to play all resolutions</translation>
        <extracomment>User Setting - Option title</extracomment>
    </message>
    <message>
        <source>Configure the maximum resolution when playing video files on this device.</source>
        <translation>Configure the maximum resolution when playing video files on this device.</translation>
        <extracomment>User Setting - Description</extracomment>
    </message>
    <message>
        <source>Disable the HEVC codec on this device. This may improve playback for some devices (ultra).</source>
        <translation>Disable the HEVC codec on this device. This may improve playback for some devices (ultra).</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Global settings that affect everyone that uses this Roku device.</source>
        <translation>Global settings that affect everyone that uses this Roku device.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Remember the currently logged in user and try to log them in again next time you start the WatchNexus app.</source>
        <translation>Remember the currently logged in user and try to log them in again next time you start the WatchNexus app.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>No Chapter Data Found</source>
        <translation>No Chapter Data Found</translation>
        <extracomment>Message shown in OSD when no chapter data is returned by the API</extracomment>
    </message>
    <message>
        <source>What&apos;s New?</source>
        <translation>What&apos;s New?</translation>
        <extracomment>Popup title - Popup displays all the major changes to the app since the last version</extracomment>
    </message>
    <message>
        <source>Movies (Grid)</source>
        <translation>Movies (Grid)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation>Go to season</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>Play Trailer</source>
        <translation>Play Trailer</translation>
    </message>
    <message>
        <source>Attempt Direct Play for H.264 media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation>Attempt Direct Play for H.264 media with unsupported profile levels before falling back to transcoding if it fails.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Album Artists (Presentation)</source>
        <translation>Album Artists (Presentation)</translation>
    </message>
    <message>
        <source>Options for TV Shows.</source>
        <translation>Options for TV Shows.</translation>
        <extracomment>Description for TV Shows user settings.</extracomment>
    </message>
    <message>
        <source>Hide Clock</source>
        <translation>Hide Clock</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Use Web Client&apos;s Home Section Arrangement</source>
        <translation>Use Web Client&apos;s Home Section Arrangement</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Make the arrangement of the Roku home view sections match the web client&apos;s home screen. WatchNexus will need to be closed and reopened for change to take effect.</source>
        <translation>Make the arrangement of the Roku home view sections match the web client&apos;s home screen. WatchNexus will need to be closed and reopened for change to take effect.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>All files</source>
        <translation>All files</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Only transcoded files</source>
        <translation>Only transcoded files</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Compatibility</source>
        <translation>Compatibility</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Attempt to prevent playback failures.</source>
        <translation>Attempt to prevent playback failures.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Codec Tag</source>
        <translation>Codec Tag</translation>
    </message>
    <message>
        <source>Studios</source>
        <translation>Studios</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Size</translation>
        <extracomment>Video size</extracomment>
    </message>
    <message>
        <source>Pixel format</source>
        <translation>Pixel format</translation>
        <extracomment>Video pixel format</extracomment>
    </message>
    <message>
        <source>Aired</source>
        <translation>Aired</translation>
        <extracomment>Aired date label</extracomment>
    </message>
    <message>
        <source>Unplayed</source>
        <translation>Unplayed</translation>
    </message>
    <message>
        <source>View All</source>
        <translation>View All</translation>
    </message>
    <message>
        <source>Maximum Bitrate</source>
        <translation>Maximum Bitrate</translation>
    </message>
    <message>
        <source>Mode</source>
        <translation>Mode</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Disable HEVC</source>
        <translation>Disable HEVC</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Return to Top</source>
        <translation>Return to Top</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Show On Hover</source>
        <translation>Show On Hover</translation>
    </message>
    <message>
        <source>Grid View Settings</source>
        <translation>Grid View Settings</translation>
    </message>
    <message>
        <source>Blur images of unwatched episodes.</source>
        <translation>Blur images of unwatched episodes.</translation>
    </message>
    <message>
        <source>direct</source>
        <translation>direct</translation>
    </message>
    <message>
        <source>Total Bitrate</source>
        <translation>Total Bitrate</translation>
    </message>
    <message>
        <source>Codec</source>
        <translation>Codec</translation>
    </message>
    <message>
        <source>Movie Library Default View</source>
        <translation>Movie Library Default View</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Bitrate Limit</source>
        <translation>Bitrate Limit</translation>
    </message>
    <message>
        <source>Artists (Grid)</source>
        <translation>Artists (Grid)</translation>
    </message>
    <message>
        <source>Here is your Quick Connect code:</source>
        <translation>Here is your Quick Connect code:</translation>
    </message>
    <message>
        <source>Hides tagline text on details pages.</source>
        <translation>Hides tagline text on details pages.</translation>
    </message>
    <message>
        <source>Blur Unwatched Episodes</source>
        <translation>Blur Unwatched Episodes</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Attempt Direct Play for HEVC media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation>Attempt Direct Play for HEVC media with unsupported profile levels before falling back to transcoding if it fails.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Max Days Next Up</source>
        <translation>Max Days Next Up</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Video Codec</source>
        <translation>Video Codec</translation>
    </message>
    <message>
        <source>Bit Rate</source>
        <translation>Bit Rate</translation>
        <extracomment>Video streaming bit rate</extracomment>
    </message>
    <message>
        <source>WxH</source>
        <translation>WxH</translation>
        <extracomment>Video width x height</extracomment>
    </message>
    <message>
        <source>Text Subtitles Only</source>
        <translation>Text Subtitles Only</translation>
        <extracomment>Name of a setting - should we hide subtitles that might transcode</extracomment>
    </message>
    <message>
        <source>Slideshow Off</source>
        <translation>Slideshow Off</translation>
    </message>
    <message>
        <source>Default view for Movie Libraries.</source>
        <translation>Default view for Movie Libraries.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Item Titles</source>
        <translation>Item Titles</translation>
        <extracomment>Title of a setting - when should we show the title text of a grid item</extracomment>
    </message>
    <message>
        <source>Select when to show titles.</source>
        <translation>Select when to show titles.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Always Hide</source>
        <translation>Always Hide</translation>
    </message>
    <message>
        <source>Disable Community Rating for Episodes</source>
        <translation>Disable Community Rating for Episodes</translation>
    </message>
    <message>
        <source>Biographical information for this person is not currently available.</source>
        <translation>Biographical information for this person is not currently available.</translation>
    </message>
    <message>
        <source>Libraries</source>
        <translation>Libraries</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of pages in TV Libraries.</source>
        <translation>Settings relating to the appearance of pages in TV Libraries.</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation>Grid</translation>
        <extracomment>Title of an option - name of grid view</extracomment>
    </message>
    <message>
        <source>Disable Unwatched Episode Count</source>
        <translation>Disable Unwatched Episode Count</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Choose your preferred audio codec when transcoding multichannel audio.</source>
        <translation>Choose your preferred audio codec when transcoding multichannel audio.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Audio Codec Support</source>
        <translation>Audio Codec Support</translation>
        <extracomment>Settings Menu - Title of option</extracomment>
    </message>
    <message>
        <source>Set the maximum resolution when playing video files on this device.</source>
        <translation>Set the maximum resolution when playing video files on this device.</translation>
        <extracomment>User Setting - Description</extracomment>
    </message>
    <message>
        <source>Apply max resolution to all files or only transcoded files.</source>
        <translation>Apply max resolution to all files or only transcoded files.</translation>
        <extracomment>User Setting - Description</extracomment>
    </message>
    <message>
        <source>Skip Details for Single Seasons</source>
        <translation>Skip Details for Single Seasons</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>HEVC</source>
        <translation>HEVC</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Video range type</source>
        <translation>Video range type</translation>
    </message>
    <message>
        <source>Level</source>
        <translation>Level</translation>
        <extracomment>Video profile level</extracomment>
    </message>
    <message>
        <source>Custom Subtitles</source>
        <translation>Custom Subtitles</translation>
        <extracomment>Name of a setting - custom subtitles that support CJK fonts</extracomment>
    </message>
    <message>
        <source>Random On</source>
        <translation>Random On</translation>
    </message>
    <message>
        <source>MPEG-4 Support</source>
        <translation>MPEG-4 Support</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Always Show</source>
        <translation>Always Show</translation>
    </message>
    <message>
        <source>Album Artists (Grid)</source>
        <translation>Album Artists (Grid)</translation>
    </message>
    <message>
        <source>Song</source>
        <translation>Song</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>Album</translation>
    </message>
    <message>
        <source>Settings that apply when Grid views are enabled.</source>
        <translation>Settings that apply when Grid views are enabled.</translation>
    </message>
    <message>
        <source>Auto - Use TV resolution</source>
        <translation>Auto - Use TV resolution</translation>
        <extracomment>User Setting - Option title</extracomment>
    </message>
    <message>
        <source>Value</source>
        <translation>Value</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Global</source>
        <translation>Global</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Remember Me?</source>
        <translation>Remember Me?</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Cinema Mode</source>
        <translation>Cinema Mode</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Use Splashscreen as Home Background</source>
        <translation>Use Splashscreen as Home Background</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Design Elements</source>
        <translation>Design Elements</translation>
    </message>
    <message>
        <source>Shows</source>
        <translation>Shows</translation>
    </message>
    <message>
        <source>Direct playing</source>
        <translation>Direct playing</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Delete Saved</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>On Now</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Save Credentials?</translation>
    </message>
    <message>
        <source>Extras</source>
        <translation>Extras</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Age</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Died</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Born</translation>
    </message>
    <message>
        <source>Episodes</source>
        <translation>Episodes</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Cast &amp; Crew</translation>
    </message>
</context>
</TS>
