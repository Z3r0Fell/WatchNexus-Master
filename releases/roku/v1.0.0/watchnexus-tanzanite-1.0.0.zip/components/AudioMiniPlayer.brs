'import "pkg:/source/api/baserequest.bs"
'import "pkg:/source/api/Image.bs"
'import "pkg:/source/enums/AnimationControl.bs"
'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/ImageType.bs"
'import "pkg:/source/enums/KeyCode.bs"
'import "pkg:/source/enums/MediaPlaybackState.bs"
'import "pkg:/source/enums/String.bs"
'import "pkg:/source/enums/TaskControl.bs"
'import "pkg:/source/enums/VideoControl.bs"
'import "pkg:/source/enums/ViewLoadStatus.bs"
'import "pkg:/source/utils/config.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.audioMiniPlayerContainerBorder = m.top.findNode("audioMiniPlayerContainerBorder")
    m.audioMiniPlayerContainerBorder.color = "#aaaaaa"
    m.audioMiniPlayerContainerBorder.visible = false
    m.audioMiniPlayerContainer = m.top.findNode("audioMiniPlayerContainer")
    m.audioMiniPlayerContainer.color = "#101010"
    m.top.visible = false
    m.audioMiniPlayerContainer.visible = false
    m.slideDownAnimation = m.top.findNode("slideDown")
    m.slideUpAnimation = m.top.findNode("slideUp")
    setupAnimationTasks()
    setupInfoNodes()
    setupButtons()
    m.song = m.top.findNode("song")
    m.song.font.size = 40
    m.seekBar.color = "0x00000077"
    m.playPosition.color = "#303030"
    m.previouslySelectedButtonIndex = 0
    m.selectedButtonIndex = 1
end sub

sub setupButtons()
    buttons = [
        "buttons"
        "previous"
        "stop"
        "play"
        "next"
        "nowPlaying"
    ]
    for each button in buttons
        m[button] = m.top.findNode(button)
    end for
end sub

' Event handler when user selected a different playback button
sub onButtonSelectedChange()
    ' Change previously selected button back to default image
    selectedButton = m.buttons.getChild(m.previouslySelectedButtonIndex)
    if isValid(selectedButton)
        selectedButton.blendColor = "#ffffff"
        selectedButton.opacity = .85
    end if
    ' Change selected button image to selected image
    selectedButton = m.buttons.getChild(m.selectedButtonIndex)
    if isValid(selectedButton)
        selectedButton.blendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
        selectedButton.opacity = 1
    end if
end sub

function isVisible() as boolean
    return m.audioMiniPlayerContainer.visible
end function

sub onSlideDownAnimationStateChange()
    if not isStringEqual(m.slideDownAnimation.state, "stopped") then
        return
    end if
    m.slideDownAnimation.unobserveFieldScoped("state")
    m.audioMiniPlayerContainerBorder.visible = false
    m.audioMiniPlayerContainer.visible = false
    m.top.visible = false
    m.previouslySelectedButtonIndex = m.selectedButtonIndex
    m.selectedButtonIndex = -1
    onButtonSelectedChange()
    ' We hiding a mini player that is currently selected
    if isSelected()
        setSelected(false)
        removeFocus()
    end if
end sub

sub setVisible(newVisibleState as boolean)
    if newVisibleState
        m.audioMiniPlayerContainerBorder.visible = true
        m.audioMiniPlayerContainer.visible = true
        m.top.visible = true
        m.slideUpAnimation.control = "start"
    else
        m.slideDownAnimation.observeFieldScoped("state", "onSlideDownAnimationStateChange")
        m.slideDownAnimation.control = "start"
        return
    end if
end sub

function isSelected() as boolean
    return m.top.selected
end function

sub setSelected(newSelectedState as boolean)
    m.top.selected = newSelectedState
    if m.top.selected
        m.previouslySelectedButtonIndex = m.selectedButtonIndex
        m.selectedButtonIndex = 1
        onButtonSelectedChange()
    end if
    if not m.top.selected
        m.previouslySelectedButtonIndex = m.selectedButtonIndex
        m.selectedButtonIndex = -1
        onButtonSelectedChange()
    end if
end sub

sub setupAnimationTasks()
    m.playPositionAnimation = m.top.FindNode("playPositionAnimation")
    m.playPositionAnimationWidth = m.top.FindNode("playPositionAnimationWidth")
end sub

' Creates audio node used to play song(s)
sub setup()
    m.global.audioPlayer.observeFieldScoped("position", "audioPositionChanged")
    m.global.audioPlayer.observeFieldScoped("audioData", "onAudioDataChanged")
end sub

sub onAudioDataChanged()
    stopLoadingSpinner()
    ' If user starts playing a mixed playlist, hide mini player
    if m.global.queueManager.callFunc("getQueueUniqueTypes").count() <> 1
        setVisible(false)
        return
    end if
    data = m.global.audioPlayer.audioData
    if not isValidAndNotEmpty(data)
        setVisible(false)
        return
    end if
    useMetaTask = false
    currentItem = m.global.queueManager.callFunc("getCurrentItem")
    if not isValid(currentItem.RunTimeTicks)
        useMetaTask = true
    end if
    if not isValid(currentItem.AlbumArtist)
        useMetaTask = true
    end if
    if not isValid(currentItem.name)
        useMetaTask = true
    end if
    if not isValid(currentItem.Artists)
        useMetaTask = true
    end if
    if useMetaTask
        ' Load meta data
        m.LoadMetaDataTask = CreateObject("roSGNode", "LoadItemsTask")
        m.LoadMetaDataTask.itemsToLoad = "metaData"
        m.LoadMetaDataTask.itemId = currentItem.id
        m.LoadMetaDataTask.observeField("content", "onMetaDataLoaded")
        m.LoadMetaDataTask.control = "RUN"
    else
        setPosterImage(ImageURL(currentItem.id, "Primary", {
            "maxHeight": 180
            "maxWidth": 180
        }))
        setOnScreenTextValues(currentItem)
        m.songDuration = currentItem.RunTimeTicks / 10000000.0
    end if
end sub

sub setupInfoNodes()
    m.albumCover = m.top.findNode("albumCover")
    m.playPosition = m.top.findNode("playPosition")
    m.seekBar = m.top.findNode("seekBar")
end sub

sub audioPositionChanged()
    if not isVisible() then
        return
    end if
    stopLoadingSpinner()
    if m.global.audioPlayer.position = 0
        m.playPosition.width = 0
    end if
    if not isValid(m.global.audioPlayer.position)
        playPositionBarWidth = 0
    else if not isValid(m.songDuration)
        playPositionBarWidth = 0
    else
        songPercentComplete = m.global.audioPlayer.position / m.songDuration
        playPositionBarWidth = m.seekBar.width * songPercentComplete
    end if
    ' Ensure position bar is never wider than the seek bar
    if playPositionBarWidth > m.seekBar.width
        playPositionBarWidth = m.seekBar.width
    end if
    ' Use animation to make the display smooth
    m.playPositionAnimationWidth.keyValue = [
        m.playPosition.width
        playPositionBarWidth
    ]
    m.playPositionAnimation.control = "start"
end sub

sub playAction()
    if m.global.audioPlayer.state = "playing"
        m.global.audioPlayer.control = "PAUSE"
        m.play.uri = "pkg:/images/icons/play.png"
        return
    end if
    if m.global.audioPlayer.state = "paused"
        m.global.audioPlayer.control = "RESUME"
        m.play.uri = "pkg:/images/icons/pause.png"
        return
    end if
    if m.global.audioPlayer.state = "finished"
        m.global.audioPlayer.control = "PLAY"
        m.play.uri = "pkg:/images/icons/pause.png"
        return
    end if
end sub

sub stopClicked()
    m.global.queueManager.callFunc("clear")
    m.global.audioPlayer.control = "stop"
end sub

function findCurrentSongIndex(songList) as integer
    if not isValidAndNotEmpty(songList) then
        return 0
    end if
    for i = 0 to songList.count() - 1
        if isStringEqual(songList[i].id, m.global.queueManager.callFunc("getCurrentItem").id)
            return i
        end if
    end for
    return 0
end function

sub onMetaDataLoaded()
    data = m.LoadMetaDataTask.content[0]
    m.LoadMetaDataTask.unobserveField("content")
    if isValidAndNotEmpty(data) and isValid(data.json)
        setPosterImage(data.posterURL)
        setOnScreenTextValues(data.json)
        if isValid(data.json.RunTimeTicks)
            m.songDuration = data.json.RunTimeTicks / 10000000.0
        end if
    end if
end sub

' Set poster image on screen
sub setPosterImage(posterURL)
    if isValid(posterURL)
        if not isStringEqual(m.albumCover.uri, posterURL)
            m.albumCover.uri = posterURL
        end if
    end if
end sub

' Populate on screen text variables
sub setOnScreenTextValues(json)
    if isValid(json) and isValid(json.Artists[0])
        setFieldTextValue("song", (bslib_toString(json.Artists[0].replace(chr(8208), "-")) + " - " + bslib_toString(json.name.trim())))
    else
        setFieldTextValue("song", (bslib_toString(json.name.trim())))
    end if
end sub

' Remove focus from mini player
sub removeFocus()
    group = m.global.sceneManager.callFunc("getActiveScene")
    if isChainValid(group, "lastFocus")
        group.lastFocus.setFocus(true)
        if isStringEqual(group.lastFocus.subtype(), "TextButton")
            group.lastFocus.focus = true
        end if
    end if
end sub

sub nowPlayingClicked()
    setSelected(false)
    removeFocus()
    data = {
        selectionType: "nowplaying"
    }
    m.top.getScene().jumpTo = data
end sub

' Process key press events
function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        return false
    end if
    if not isSelected() then
        return false
    end if
    if key = "right"
        if m.selectedButtonIndex >= m.buttons.getChildCount() - 1 then
            return false
        end if
        m.previouslySelectedButtonIndex = m.selectedButtonIndex
        m.selectedButtonIndex = m.selectedButtonIndex + 1
        onButtonSelectedChange()
        return true
    end if
    if key = "left"
        if m.selectedButtonIndex = 0 then
            return false
        end if
        m.previouslySelectedButtonIndex = m.selectedButtonIndex
        m.selectedButtonIndex = m.selectedButtonIndex - 1
        onButtonSelectedChange()
        return true
    end if
    if key = "OK"
        selectedButtonID = m.buttons.getChild(m.selectedButtonIndex).id
        if isStringEqual(selectedButtonID, "play")
            playAction()
            return true
        else if isStringEqual(selectedButtonID, "previous")
            m.global.audioPlayer.callFunc("playPrevious")
            return true
        else if isStringEqual(selectedButtonID, "next")
            m.global.audioPlayer.callFunc("playNext")
            return true
        else if isStringEqual(selectedButtonID, "stop")
            stopClicked()
            return true
        else if isStringEqual(selectedButtonID, "nowPlaying")
            nowPlayingClicked()
            return true
        end if
    end if
    if key = "replay"
        setSelected(false)
        removeFocus()
        return true
    end if
    setSelected(false)
    removeFocus()
    return false
end function
'//# sourceMappingURL=./AudioMiniPlayer.brs.map