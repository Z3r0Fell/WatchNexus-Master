'import "pkg:/source/enums/ItemType.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.extrasType = {
        BEHINDTHESCENES: "Behind the Scenes"
        CLIP: "Clip"
        DELETEDSCENE: "Deleted Scene"
        FEATURETTE: "Featurette"
        INTERVIEW: "Interview"
        SAMPLE: "Sample"
        SCENE: "Scene"
        SHORT: "Short"
        THEMESONG: "ThemeSong"
        THEMEVIDEO: "ThemeVideo"
        TRAILER: "Trailer"
        UNKNOWN: "Extra"
    }
    initPosterImg()
    initName()
    initRole()
    m.name.height = 34
    m.name.font.size = 25
    m.name.horizAlign = "left"
    m.name.vertAlign = "bottom"
    m.role.font.size = 22
end sub

sub initPosterImg()
    m.posterImg = m.top.findNode("posterImg")
end sub

sub initName()
    m.name = m.top.findNode("pLabel")
end sub

sub initRole()
    m.role = m.top.findNode("subTitle")
end sub

sub showContent()
    ' validate nodes to prevent crash
    if not isValid(m.posterImg) then
        initPosterImg()
    end if
    if not isValid(m.name) then
        initName()
    end if
    if not isValid(m.role) then
        initRole()
    end if
    if isValid(m.top.itemContent)
        cont = m.top.itemContent
        m.name.text = cont.labelText
        m.name.maxWidth = cont.imageWidth
        m.role.maxWidth = cont.imageWidth
        m.posterImg.uri = cont.posterUrl
        m.posterImg.width = cont.imageWidth
        if isStringEqual(cont.LookupCI("type"), "musicvideo")
            m.posterImg.width = 400
            m.name.maxWidth = 400
            m.role.maxWidth = 400
            m.posterImg.height = 260
        end if
        if isChainValid(cont, "json.ExtraType")
            if cont.json.ExtraType <> ""
                cont.subTitle = m.extrasType[UCase(cont.json.ExtraType)]
            end if
        end if
        if isChainValid(cont, "json.officialrating")
            if cont.json.officialrating <> ""
                cont.subTitle += (" - " + bslib_toString(cont.json.officialrating))
            end if
        end if
        m.role.Text = cont.subTitle.trim()
    else
        m.role.text = tr("Unknown")
        m.posterImg.uri = "pkg:/images/baseline_person_white_48dp.png"
    end if
end sub

sub focusChanged()
    if m.top.itemHasFocus = true
        m.name.repeatCount = -1
        m.role.repeatCount = -1
    else
        m.name.repeatCount = 0
        m.role.repeatCount = 0
    end if
    if m.global.device.isAudioGuideEnabled = true
        txt2Speech = CreateObject("roTextToSpeech")
        txt2Speech.Flush()
        txt2Speech.Say(m.name.text)
        txt2Speech.Say(m.role.text)
    end if
end sub
'//# sourceMappingURL=./ExtrasItem.brs.map