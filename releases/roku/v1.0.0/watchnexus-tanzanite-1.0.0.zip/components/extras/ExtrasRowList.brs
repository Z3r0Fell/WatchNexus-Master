'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/ItemType.bs"
'import "pkg:/source/enums/PersonType.bs"
'import "pkg:/source/enums/TaskControl.bs"
'import "pkg:/source/enums/VideoType.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.top.visible = true
    m.top.focusBitmapBlendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    updateSize()
    m.top.observeField("rowItemSelected", "onRowItemSelected")
    m.top.observeField("rowItemFocused", "onRowItemFocused")
    ' Set up all Tasks
    m.LoadPeopleTask = CreateObject("roSGNode", "LoadItemsTask")
    m.LoadPeopleTask.itemsToLoad = "people"
    m.LikeThisTask = CreateObject("roSGNode", "LoadItemsTask")
    m.LikeThisTask.itemsToLoad = "likethis"
    m.SpecialFeaturesTask = CreateObject("roSGNode", "LoadItemsTask")
    m.SpecialFeaturesTask.itemsToLoad = "specialfeatures"
    m.LoadMoviesTask = CreateObject("roSGNode", "LoadItemsTask")
    m.LoadMoviesTask.itemsToLoad = "personMovies"
    m.LoadShowsTask = CreateObject("roSGNode", "LoadItemsTask")
    m.LoadShowsTask.itemsToLoad = "personTVShows"
    m.LoadEpisodesTask = CreateObject("roSGNode", "LoadItemsTask")
    m.LoadEpisodesTask.itemsToLoad = "seasonOfEpisodes"
    m.LoadSeriesTask = CreateObject("roSGNode", "LoadItemsTask")
    m.LoadSeriesTask.itemsToLoad = "personSeries"
end sub

sub updateSize()
    itemHeight = 396
    m.top.itemSize = [
        1710
        itemHeight
    ]
    m.top.rowItemSpacing = [
        36
        36
    ]
end sub

sub onSeasonOfEpisodesLoaded()
    data = m.LoadEpisodesTask.content
    m.LoadEpisodesTask.unobserveField("content")
    if not isValidAndNotEmpty(data) then
        return
    end if
    if not m.top.hasItems then
        m.top.hasItems = true
    end if
    header = "Season"
    if isChainValid(data[0], "json.ParentIndexNumber")
        header += (" " + bslib_toString(data[0].json.ParentIndexNumber))
    end if
    ' We can't simply use the episode index due to combination episodes
    shiftAmount = 0
    if isValidAndNotEmpty(m.top.episodeID)
        for each episode in data
            if isStringEqual(m.top.episodeID, episode.json.LookupCI("id")) then
                exit for
            end if
            shiftAmount++
        end for
    end if
    ' Shift episodes array so the selected episode is displayed first
    if shiftAmount > 0
        for i = 0 to shiftAmount - 1
            itemToMove = data.Shift()
            data.push(itemToMove)
        end for
    end if
    row = buildRow(header, data, 502)
    addRowSize([
        502
        396
    ])
    m.top.content.appendChild(row)
end sub

sub loadParts(data as object)
    m.SpecialFeaturesTask.observeField("content", "onSpecialFeaturesLoaded")
    m.LoadPeopleTask.observeField("content", "onPeopleLoaded")
    m.LikeThisTask.observeField("content", "onLikeThisLoaded")
    m.LoadEpisodesTask.observeField("content", "onSeasonOfEpisodesLoaded")
    m.top.content = CreateObject("roSGNode", "ContentNode")
    m.top.parentId = data.id
    m.people = data.People
    m.LoadPeopleTask.peopleList = m.people
    m.SpecialFeaturesTask.itemId = m.top.parentId
    m.SpecialFeaturesTask.control = "RUN"
    if isAllValid([
        m.top.seasonID
        m.top.showID
    ])
        m.LoadEpisodesTask.showID = m.top.showID
        m.LoadEpisodesTask.seasonID = m.top.seasonID
        m.LoadEpisodesTask.control = "RUN"
    end if
end sub

sub loadPersonVideos(personId)
    m.personId = personId
    m.LoadMoviesTask.itemId = m.personId
    m.LoadMoviesTask.observeField("content", "onMoviesLoaded")
    m.LoadMoviesTask.control = "RUN"
end sub

sub onPeopleLoaded()
    people = m.LoadPeopleTask.content
    m.loadPeopleTask.unobserveField("content")
    if isValidAndNotEmpty(people)
        if not m.top.hasItems then
            m.top.hasItems = true
        end if
        row = m.top.content.createChild("ContentNode")
        row.Title = tr("Cast & Crew")
        for each person in people
            if LCase(person.json.LookupCI("type")) = "actor" and isValid(person.json.LookupCI("Role")) and person.json.LookupCI("Role").ToStr().Trim() <> ""
                person.subTitle = (bslib_toString(tr("as")) + " " + bslib_toString(person.json.LookupCI("Role")))
            else
                person.subTitle = person.json.LookupCI("Type")
            end if
            person.Type = capitalize("person")
            row.appendChild(person)
        end for
        addRowSize([
            234
            372
        ])
    end if
    m.LikeThisTask.itemId = m.top.parentId
    m.LikeThisTask.control = "RUN"
end sub

sub onLikeThisLoaded()
    data = m.LikeThisTask.content
    m.LikeThisTask.unobserveField("content")
    if isValidAndNotEmpty(data)
        if not m.top.hasItems then
            m.top.hasItems = true
        end if
        row = m.top.content.createChild("ContentNode")
        row.Title = tr("More Like This")
        for each item in data
            item.Id = item.json.LookupCI("Id")
            item.labelText = item.json.LookupCI("Name")
            if isValid(item.json.LookupCI("ProductionYear"))
                item.subTitle = stri(item.json.LookupCI("ProductionYear"))
            else if isValid(item.json.LookupCI("PremiereDate"))
                premierYear = CreateObject("roDateTime")
                premierYear.FromISO8601String(item.json.LookupCI("PremiereDate"))
                item.subTitle = stri(premierYear.GetYear())
            end if
            item.Type = item.json.LookupCI("Type")
            row.appendChild(item)
        end for
        if isStringEqual(data[0].json.LookupCI("Type"), "musicvideo")
            addRowSize([
                400
                330
            ])
        else
            addRowSize([
                234
                396
            ])
        end if
    end if
end sub

function onSpecialFeaturesLoaded()
    data = m.SpecialFeaturesTask.content
    m.SpecialFeaturesTask.unobserveField("content")
    if isValidAndNotEmpty(data)
        if not m.top.hasItems then
            m.top.hasItems = true
        end if
        row = m.top.content.createChild("ContentNode")
        row.Title = tr("Special Features")
        for each item in data
            m.top.visible = true
            item.Id = item.json.LookupCI("Id")
            item.labelText = item.json.LookupCI("Name")
            item.subTitle = ""
            item.Type = item.json.LookupCI("Type")
            item.imageWidth = 450
            row.appendChild(item)
        end for
        addRowSize([
            462
            372
        ])
    end if
    m.LoadPeopleTask.control = "RUN"
    return m.top.content
end function

sub onMoviesLoaded()
    data = m.LoadMoviesTask.content
    m.LoadMoviesTask.unobserveField("content")
    rlContent = CreateObject("roSGNode", "ContentNode")
    if isValidAndNotEmpty(data)
        if not m.top.hasItems then
            m.top.hasItems = true
        end if
        row = rlContent.createChild("ContentNode")
        row.title = tr("Movies")
        for each mov in data
            mov.Id = mov.json.Id
            mov.labelText = mov.json.Name
            mov.subTitle = mov.json.ProductionYear
            mov.Type = mov.json.Type
            row.appendChild(mov)
        end for
        m.top.rowItemSize = [
            [
                234
                396
            ]
        ]
    end if
    m.top.content = rlContent
    m.LoadShowsTask.itemId = m.personId
    m.LoadShowsTask.observeField("content", "onShowsLoaded")
    m.LoadShowsTask.control = "RUN"
end sub

sub onShowsLoaded()
    data = m.LoadShowsTask.content
    m.LoadShowsTask.unobserveField("content")
    if isValidAndNotEmpty(data)
        if not m.top.hasItems then
            m.top.hasItems = true
        end if
        row = buildRow("TV Shows", data, 502)
        addRowSize([
            502
            396
        ])
        m.top.content.appendChild(row)
    end if
    m.LoadSeriesTask.itemId = m.personId
    m.LoadSeriesTask.observeField("content", "onSeriesLoaded")
    m.LoadSeriesTask.control = "RUN"
end sub

sub onSeriesLoaded()
    data = m.LoadSeriesTask.content
    m.LoadSeriesTask.unobserveField("content")
    if isValidAndNotEmpty(data)
        if not m.top.hasItems then
            m.top.hasItems = true
        end if
        row = buildRow("Series", data)
        addRowSize([
            234
            396
        ])
        m.top.content.appendChild(row)
    end if
    m.top.visible = true
end sub

function buildRow(rowTitle as string, items, imgWdth = 0)
    row = CreateObject("roSGNode", "ContentNode")
    row.Title = tr(rowTitle)
    for each mov in items
        if LCase(mov.json.type) = "episode"
            if isAllValid([
                mov.json.SeriesName
                mov.json.ParentIndexNumber
                mov.json.IndexNumber
                mov.json.Name
            ])
                mov.labelText = mov.json.SeriesName
                endingEpisode = ""
                if isValid(mov.json.LookupCI("indexNumberEnd"))
                    endingEpisode = ("-" + bslib_toString(mov.json.LookupCI("indexNumberEnd")))
                end if
                mov.subTitle = ("S" + bslib_toString(mov.json.ParentIndexNumber) + ":E" + bslib_toString(mov.json.IndexNumber) + bslib_toString(endingEpisode) + " - " + bslib_toString(mov.json.Name))
            else
                mov.labelText = mov.json.Name
                mov.subTitle = mov.json.ProductionYear
            end if
        else
            mov.labelText = mov.json.Name
            mov.subTitle = mov.json.ProductionYear
            if isValid(mov.json.EndDate)
                mov.subTitle += (" - " + bslib_toString(LEFT(mov.json.EndDate, 4)))
            end if
        end if
        mov.Id = mov.json.Id
        mov.Type = mov.json.Type
        if imgWdth > 0
            mov.imageWidth = imgWdth
        end if
        row.appendChild(mov)
    end for
    return row
end function

sub addRowSize(newRow)
    sizeArray = m.top.rowItemSize
    newSizeArray = []
    for each size in sizeArray
        newSizeArray.push(size)
    end for
    newSizeArray.push(newRow)
    m.top.rowItemSize = newSizeArray
end sub

sub onRowItemSelected()
    m.top.selectedItem = m.top.content.getChild(m.top.rowItemSelected[0]).getChild(m.top.rowItemSelected[1])
    m.top.selectedItem = invalid
end sub

sub onRowItemFocused()
    m.top.focusedItem = m.top.content.getChild(m.top.rowItemFocused[0]).getChild(m.top.rowItemFocused[1])
end sub
'//# sourceMappingURL=./ExtrasRowList.brs.map