'import "pkg:/source/api/sdk.bs"
'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/KeyCode.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.top.optionsAvailable = false
    m.languageButton = m.top.findNode("languageButton")
    m.searchButton = m.top.findNode("searchButton")
    m.mySubtitleList = m.top.findNode("mySubtitleList")
    mySubtitleBackground = m.top.findNode("mySubtitleBackground")
    mySubtitleBackground.color = "#101420"
    m.languageButton.textColor = "#101010"
    m.languageButton.focusTextColor = "#ffffff"
    m.languageButton.background = "#ffffff"
    m.languageButton.focusBackground = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    m.searchButton.background = "#c8fafa"
    m.searchButton.color = "#101010"
    m.searchButton.focusBackground = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    m.searchButton.focusColor = "#ffffff"
    m.mySubtitleList.focusBitmapBlendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    m.mySubtitleList.focusFootprintBlendColor = "#ffffff"
    headerText = m.top.findNode("headerText")
    headerText.font.size = "45"
    m.searchButton.focus = true
    m.searchButton.setFocus(true)
end sub

sub onItemContentChanged()
    if not isValid(m.top.itemContent) then
        return
    end if
    itemContent = m.top.itemContent
    mySubtitles = CreateObject("roSGNode", "ContentNode")
    for each stream in itemContent.json.mediastreams
        if LCase(stream.type) = "subtitle"
            mySubtitle = mySubtitles.createChild("SubtitleData")
            mySubtitle.index = stream.index
            mySubtitle.path = stream.path
            mySubtitle.displaytitle = stream.displaytitle
            mySubtitle.canDelete = stream.isExternal
        end if
    end for
    m.mySubtitleList.content = mySubtitles
    m.top.overhangTitle = itemContent.json.name
    m.top.findNode("moviePoster").uri = itemContent.posterURL
    path = CreateObject("roPath", itemContent.json.path)
    m.top.findNode("fileName").text = path.Split().filename
end sub

sub setDefaultSubtitleLanguage()
    if not isValidAndNotEmpty(m.top.preferredSubtitleLanguage) then
        return
    end if
    if not isValidAndNotEmpty(m.top.cultures) then
        return
    end if
    preferredSubtitleLanguage = LCase(m.top.preferredSubtitleLanguage)
    for each culture in m.top.cultures
        if LCase(culture.ThreeLetterISOLanguageName) = preferredSubtitleLanguage
            m.top.selectedCulture = culture
            exit for
        end if
    end for
end sub

sub onSelectedCultureChanged()
    if not isValid(m.top.selectedCulture) then
        return
    end if
    selectedCulture = m.top.selectedCulture
    m.languageButton.text = selectedCulture.DisplayName
    ' Once language is selected, move focus to search button
    m.languageButton.focus = false
    m.searchButton.focus = true
    m.searchButton.setFocus(true)
    group = m.global.sceneManager.callFunc("getActiveScene")
    group.lastFocus = m.searchButton
end sub

sub OnScreenShown()
    if isValid(m.top.lastFocus)
        m.top.lastFocus.setFocus(true)
        if m.top.lastFocus.isSubType("StandardButton") or m.top.lastFocus.isSubType("TextButton")
            m.top.lastFocus.focus = true
        end if
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.top.lastFocus
    else
        m.top.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.searchButton
        m.searchButton.focus = true
    end if
end sub

' Handle navigation input from the remote and act on it
function onKeyEvent(key as string, press as boolean) as boolean
    if not press
        if key = "replay"
            group = m.global.sceneManager.callFunc("getActiveScene")
            if isValid(group.lastFocus)
                if group.lastFocus.isSubType("StandardButton") or group.lastFocus.isSubType("TextButton")
                    group.lastFocus.focus = true
                end if
            end if
        end if
        return false
    end if
    if key = "replay"
        m.searchButton.focus = false
        m.languageButton.focus = false
        return false
    end if
    if key = "OK" and m.mySubtitleList.isinFocusChain()
        subtitleToDelete = m.mySubtitleList.content.getChild(m.mySubtitleList.itemSelected)
        if not subtitleToDelete.canDelete then
            return false
        end if
        m.top.subtitleToDelete = subtitleToDelete
        m.top.subtitleToDelete = invalid
        return true
    end if
    if key = "OK" and m.languageButton.hasFocus()
        startLoadingSpinner()
        m.languageButton.selected = not m.languageButton.selected
        return true
    end if
    if key = "OK" and m.searchButton.focus
        m.searchButton.selected = not m.searchButton.selected
        return true
    end if
    if key = "up" and m.searchButton.focus
        m.searchButton.focus = false
        m.languageButton.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.languageButton
        m.languageButton.focus = true
        return true
    end if
    if key = "down" and m.languageButton.hasFocus()
        m.languageButton.focus = false
        m.searchButton.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.searchButton
        m.searchButton.focus = true
        return true
    end if
    if key = "right"
        if m.mySubtitleList.content.getChildCount() = 0
            return false
        end if
        if m.languageButton.hasFocus()
            m.languageButton.focus = false
        end if
        if m.mySubtitleList.hasFocus()
            return false
        end if
        m.searchButton.focus = false
        m.mySubtitleList.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.mySubtitleList
        return true
    end if
    if key = "left" and m.mySubtitleList.isinFocusChain()
        m.searchButton.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.searchButton
        m.searchButton.focus = true
        return true
    end if
    return false
end function
'//# sourceMappingURL=./SubtitleSearchView.brs.map