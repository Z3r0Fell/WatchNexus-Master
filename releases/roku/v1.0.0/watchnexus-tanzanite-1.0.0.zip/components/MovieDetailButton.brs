'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.top.iconSide = "left"
    m.buttonBackground = m.top.findNode("buttonBackground")
    m.buttonIcon = m.top.findNode("buttonIcon")
    m.buttonText = m.top.findNode("buttonText")
end sub

sub itemContentChanged()
    itemData = m.top.itemContent
    m.buttonText.color = "#ffffff"
    m.buttonText.font.size = itemData.fontSize
    m.buttonBackground.blendColor = "0x00000000"
    m.buttonIcon.uri = itemData.icon
    m.buttonIcon.blendcolor = itemData.iconBlendColor
    m.buttonText.text = itemData.text
    m.buttonBackground.height = itemData.height
    m.buttonBackground.width = itemData.width
    m.focusTextColor = "#ffffff"
    m.textColor = "#ffffff"
    m.focusBackground = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    m.focusIcon = itemData.focusIcon
    m.icon = itemData.icon
    m.background = "0x00000000"
    m.height = itemData.height
    m.width = itemData.width
    m.padding = itemData.padding
    m.iconSide = itemData.iconSide
    setIconSize()
    m.buttonText.height = m.height
    m.top.focus = itemData.focus
    onFocusChanged()
end sub

sub onFocusChanged()
    if m.top.focus
        m.buttonText.color = m.focusTextColor
        if m.focusIcon <> "" then
            m.buttonIcon.uri = m.focusIcon
        else
            m.buttonIcon.uri = m.icon
        end if
    else
        m.buttonText.color = m.textColor
        m.buttonIcon.uri = m.icon
    end if
end sub

sub setIconSize()
    height = m.buttonBackground.height
    width = m.buttonBackground.width
    if height > 0 and width > 0
        ' TODO: Use smallest number between them
        m.buttonIcon.height = m.height
        if m.padding > 0
            m.buttonIcon.height = m.buttonIcon.height - m.padding
        end if
        m.buttonIcon.width = m.buttonIcon.height
        ' Set Icon translation
        if LCase(m.iconSide) = "right"
            m.buttonIcon.translation = [
                m.buttonBackground.width - m.padding - m.buttonIcon.width
                ((height - m.buttonIcon.height) / 2)
            ]
            m.buttonText.translation = [
                m.padding
                0
            ]
        else
            m.buttonIcon.translation = [
                m.padding
                ((height - m.buttonIcon.height) / 2)
            ]
            m.buttonText.translation = [
                m.padding + m.buttonIcon.width + 20
                0
            ]
        end if
        ' Set text max width
        m.buttonText.maxWidth = m.width - m.padding - m.buttonIcon.width - 40
    end if
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        return false
    end if
    if key = "right" and m.top.focus
        m.top.escape = "right"
    end if
    if key = "left" and m.top.focus
        m.top.escape = "left"
    end if
    return false
end function
'//# sourceMappingURL=./MovieDetailButton.brs.map