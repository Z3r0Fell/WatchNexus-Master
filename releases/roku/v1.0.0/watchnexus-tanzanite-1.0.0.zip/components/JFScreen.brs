sub init()
end sub

' Function called when the screen is displayed by the screen manager
' It is expected that screens override this function to handle focus
' managmenet and any other actions required on screen shown
sub OnScreenShown()
    if m.top.lastFocus <> invalid
        m.top.lastFocus.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.top.lastFocus
    else
        m.top.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.top
    end if
end sub

' Function called when the screen is hidden by the screen manager
' It is expected that screens override this function if required,
' to handle focus any actions required on the screen being hidden
sub OnScreenHidden()
end sub
'//# sourceMappingURL=./JFScreen.brs.map