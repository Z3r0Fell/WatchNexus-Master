'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/KeyCode.bs"
'import "pkg:/source/enums/TaskControl.bs"
'import "pkg:/source/utils/config.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.top.optionsAvailable = false
    m.top.setFocus(true)
    m.serverPicker = m.top.findNode("serverPicker")
    m.serverUrlTextbox = m.top.findNode("serverUrlTextbox")
    m.serverUrlContainer = m.top.findNode("serverUrlContainer")
    m.serverPickerContainer = m.top.findNode("serverPickerContainer")
    m.serverUrlOutline = m.top.findNode("serverUrlOutline")
    m.serverUrlOutline.blendColor = "0xff6867FF"
    m.serverPickerContainer.color = "#101420"
    m.serverUrlContainer.color = "0x00000077"
    m.submit = m.top.findNode("submit")
    m.submit.background = "#c8fafa"
    m.submit.color = "#101010"
    m.submit.focusBackground = "0xff6867FF"
    m.submit.focusColor = "#ffffff"
    m.top.observeField("serverUrl", "clearErrorMessage")
    ScanForServers()
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        return true
    end if
    if key = "right"
        if m.serverPicker.hasFocus()
            selectedServer = m.serverPicker.content.getChild(m.serverPicker.itemFocused)
            if chainLookupReturn(selectedServer, "isSavedServer", false)
                selectedServer.itemHasDeleteFocus = true
                return true
            end if
        end if
    end if
    if key = "left"
        if m.serverPicker.hasFocus()
            selectedServer = m.serverPicker.content.getChild(m.serverPicker.itemFocused)
            if isValid(selectedServer)
                selectedServer.itemHasDeleteFocus = false
            end if
            return true
        end if
    end if
    if key = "OK"
        if m.serverPicker.hasFocus()
            selectedServer = m.serverPicker.content.getChild(m.serverPicker.itemFocused)
            if chainLookupReturn(selectedServer, "itemHasDeleteFocus", false)
                m.top.forgetServer = selectedServer.baseUrl
                return true
            end if
            m.top.serverUrl = selectedServer.baseUrl
            m.submit.setFocus(true)
            m.submit.focus = true
            return true
        end if
        if m.submit.hasFocus()
            m.submit.selected = not m.submit.selected
            return true
        end if
        if m.serverUrlContainer.hasFocus()
            ShowKeyboard()
            return true
        end if
        return false
    end if
    if key = "down"
        if m.serverPicker.hasFocus() and m.serverPicker.content.getChildCount() > 0 and m.serverPicker.itemFocused = m.serverPicker.content.getChildCount() - 1
            m.serverUrlContainer.setFocus(true)
            m.serverUrlOutline.visible = true
            return true
        end if
        if m.serverUrlContainer.hasFocus()
            m.serverUrlOutline.visible = false
            m.submit.setFocus(true)
            m.submit.focus = true
            return true
        end if
        return false
    end if
    if key = "up"
        if m.serverUrlContainer.hasFocus() and isValidAndNotEmpty(m.servers)
            m.serverPicker.setFocus(true)
            m.serverUrlOutline.visible = false
            return true
        end if
        if m.serverUrlContainer.hasFocus() and m.servers.Count() = 0
            ScanForServers()
            m.serverUrlOutline.visible = false
            return true
        end if
        if m.submit.hasFocus()
            m.serverUrlContainer.setFocus(true)
            m.serverUrlOutline.visible = true
            m.submit.focus = false
            return true
        end if
        return false
    end if
    if key = "back"
        if m.serverUrlContainer.hasFocus() and isValidAndNotEmpty(m.servers)
            m.serverUrlOutline.visible = false
            m.serverPicker.setFocus(true)
            return true
        end if
        if m.submit.hasFocus() and isValidAndNotEmpty(m.servers)
            m.serverPicker.setFocus(true)
            return true
        end if
        if m.submit.hasFocus() and m.servers.Count() = 0
            m.serverUrlOutline.visible = true
            m.serverUrlContainer.setFocus(true)
            return true
        end if
        if m.serverUrlContainer.hasFocus() and m.servers.Count() = 0
            ScanForServers()
            return true
        end if
        if m.serverPicker.hasFocus() and isValidAndNotEmpty(m.servers)
            ScanForServers()
            return true
        end if
        return false
    end if
    return false
end function

sub ScanForServers()
    m.ssdpScanner = CreateObject("roSGNode", "ServerDiscoveryTask")
    m.ssdpScanner.observeField("content", "ScanForServersComplete")
    m.ssdpScanner.control = "RUN"
    startLoadingSpinner(false)
end sub

sub ScanForServersComplete(event)
    m.servers = event.getData()
    items = CreateObject("roSGNode", "ServerData")
    for each server in m.servers
        server.isSavedServer = false
        server.subtype = "ServerData"
        'add new fields for every server property onto the ContentNode (rather than making a dedicated component just to hold data...)
        items.update([
            server
        ], true)
    end for
    'load any previously logged in to servers as well (if they aren't already discovered on the local network)
    saved = get_setting("saved_servers")
    if isValid(saved)
        savedServers = ParseJson(saved)
        for each server in savedServers.serverList
            alreadyListed = false
            for each listed in m.servers
                if LCase(listed.baseUrl) = server.baseUrl 'saved server data is always lowercase
                    alreadyListed = true
                    exit for
                end if
            end for
            if alreadyListed = false
                server.isSavedServer = true
                items.update([
                    server
                ], true)
                m.servers.push(server)
            end if
        end for
    end if
    m.serverPicker.content = items
    stopLoadingSpinner()
    'if we have at least one server, focus on the server picker
    if m.servers.Count() > 0
        m.serverPicker.setFocus(true)
        'no servers found...focus on the input textbox
    else
        m.serverUrlContainer.setFocus(true)
        'show/hide input box outline
        m.serverUrlOutline.visible = true
    end if
end sub

sub ShowKeyboard()
    dialog = createObject("roSGNode", "StandardKeyboardDialog")
    dialog.title = tr("Enter the server name or ip address")
    dialog.buttons = [
        tr("OK")
        tr("Cancel")
    ]
    dialog.text = m.serverUrlTextbox.text
    palette = createObject("roSGNode", "RSGPalette")
    palette.colors = {
        DialogBackgroundColor: "#101420"
    }
    dialog.palette = palette
    m.top.getscene().dialog = dialog
    m.dialog = dialog
    dialog.observeField("buttonSelected", "onDialogButton")
end sub

function onDialogButton()
    d = m.dialog
    button_text = d.buttons[d.buttonSelected]
    if button_text = tr("OK")
        m.serverUrlTextbox.text = d.text
        m.dialog.close = true
        return true
    else if button_text = tr("Cancel")
        m.dialog.close = true
        return true
    else
        return false
    end if
end function

sub clearErrorMessage()
    m.top.errorMessage = ""
end sub
'//# sourceMappingURL=./SetServerScreen.brs.map