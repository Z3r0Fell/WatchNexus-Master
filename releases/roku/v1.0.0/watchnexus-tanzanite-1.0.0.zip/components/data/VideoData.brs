'import "pkg:/source/api/baserequest.bs"
'import "pkg:/source/api/Image.bs"
'import "pkg:/source/utils/config.bs"

sub setFields()
    json = m.top.json
    m.top.id = json.id
    m.top.Title = json.name
    m.top.Description = json.overview
    m.top.favorite = json.UserData.isFavorite
    m.top.watched = chainLookup(json, "UserData.played")
    m.top.Type = "Video"
    setPoster()
end sub

sub setPoster()
    if m.top.image <> invalid
        m.top.posterURL = m.top.image.url
    else if m.top.json.ImageTags.Primary <> invalid
        imgParams = {
            "maxHeight": 440
            "maxWidth": 295
            "Tag": m.top.json.ImageTags.Primary
        }
        m.top.posterURL = ImageURL(m.top.json.id, "Primary", imgParams)
    end if
end sub
'//# sourceMappingURL=./VideoData.brs.map