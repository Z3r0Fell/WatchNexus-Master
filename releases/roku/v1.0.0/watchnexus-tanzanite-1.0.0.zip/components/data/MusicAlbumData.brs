'import "pkg:/source/utils/misc.bs"

sub setFields()
    datum = m.top.json
    m.top.id = datum.id
    m.top.title = datum.name
    m.top.overview = datum.overview
end sub

sub setPoster()
    if isvalid(m.top.image)
        m.top.posterURL = m.top.image.url
    else
        m.top.posterURL = "pkg:/images/icons/album.png"
    end if
end sub
'//# sourceMappingURL=./MusicAlbumData.brs.map