'import "pkg:/source/api/baserequest.bs"
'import "pkg:/source/api/Image.bs"
'import "pkg:/source/utils/config.bs"

sub setFields()
    json = m.top.json
    m.top.id = json.id
    m.top.Title = json.name
    m.top.Type = "Folder"
    m.top.iconUrl = "pkg:/images/media_type_icons/folder_white.png"
    ' This is a temporary measure to avoid displaying landscape photos
    ' in GridItem components that only support portrait. It will be fixed
    ' after the ItemGrid is reworked.
    if m.top.json.Type <> "CollectionFolder"
        setPoster()
    end if
end sub

sub setPoster()
    if m.top.image <> invalid
        m.top.posterURL = m.top.image.url
    else if m.top.json.Type = "Studio"
        imgParams = {
            "maxHeight": 440
            "maxWidth": 295
            "Tag": m.top.json.ParentThumbImageTag
        }
        m.top.posterURL = ImageURL(m.top.json.id, "Thumb", imgParams)
    else if m.top.json.ImageTags.Primary <> invalid
        imgParams = {
            "maxHeight": 440
            "maxWidth": 295
            "Tag": m.top.json.ImageTags.Primary
        }
        m.top.posterURL = ImageURL(m.top.json.id, "Primary", imgParams)
    end if
end sub

sub setWatched(isWatched as boolean, unplayedItemCount = 0 as integer)
    if not isValid(m.top.json) then
        return
    end if
    json = m.top.json
    if isChainValid(json, "UserData.Played")
        json.UserData.AddReplace("Played", isWatched)
        json.UserData.AddReplace("PlaybackPositionTicks", 0)
        if isWatched
            json.UserData.AddReplace("UnplayedItemCount", 0)
        else
            if unplayedItemCount = 0
                if isValid(json.RecursiveItemCount)
                    json.UserData.AddReplace("UnplayedItemCount", json.RecursiveItemCount)
                end if
            else
                json.UserData.AddReplace("UnplayedItemCount", unplayedItemCount)
            end if
        end if
        m.top.json = json
    end if
    m.top.watched = isWatched
end sub
'//# sourceMappingURL=./FolderData.brs.map