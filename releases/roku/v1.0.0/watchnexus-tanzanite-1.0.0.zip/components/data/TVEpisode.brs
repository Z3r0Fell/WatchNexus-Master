'import "pkg:/source/api/baserequest.bs"
'import "pkg:/source/api/Image.bs"
'import "pkg:/source/utils/config.bs"

sub setFields()
    json = m.top.json
    m.top.id = json.id
    m.top.Description = json.overview
    m.top.favorite = json.UserData.isFavorite
    m.top.watched = chainLookup(json, "UserData.played")
    m.top.Type = json.Type
    setPoster()
end sub

sub setPoster()
    if m.top.image <> invalid
        m.top.posterURL = m.top.image.url
    else if m.top.json.ImageTags.Primary <> invalid
        imgParams = {
            "maxHeight": 440
            "maxWidth": 295
        }
        m.top.posterURL = ImageURL(m.top.json.id, "Primary", imgParams)
    end if
end sub

' Set Watched Status
' Called from VisualLibraryScene.
' unplayedItemCount is not used for Movies (but signature needs to match)
sub setWatched(isWatched as boolean, unplayedItemCount = 0 as integer)
    if not isValid(m.top.json) then
        return
    end if
    json = m.top.json
    if isChainValid(json, "UserData.Played")
        json.UserData.AddReplace("Played", isWatched)
        json.UserData.AddReplace("PlaybackPositionTicks", 0)
        m.top.json = json
    end if
    m.top.watched = isWatched
end sub
'//# sourceMappingURL=./TVEpisode.brs.map