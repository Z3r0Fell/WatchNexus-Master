'import "pkg:/source/enums/ItemType.bs"
'import "pkg:/source/utils/misc.bs"

sub setFields()
    if not isValid(m.top.json) then
        return
    end if
    datum = m.top.json
    m.top.id = datum.id
    m.top.type = "episode"
    m.top.title = datum.name
    m.top.showID = datum.SeriesID
    m.top.seasonID = datum.SeasonID
    m.top.overview = datum.overview
    m.top.favorite = datum.UserData.isFavorite
    m.top.watched = chainLookup(datum, "UserData.played")
end sub

sub setPoster()
    if isValid(m.top.image)
        m.top.posterURL = m.top.image.url
    else
        m.top.posterURL = ""
    end if
end sub
'//# sourceMappingURL=./TVEpisodeData.brs.map