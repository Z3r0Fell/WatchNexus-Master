'import "pkg:/source/api/baserequest.bs"
'import "pkg:/source/api/Image.bs"
'import "pkg:/source/enums/ItemType.bs"
'import "pkg:/source/utils/config.bs"

sub setData()
    ' We keep json around just as a reference,
    ' but ideally everything should be going through one of the interfaces
    datum = m.top.json
    m.top.id = datum.LookupCI("Id")
    m.top.name = datum.LookupCI("name")
    m.top.type = datum.LookupCI("type")
    if datum.CollectionType = invalid
        m.top.CollectionType = datum.type
    else
        m.top.CollectionType = datum.CollectionType
    end if
    ' Set appropriate Images for Wide and Tall based on type
    if LCase(datum.type) = "collectionfolder" or LCase(datum.type) = "userview"
        if IsValid(datum.ImageTags)
            params = {
                "Tag": datum.ImageTags.Primary
                "maxHeight": 261
                "maxWidth": 464
            }
            m.top.thumbnailURL = ImageURL(datum.LookupCI("Id"), "Primary", params)
            m.top.widePosterUrl = m.top.thumbnailURL
        end if
        ' Add Icon URLs for display if there is no Poster
        if LCase(m.top.CollectionType) = "livetv"
            m.top.iconUrl = "pkg:/images/media_type_icons/live_tv_white.png"
        else if LCase(m.top.CollectionType) = "folders" or LCase(m.top.CollectionType) = "nextup"
            m.top.iconUrl = "pkg:/images/media_type_icons/folder_white.png"
        else if isStringEqual(m.top.CollectionType, "mylist")
            m.top.iconUrl = "pkg:/images/icons/star.png"
        end if
    else if datum.type = "Episode" or LCase(datum.type) = "recording" or datum.type = "MusicVideo"
        m.top.isWatched = datum.UserData.Played
        imgParams = {}
        imgParams.Append({
            "maxHeight": 261
        })
        imgParams.Append({
            "maxWidth": 464
        })
        if datum.ImageTags.Primary <> invalid
            param = {
                "Tag": datum.ImageTags.Primary
            }
            imgParams.Append(param)
        end if
        m.top.thumbnailURL = ImageURL(datum.LookupCI("Id"), "Primary", imgParams)
        ' Add Wide Poster  (Series Backdrop)
        if datum.ParentThumbImageTag <> invalid
            imgParams["Tag"] = datum.ParentThumbImageTag
            m.top.widePosterUrl = ImageURL(datum.ParentThumbItemId, "Thumb", imgParams)
        else if datum.ParentBackdropImageTags <> invalid
            imgParams["Tag"] = datum.ParentBackdropImageTags[0]
            m.top.widePosterUrl = ImageURL(datum.ParentBackdropItemId, "Backdrop", imgParams)
        else if datum.ImageTags.Primary <> invalid
            imgParams["Tag"] = datum.SeriesPrimaryImageTag
            m.top.widePosterUrl = ImageURL(datum.LookupCI("Id"), "Primary", imgParams)
        end if
        ' If no widePosterUrl has been determined, revent to thumbnailURL
        if not isValidAndNotEmpty(m.top.widePosterUrl)
            m.top.widePosterUrl = m.top.thumbnailURL
        end if
    else if datum.type = "Series"
        m.top.isWatched = datum.UserData.Played
        imgParams = {
            "maxHeight": 261
        }
        imgParams.Append({
            "maxWidth": 464
        })
        m.top.posterURL = ImageURL(datum.LookupCI("Id"), "Primary", imgParams)
        ' Add Wide Poster  (Series Backdrop)
        if datum.ImageTags <> invalid and datum.imageTags.Thumb <> invalid
            imgParams["Tag"] = datum.imageTags.Thumb
            m.top.widePosterUrl = ImageURL(datum.LookupCI("Id"), "Thumb", imgParams)
        else if datum.BackdropImageTags <> invalid
            imgParams["Tag"] = datum.BackdropImageTags[0]
            m.top.widePosterUrl = ImageURL(datum.LookupCI("Id"), "Backdrop", imgParams)
        end if
    else if datum.type = "Movie"
        m.top.isWatched = datum.UserData.Played
        imgParams = {}
        imgParams.Append({
            "maxHeight": 261
        })
        imgParams.Append({
            "maxWidth": 175
        })
        if datum.ImageTags.Primary <> invalid
            param = {
                "Tag": datum.ImageTags.Primary
            }
            imgParams.Append(param)
        end if
        m.top.posterURL = ImageURL(datum.LookupCI("Id"), "Primary", imgParams)
        ' For wide image, use backdrop
        imgParams["maxWidth"] = 464
        if datum.ImageTags <> invalid and datum.imageTags.Thumb <> invalid
            imgParams["Tag"] = datum.imageTags.Thumb
            m.top.thumbnailUrl = ImageURL(datum.LookupCI("Id"), "Thumb", imgParams)
        else if datum.BackdropImageTags[0] <> invalid
            imgParams["Tag"] = datum.BackdropImageTags[0]
            m.top.thumbnailUrl = ImageURL(datum.LookupCI("Id"), "Backdrop", imgParams)
        end if
    else if datum.type = "Video"
        m.top.isWatched = datum.UserData.Played
        imgParams = {
            "maxHeight": 261
            "maxWidth": 464
        }
        if datum.ImageTags <> invalid and datum.ImageTags.Primary <> invalid
            imgParams.Append({
                "Tag": datum.ImageTags.Primary
            })
        end if
        m.top.posterURL = ImageURL(datum.LookupCI("Id"), "Primary", imgParams)
        m.top.thumbnailUrl = m.top.posterURL
    else if datum.type = "MusicAlbum"
        params = {
            "Tag": datum.ImageTags.Primary
            "maxHeight": 261
            "maxWidth": 261
        }
        m.top.thumbnailURL = ImageURL(datum.LookupCI("Id"), "Primary", params)
        m.top.widePosterUrl = m.top.thumbnailURL
        m.top.posterUrl = m.top.thumbnailURL
    else if datum.type = "TvChannel" or datum.type = "Channel"
        params = {
            "Tag": datum.ImageTags.Primary
            "maxHeight": 261
            "maxWidth": 464
        }
        m.top.thumbnailURL = ImageURL(datum.LookupCI("Id"), "Primary", params)
        m.top.widePosterUrl = m.top.thumbnailURL
        m.top.iconUrl = "pkg:/images/media_type_icons/live_tv_white.png"
    else if datum.type = "Photo"
        params = {
            "Tag": datum.ImageTags.Primary
            "maxHeight": 261
            "maxWidth": 464
        }
        m.top.thumbnailURL = ImageURL(datum.LookupCI("Id"), "Primary", params)
        m.top.widePosterUrl = m.top.thumbnailURL
        m.top.posterUrl = m.top.thumbnailURL
    else if datum.type = "PhotoAlbum"
        params = {
            "Tag": datum.ImageTags.Primary
            "maxHeight": 261
            "maxWidth": 464
        }
        m.top.thumbnailURL = ImageURL(datum.LookupCI("Id"), "Primary", params)
        m.top.widePosterUrl = m.top.thumbnailURL
        m.top.posterUrl = m.top.thumbnailURL
    end if
end sub
'//# sourceMappingURL=./HomeData.brs.map