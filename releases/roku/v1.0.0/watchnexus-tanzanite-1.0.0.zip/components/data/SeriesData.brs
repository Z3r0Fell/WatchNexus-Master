'import "pkg:/source/api/baserequest.bs"
'import "pkg:/source/api/Image.bs"
'import "pkg:/source/utils/config.bs"

sub setFields()
    json = m.top.json
    m.top.id = json.id
    m.top.Title = json.name
    m.top.Description = json.overview
    m.top.favorite = json.UserData.isFavorite
    m.top.watched = chainLookup(json, "UserData.played")
    m.top.Type = "Series"
    m.top.overview = json.overview
    if json.ProductionYear <> invalid
        m.top.SubTitle = json.ProductionYear
    end if
    if json.OfficialRating <> invalid and json.OfficialRating <> ""
        m.top.Rating = json.OfficialRating
        if m.top.SubTitle <> ""
            m.top.SubTitle = m.top.SubTitle + " - " + m.top.Rating
        else
            m.top.SubTitle = m.top.Rating
        end if
    end if
    setPoster()
end sub

sub setWatched(isWatched as boolean, unplayedItemCount = 0 as integer)
    if not isValid(m.top.json) then
        return
    end if
    json = m.top.json
    if isChainValid(json, "UserData.Played")
        json.UserData.AddReplace("Played", isWatched)
        json.UserData.AddReplace("PlaybackPositionTicks", 0)
        if isWatched
            json.UserData.AddReplace("UnplayedItemCount", 0)
        else
            if unplayedItemCount = 0
                if isValid(json.RecursiveItemCount)
                    json.UserData.AddReplace("UnplayedItemCount", json.RecursiveItemCount)
                end if
            else
                json.UserData.AddReplace("UnplayedItemCount", unplayedItemCount)
            end if
        end if
        m.top.json = json
    end if
    m.top.watched = isWatched
end sub

sub setPoster()
    if m.top.image <> invalid
        m.top.posterURL = m.top.image.url
    else
        if m.top.json.ImageTags.Primary <> invalid
            imgParams = {
                "maxHeight": 440
                "maxWidth": 295
                "Tag": m.top.json.ImageTags.Primary
            }
            m.top.posterURL = ImageURL(m.top.json.id, "Primary", imgParams)
        else if m.top.json.BackdropImageTags <> invalid
            imgParams = {
                "maxHeight": 440
                "Tag": m.top.json.BackdropImageTags[0]
            }
            m.top.posterURL = ImageURL(m.top.json.id, "Backdrop", imgParams)
        end if
        if isChainValid(m.top.json, "ImageTags.Thumb")
            imgParams = {
                "maxHeight": 331
                "maxWidth": 464
                "Tag": chainLookup(m.top.json, "ImageTags.Thumb")
            }
            m.top.landscapePosterURL = ImageURL(m.top.json.id, "Thumb", imgParams)
        end if
        ' Add Backdrop Image
        if m.top.json.BackdropImageTags <> invalid
            imgParams = {
                "maxHeight": 720
                "maxWidth": 1280
                "Tag": m.top.json.BackdropImageTags[0]
            }
            m.top.backdropURL = ImageURL(m.top.json.id, "Backdrop", imgParams)
        end if
    end if
end sub
'//# sourceMappingURL=./SeriesData.brs.map