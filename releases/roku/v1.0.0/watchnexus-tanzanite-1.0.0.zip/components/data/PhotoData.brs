'import "pkg:/source/api/Image.bs"
'import "pkg:/source/api/baserequest.bs"
'import "pkg:/source/utils/config.bs"

sub setFields()
    json = m.top.json
    m.top.id = json.id
    m.top.Title = json.name
    m.top.Type = "Photo"
    setPoster()
end sub

sub setPoster()
    if m.top.image <> invalid
        m.top.posterURL = m.top.image.url
    else
        if m.top.json.ImageTags.Primary <> invalid
            imgParams = {
                "maxHeight": 440
                "maxWidth": 295
                "Tag": m.top.json.ImageTags.Primary
            }
            m.top.posterURL = ImageURL(m.top.json.id, "Primary", imgParams)
        else if m.top.json.BackdropImageTags[0] <> invalid
            imgParams = {
                "maxHeight": 440
                "Tag": m.top.json.BackdropImageTags[0]
            }
            m.top.posterURL = ImageURL(m.top.json.id, "Backdrop", imgParams)
        else if m.top.json.ParentThumbImageTag <> invalid and m.top.json.ParentThumbItemId <> invalid
            imgParams = {
                "maxHeight": 440
                "maxWidth": 295
                "Tag": m.top.json.ParentThumbImageTag
            }
            m.top.posterURL = ImageURL(m.top.json.ParentThumbItemId, "Thumb", imgParams)
        end if
        ' Add Backdrop Image
        if m.top.json.BackdropImageTags[0] <> invalid
            imgParams = {
                "maxHeight": 720
                "maxWidth": 1280
                "Tag": m.top.json.BackdropImageTags[0]
            }
            m.top.backdropURL = ImageURL(m.top.json.id, "Backdrop", imgParams)
        end if
    end if
end sub
'//# sourceMappingURL=./PhotoData.brs.map