'import "pkg:/source/api/baserequest.bs"
'import "pkg:/source/api/Image.bs"
'import "pkg:/source/utils/config.bs"

sub setFields()
    json = m.top.json
    m.top.id = json.id
    m.top.favorite = json.UserData.isFavorite
    m.top.Type = "MusicAlbum"
    setPoster()
end sub

sub setPoster()
    if m.top.image <> invalid
        m.top.posterURL = m.top.image.url
    else
        if m.top.json.ImageTags.Primary <> invalid
            imgParams = {
                "maxHeight": 400
                "maxWidth": 400
            }
            m.top.posterURL = ImageURL(m.top.json.id, "Primary", imgParams)
        else if m.top.json.BackdropImageTags[0] <> invalid
            imgParams = {
                "maxHeight": 400
            }
            m.top.posterURL = ImageURL(m.top.json.id, "Backdrop", imgParams)
        else if m.top.json.ParentThumbImageTag <> invalid and m.top.json.ParentThumbItemId <> invalid
            imgParams = {
                "maxHeight": 400
                "maxWidth": 400
            }
            m.top.posterURL = ImageURL(m.top.json.ParentThumbItemId, "Thumb", imgParams)
        end if
        ' Add Backdrop Image
        if m.top.json.BackdropImageTags[0] <> invalid
            imgParams = {
                "maxHeight": 1200
                "maxWidth": 1920
            }
            m.top.backdropURL = ImageURL(m.top.json.id, "Backdrop", imgParams)
        end if
    end if
end sub
'//# sourceMappingURL=./MusicAlbumSongListData.brs.map