' Called whenever m.top.json changes.
' It is expected that each node that extends JFContentItem will override this function
sub setFields()
end sub
'//# sourceMappingURL=./ServerData.brs.map