'import "pkg:/source/api/baserequest.bs"
'import "pkg:/source/api/Image.bs"
'import "pkg:/source/utils/config.bs"

sub init()
    m.top.overview = "boxsets"
end sub

sub setFields()
    json = m.top.json
    m.top.id = json.id
    m.top.Title = json.name
    m.top.overview = json.overview
    m.top.Description = json.overview
    m.top.favorite = chainLookupReturn(json, "UserData.isFavorite", false)
    m.top.watched = chainLookupReturn(json, "UserData.played", false)
    m.top.Type = "Boxset"
    setPoster()
end sub

sub setWatched(isWatched as boolean, unplayedItemCount = 0 as integer)
    if not isValid(m.top.json) then
        return
    end if
    json = m.top.json
    if isChainValid(json, "UserData.Played")
        json.UserData.AddReplace("Played", isWatched)
        json.UserData.AddReplace("PlaybackPositionTicks", 0)
        if isWatched
            json.UserData.AddReplace("UnplayedItemCount", 0)
        else
            if unplayedItemCount = 0
                if isValid(json.RecursiveItemCount)
                    json.UserData.AddReplace("UnplayedItemCount", json.RecursiveItemCount)
                end if
            else
                json.UserData.AddReplace("UnplayedItemCount", unplayedItemCount)
            end if
        end if
        m.top.json = json
    end if
    m.top.watched = isWatched
end sub

sub setPoster()
    if m.top.image <> invalid
        m.top.posterURL = m.top.image.url
    else
        if m.top.json.ImageTags.Primary <> invalid
            imgParams = {
                "maxHeight": 440
                "maxWidth": 295
                "Tag": m.top.json.ImageTags.Primary
            }
            m.top.posterURL = ImageURL(m.top.json.id, "Primary", imgParams)
        else if m.top.json.BackdropImageTags <> invalid
            imgParams = {
                "maxHeight": 440
                "Tag": m.top.json.BackdropImageTags[0]
            }
            m.top.posterURL = ImageURL(m.top.json.id, "Backdrop", imgParams)
        end if
        ' Add Backdrop Image
        if m.top.json.BackdropImageTags <> invalid
            imgParams = {
                "maxHeight": 720
                "maxWidth": 1280
                "Tag": m.top.json.BackdropImageTags[0]
            }
            m.top.backdropURL = ImageURL(m.top.json.id, "Backdrop", imgParams)
        end if
    end if
end sub
'//# sourceMappingURL=./CollectionData.brs.map