'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/String.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.params = {}
    m.groups = []
    m.scene = m.top.getScene()
    m.content = m.scene.findNode("content")
    m.overhang = m.scene.findNode("overhang")
end sub

'
' Push a new group onto the stack, replacing the existing group on the screen
sub pushScene(newGroup)
    currentGroup = m.groups.peek()
    if isValid(newGroup)
        if isValid(currentGroup)
            'Search through group and store off last focused item
            if currentGroup.focusedChild <> invalid
                focused = currentGroup.focusedChild
                while focused.hasFocus() = false
                    focused = focused.focusedChild
                end while
                currentGroup.lastFocus = focused
                currentGroup.setFocus(false)
            else
                currentGroup.setFocus(false)
            end if
            if currentGroup.isSubType("JFGroup")
                unregisterOverhangData(currentGroup)
            end if
            currentGroup.visible = false
            if currentGroup.isSubType("JFScreen")
                currentGroup.callFunc("OnScreenHidden")
            end if
        end if
        ' If we are moving in to a movie detail view, reset preferred audio track index
        if newGroup.isSubType("MovieDetails")
            m.global.queueManager.callFunc("setPreferredAudioTrackIndex", -1)
            m.global.queueManager.callFunc("setPreferredAudioTrackName", "")
        end if
        m.groups.push(newGroup)
        if currentGroup <> invalid
            m.content.replaceChild(newGroup, 0)
        else
            m.content.appendChild(newGroup)
        end if
        if newGroup.isSubType("JFScreen")
            newGroup.callFunc("OnScreenShown")
        end if
        'observe info about new group, set overhang title, etc.
        if newGroup.isSubType("JFGroup")
            registerOverhangData(newGroup)
            ' Some groups set focus to a specific component within init(), so we don't want to
            ' change if that is the case.
            if newGroup.isInFocusChain() = false
                newGroup.setFocus(true)
            end if
        end if
    else
        currentGroup.focusedChild.setFocus(true)
    end if
end sub

'
' Remove the current group and load the last group from the stack
sub popScene()
    group = m.groups.pop()
    if isValid(group)
        if group.isSubType("JFGroup")
            unregisterOverhangData(group)
        end if
        group.visible = false
        if group.isSubType("JFScreen")
            group.callFunc("OnScreenHidden")
        end if
    else
        ' Exit app if for some reason we don't have anything on the stack
        m.scene.exit = true
    end if
    group = m.groups.peek()
    if isValid(group)
        registerOverhangData(group)
        ' If we are moving back to anything other than a movie detail view, reset preferred audio track index
        if not group.isSubType("MovieDetails")
            m.global.queueManager.callFunc("setPreferredAudioTrackIndex", -1)
            m.global.queueManager.callFunc("setPreferredAudioTrackName", "")
        end if
        group.visible = true
        m.content.replaceChild(group, 0)
        if group.isSubType("JFScreen")
            group.callFunc("OnScreenShown")
        else
            ' Restore focus
            if group.lastFocus <> invalid
                group.lastFocus.setFocus(true)
            else
                if group.focusedChild <> invalid
                    group.focusedChild.setFocus(true)
                else
                    group.setFocus(true)
                end if
            end if
        end if
    else
        ' Exit app if the stack is empty after removing group
        m.scene.exit = true
    end if
    stopLoadingSpinner()
end sub

'
' Return group at top of stack without removing
function getActiveScene() as object
    return m.groups.peek()
end function

'
' Clear all content from group stack
sub clearScenes()
    if m.content <> invalid then
        m.content.removeChildrenIndex(m.content.getChildCount(), 0)
    end if
    for each group in m.groups
        if type(group) = "roSGNode" and group.isSubtype("JFScreen")
            group.callFunc("OnScreenHidden")
        end if
    end for
    m.groups = []
end sub

'
' Clear previous scene from group stack
sub clearPreviousScene()
    m.groups.pop()
end sub

'
' Delete scene from group stack at passed index
sub deleteSceneAtIndex(index = 1)
    m.groups.Delete(index)
end sub

'
' Return count of scenes
function getSceneCount() as integer
    return m.groups.Count()
end function

'
' Display user/device settings screen
sub settings()
    hideMiniPlayer()
    if m.global.audioPlayer.state = "playing"
        m.global.audioPlayer.control = "stop"
    end if
    settingsScreen = createObject("roSGNode", "Settings")
    pushScene(settingsScreen)
end sub

sub hideMiniPlayer()
    if not isValid(m.scene) then
        return
    end if
    audioMiniPlayer = m.scene.findNode("audioMiniPlayer")
    if not isValid(audioMiniPlayer) then
        return
    end if
    audioMiniPlayer.callFunc("setVisible", false)
end sub

'
' Register observers for overhang data
sub registerOverhangData(group)
    if group.isSubType("SetServerScreen")
        m.overhang.visible = false
        return
    end if
    if group.isSubType("MovieDetails")
        m.overhang.visible = false
        return
    end if
    if group.isSubType("Home")
        m.overhang.isVisible = true
        return
    end if
    if group.isSubType("JFGroup")
        if group.overhangTitle <> invalid then
            m.overhang.title = group.overhangTitle
        end if
        if group.optionsAvailable
            m.overhang.showOptions = true
        else
            m.overhang.showOptions = false
        end if
        group.observeField("optionsAvailable", "updateOptions")
        group.observeField("overhangTitle", "updateOverhangTitle")
        if group.overhangVisible
            m.overhang.visible = true
        else
            m.overhang.visible = false
        end if
        group.observeField("overhangVisible", "updateOverhangVisible")
    else
        print ("registerOverhangData(): Unexpected group type. " + bslib_toString(group.subtype()))
    end if
end sub

'
' Remove observers for overhang data
sub unregisterOverhangData(group)
    group.unobserveField("overhangTitle")
end sub

'
' Update overhang title
sub updateOverhangTitle(msg)
    m.overhang.title = msg.getData()
end sub

'
' Update options availability
sub updateOptions(msg)
    m.overhang.showOptions = msg.getData()
end sub

'
' Update whether the overhang is visible or not
sub updateOverhangVisible(msg)
    m.overhang.visible = msg.getData()
end sub

'
' Update username in overhang
sub updateUser()
    ' Passthrough to overhang
    if m.overhang <> invalid then
        m.overhang.currentUser = m.top.currentUser
    end if
end sub

'
' Display dialog to user with an OK button
sub userMessage(title as string, message as string)
    dialog = createObject("roSGNode", "StandardMessageDialog")
    dialog.title = title
    dialog.message = message
    dialog.buttons = [
        tr("OK")
    ]
    dialog.observeField("buttonSelected", "dismissDialog")
    m.scene.dialog = dialog
end sub

'
' Display dialog to user with an OK button
sub standardDialog(title, message)
    dialog = createObject("roSGNode", "StandardDialog")
    dlgPalette = createObject("roSGNode", "RSGPalette")
    dlgPalette.colors = {
        DialogBackgroundColor: chainLookupReturn(m.global.session, "user.settings.colorDialogBackground", "#101420")
        DialogFocusColor: chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
        DialogFocusItemColor: chainLookupReturn(m.global.session, "user.settings.colorDialogSelectedText", "#ffffff")
        DialogSecondaryTextColor: "#FF0000"
        DialogSecondaryItemColor: chainLookupReturn(m.global.session, "user.settings.colorDialogBorderLine", "#c8fafa")
        DialogTextColor: chainLookupReturn(m.global.session, "user.settings.colorDialogText", "#ffffff")
    }
    dialog.palette = dlgPalette
    dialog.observeField("buttonSelected", "dismissDialog")
    dialog.title = title
    dialog.contentData = message
    dialog.buttons = [
        tr("OK")
    ]
    m.scene.dialog = dialog
end sub

'
' Display What's New dialog to user with an OK button
sub whatsNewDialog()
    dialog = createObject("roSGNode", "WhatsNewDialog")
    dialog.observeField("buttonSelected", "dismissDialog")
    m.scene.dialog = dialog
end sub

'
' Display dialog to user with an OK button
sub LibrarySettingDialog(title)
    m.itemID = ""
    m.userselection = false
    dialog = createObject("roSGNode", "LibrarySettingDialog")
    dlgPalette = createObject("roSGNode", "RSGPalette")
    dlgPalette.colors = {
        DialogBackgroundColor: chainLookupReturn(m.global.session, "user.settings.colorDialogBackground", "#101420")
        DialogFocusColor: chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
        DialogFocusItemColor: chainLookupReturn(m.global.session, "user.settings.colorDialogSelectedText", "#ffffff")
        DialogSecondaryTextColor: "#FF0000"
        DialogSecondaryItemColor: chainLookupReturn(m.global.session, "user.settings.colorDialogBorderLine", "#c8fafa")
        DialogTextColor: chainLookupReturn(m.global.session, "user.settings.colorDialogText", "#ffffff")
    }
    dialog.palette = dlgPalette
    dialog.observeField("buttonSelected", "radioButtonSelected")
    dialog.observeField("wasClosed", "optionClosed")
    dialog.title = title
    dialog.buttons = [
        tr("OK")
    ]
    m.scene.dialog = dialog
end sub

'
' Display dialog to user with an OK button
sub radioDialog(title, message, buttons = [
    tr("OK")
])
    m.itemID = ""
    m.userselection = false
    dialog = createObject("roSGNode", "RadioDialog")
    dlgPalette = createObject("roSGNode", "RSGPalette")
    dlgPalette.colors = {
        DialogBackgroundColor: chainLookupReturn(m.global.session, "user.settings.colorDialogBackground", "#101420")
        DialogFocusColor: chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
        DialogFocusItemColor: chainLookupReturn(m.global.session, "user.settings.colorDialogSelectedText", "#ffffff")
        DialogSecondaryTextColor: "#FF0000"
        DialogSecondaryItemColor: chainLookupReturn(m.global.session, "user.settings.colorDialogBorderLine", "#c8fafa")
        DialogTextColor: chainLookupReturn(m.global.session, "user.settings.colorDialogText", "#ffffff")
    }
    dialog.palette = dlgPalette
    dialog.observeField("buttonSelected", "radioButtonSelected")
    dialog.observeField("wasClosed", "optionClosed")
    dialog.title = title
    dialog.contentData = message
    dialog.buttons = buttons
    m.scene.dialog = dialog
end sub

sub radioButtonSelected()
    m.userselection = true
    dismissDialog()
end sub

'
' Display remote subtitle dialog to user with OK and cancel buttons
sub remoteSubtitleDialog(title, message)
    dialog = createObject("roSGNode", "RemoteSubtitleDialog")
    dlgPalette = createObject("roSGNode", "RSGPalette")
    dlgPalette.colors = {
        DialogBackgroundColor: chainLookupReturn(m.global.session, "user.settings.colorDialogBackground", "#101420")
        DialogFocusColor: chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
        DialogFocusItemColor: chainLookupReturn(m.global.session, "user.settings.colorDialogSelectedText", "#ffffff")
        DialogSecondaryTextColor: "#FF0000"
        DialogSecondaryItemColor: chainLookupReturn(m.global.session, "user.settings.colorDialogBorderLine", "#c8fafa")
        DialogTextColor: chainLookupReturn(m.global.session, "user.settings.colorDialogText", "#ffffff")
    }
    dialog.palette = dlgPalette
    dialog.observeField("buttonSelected", "dismissDialog")
    dialog.title = title
    dialog.contentData = message
    dialog.buttons = [
        tr("OK")
        tr("Cancel")
    ]
    m.scene.dialog = dialog
end sub

sub keyboardDialog(id, title, message, buttons, hintText, itemID)
    m.buttonData = buttons
    m.itemID = itemID
    m.top.dataReturned = false
    m.top.returnData = invalid
    m.userselection = false
    dialog = createObject("roSGNode", "StandardKeyboardDialog")
    dialog.id = id
    dlgPalette = createObject("roSGNode", "RSGPalette")
    dlgPalette.colors = {
        DialogBackgroundColor: chainLookupReturn(m.global.session, "user.settings.colorDialogBackground", "#101420")
        DialogFocusColor: chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
        DialogFocusItemColor: chainLookupReturn(m.global.session, "user.settings.colorDialogSelectedText", "#ffffff")
        DialogSecondaryTextColor: "#FF0000"
        DialogSecondaryItemColor: chainLookupReturn(m.global.session, "user.settings.colorDialogBorderLine", "#c8fafa")
        DialogTextColor: chainLookupReturn(m.global.session, "user.settings.colorDialogText", "#ffffff")
    }
    dialog.palette = dlgPalette
    dialog.observeField("buttonSelected", "optionSelected")
    dialog.observeField("wasClosed", "optionClosed")
    dialog.title = title
    dialog.message = message
    dialog.text = hintText
    if isStringEqual(type(buttons[0]), "rostring")
        dialog.buttons = buttons
    else
        objectTitles = []
        for each playlist in buttons
            objectTitles.push(playlist.title)
        end for
        dialog.buttons = objectTitles
    end if
    m.scene.dialog = dialog
end sub

'
' Display dialog to user with an OK button
sub optionDialog(id, title, message, buttons, params)
    m.buttonData = buttons
    m.itemID = params.LookupCI("id")
    m.params = params
    m.top.dataReturned = false
    m.top.returnData = invalid
    m.userselection = false
    dialog = createObject("roSGNode", "StandardMessageDialog")
    dialog.id = id
    dlgPalette = createObject("roSGNode", "RSGPalette")
    dlgPalette.colors = {
        DialogBackgroundColor: chainLookupReturn(m.global.session, "user.settings.colorDialogBackground", "#101420")
        DialogFocusColor: chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
        DialogFocusItemColor: chainLookupReturn(m.global.session, "user.settings.colorDialogSelectedText", "#ffffff")
        DialogSecondaryItemColor: chainLookupReturn(m.global.session, "user.settings.colorDialogBorderLine", "#c8fafa")
        DialogTextColor: chainLookupReturn(m.global.session, "user.settings.colorDialogText", "#ffffff")
    }
    dialog.palette = dlgPalette
    dialog.observeField("buttonSelected", "optionSelected")
    dialog.observeField("wasClosed", "optionClosed")
    dialog.title = title
    ' Apply fallback font to dialog title
    if m.global.fallbackFont <> ""
        if chainLookupReturn(m.global.session, "user.settings.useFallbackFont", false)
            dialogTitle = findNodeBySubtype(dialog, "StdDlgTitleArea")
            if dialogTitle.count() <> 0 and isValid(dialogTitle[0]) and isValid(dialogTitle[0].node)
                dialogTitleLabel = dialogTitle[0].node.getChild(0)
                if isValid(dialogTitleLabel)
                    if dialogTitleLabel.isSubType("ScrollingText")
                        dialogTitleLabel.font.uri = m.global.fallbackFont
                    end if
                end if
            end if
        end if
    end if
    dialog.message = message
    if isStringEqual(type(buttons[0]), "rostring")
        dialog.buttons = buttons
    else
        objectTitles = []
        for each playlist in buttons
            objectTitles.push(playlist.title)
        end for
        dialog.buttons = objectTitles
    end if
    m.scene.dialog = dialog
end sub

'
' Return button the user selected
sub optionClosed()
    if m.userselection then
        return
    end if
    m.top.returnData = {
        id: m.scene.dialog.id
        itemID: m.itemID
        params: m.params
        indexSelected: -1
        buttonSelected: ""
        text: m.scene.dialog.text
    }
    m.top.dataReturned = true
end sub

'
' Return button the user selected
sub optionSelected()
    m.userselection = true
    m.top.returnData = {
        id: m.scene.dialog.id
        itemID: m.itemID
        params: m.params
        indexSelected: m.scene.dialog.buttonSelected
        buttonSelected: m.buttonData[m.scene.dialog.buttonSelected]
        text: m.scene.dialog.text
    }
    m.top.dataReturned = true
    dismissDialog()
end sub

'
' Close currently displayed dialog
sub dismissDialog(msg = invalid)
    if not isDialogOpen() then
        return
    end if
    if isValid(msg)
        ' User chose cancel button
        if msg.getData() = 1
            m.returnData = {}
            m.top.dataReturned = false
        end if
    end if
    m.scene.dialog.close = true
end sub

'
' Returns bool indicating if dialog is currently displayed
function isDialogOpen() as boolean
    return isValid(m.scene.dialog)
end function
'//# sourceMappingURL=./SceneManager.brs.map