'import "pkg:/source/enums/ItemType.bs"

sub setFields()
    datum = m.top.json
    m.top.id = datum.id
    m.top.title = datum.name
    m.top.overview = datum.overview
    m.top.type = "season"
    setPoster()
end sub

sub setPoster()
    if m.top.image <> invalid
        m.top.posterURL = m.top.image.url
    else
        m.top.posterURL = ""
    end if
end sub
'//# sourceMappingURL=./TVSeasonData.brs.map