'import "pkg:/source/api/userauth.bs"
'import "pkg:/source/api/baserequest.bs"
'import "pkg:/source/utils/config.bs"
'import "pkg:/source/utils/session.bs"

sub init()
    m.quickConnectTimer = m.top.findNode("quickConnectTimer")
    m.quickConnectTimer.observeField("fire", "quickConnectStatus")
    m.quickConnectTimer.control = "start"
    m.top.observeFieldScoped("buttonSelected", "onButtonSelected")
end sub

sub quickConnectStatus()
    m.quickConnectTimer.control = "stop"
    m.checkTask = CreateObject("roSGNode", "QuickConnect")
    m.checkTask.secret = m.top.quickConnectJson.secret
    m.checkTask.saveCredentials = m.top.saveCredentials
    m.checkTask.observeField("authenticated", "OnAuthenticated")
    m.checkTask.control = "run"
end sub

sub OnAuthenticated()
    m.checkTask.control = "stop"
    m.checkTask.unobserveField("authenticated")
    ' Did we get the A-OK to authenticate?
    authenticated = m.checkTask.authenticated
    if authenticated < 0
        ' Still waiting, check again in 3 seconds...
        authenticated = 0
        m.quickConnectTimer.control = "start"
    else if authenticated > 0
        ' We've been logged in via Quick Connect...
        m.top.close = true
        m.top.authenticated = true
    end if
end sub

sub quickConnectClosed()
    m.quickConnectTimer.control = "stop"
    if m.checkTask <> invalid
        m.checkTask.control = "stop"
        m.checkTask.unobserveField("authenticated")
    end if
    m.top.close = true
end sub

sub onButtonSelected()
    ' only one button at the moment...
    quickConnectClosed()
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        return false
    end if
    ' Note that "OK" does not get sent here, hence onButtonSelected() above.
    if key = "back"
        quickConnectClosed()
        return true
    end if
    return false
end function
'//# sourceMappingURL=./QuickConnectDialog.brs.map