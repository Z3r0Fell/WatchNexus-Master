'import "pkg:/source/api/userauth.bs"
'import "pkg:/source/api/baserequest.bs"
'import "pkg:/source/utils/config.bs"

sub init()
    m.top.functionName = "monitorQuickConnect"
end sub

sub monitorQuickConnect()
    authenticated = checkQuickConnect(m.top.secret)
    if authenticated = true
        loggedIn = AuthenticateViaQuickConnect(m.top.secret)
        if loggedIn
            currentUser = AboutMe()
            session_user_Login(currentUser, m.top.saveCredentials)
            session_user_LoadUserPreferences()
            LoadUserAbilities()
            m.top.authenticated = 1
            return
        end if
    end if
    m.top.authenticated = -1
end sub
'//# sourceMappingURL=./QuickConnect.brs.map