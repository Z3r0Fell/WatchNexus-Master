'import "pkg:/source/api/baserequest.bs"
'import "pkg:/source/api/Image.bs"
'import "pkg:/source/api/Items.bs"
'import "pkg:/source/enums/ItemType.bs"
'import "pkg:/source/enums/TaskControl.bs"
'import "pkg:/source/enums/ViewLoadStatus.bs"
'import "pkg:/source/utils/config.bs"
'import "pkg:/source/utils/deviceCapabilities.bs"

sub init()
    m.top.imageDisplayMode = "scaleToZoom"
    m.loadItemsTask1 = createObject("roSGNode", "LoadItemsTask")
    m.top.optionsAvailable = false
    m.searchRow = m.top.findnode("searchRow")
    m.searchTask = CreateObject("roSGNode", "SearchTask")
    'set label text
    m.searchHelpText = m.top.findNode("SearchHelpText")
    m.searchHelpText.text = tr("You can search for Titles, People, Live TV Channels and more")
    m.loadStatus = 0
end sub

sub searchMedias()
    query = m.top.searchAlpha
    'if user deletes the search string hide the spinner
    if query.len() = 0
        stopLoadingSpinner()
    end if
    'if search task is running and user selectes another letter stop the search and load the next letter
    m.searchTask.control = "stop"
    if query <> invalid and query <> ""
        startLoadingSpinner(false)
    end if
    m.searchTask.observeField("results", "loadResults")
    m.searchTask.query = query
    m.top.overhangTitle = tr("Search") + ": " + query
    m.searchTask.control = "RUN"
end sub

sub loadResults()
    m.searchTask.unobserveField("results")
    stopLoadingSpinner()
    m.searchRow.itemData = m.searchTask.results
    m.searchRow.query = m.top.SearchAlpha
    m.searchHelpText.visible = false
    if m.searchTask.results.TotalRecordCount = 0
        ' make sure focus is on the keyboard
        if m.searchRow.isinFocusChain()
            m.searchAlphabox.setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.searchAlphabox
        end if
        return
    end if
    m.searchAlphabox = m.top.findnode("searchResults")
    m.searchAlphabox.translation = "[470, 85]"
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    m.searchAlphabox = m.top.findNode("search_Key")
    if m.searchAlphabox.textEditBox.hasFocus()
        m.searchAlphabox.textEditBox.translation = "[0, -150]"
    else
        m.searchAlphabox.textEditBox.translation = "[0, 0]"
    end if
    if key = "left" and m.searchRow.isinFocusChain()
        m.searchAlphabox.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.searchAlphabox
        return true
    else if key = "right" and m.searchRow.content <> invalid and m.searchRow.content.getChildCount() > 0
        m.searchRow.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.searchRow
        return true
    else if key = "play" and m.searchRow.isinFocusChain() and m.searchRow.rowItemFocused.count() > 0
        if m.searchRow.rowItemFocused <> invalid
            selectedContent = m.searchRow.content.getChild(m.searchRow.rowItemFocused[0])
            if selectedContent <> invalid
                selectedItem = selectedContent.getChild(m.searchRow.rowItemFocused[1])
                if selectedItem <> invalid
                    m.top.quickPlayNode = selectedItem
                    return true
                end if
            end if
        end if
    end if
    return false
end function

function getItemFocused() as object
    if not m.searchRow.isinFocusChain() then
        return invalid
    end if
    if not isValidAndNotEmpty(m.searchRow.rowItemFocused) then
        return invalid
    end if
    selectedContent = m.searchRow.content.getChild(m.searchRow.rowItemFocused[0])
    if not isValid(selectedContent) then
        return invalid
    end if
    return selectedContent.getChild(m.searchRow.rowItemFocused[1])
end function

sub OnScreenShown()
    group = m.global.sceneManager.callFunc("getActiveScene")
    if isValid(m.top.lastFocus)
        m.top.lastFocus.setFocus(true)
        group.lastFocus = m.top.lastFocus
    else
        m.top.setFocus(true)
        group.lastFocus = m.top
    end if
    if isStringEqual(m.loadStatus, 0)
        m.loadStatus = 1
        return
    end if
    focusedItem = getItemFocused()
    if not isValid(focusedItem) then
        return
    end if
    ' Only refresh meta data for specific item types
    if not inArray([
        "episode"
        "movie"
        "season"
        "series"
        "video"
        "musicvideo"
        "recording"
        "boxset"
    ], focusedItem.LookupCI("type")) then
        return
    end if
    m.loadItemsTask1.itemId = focusedItem.LookupCI("id")
    m.loadItemsTask1.observeField("content", "onItemDataLoaded")
    m.loadItemsTask1.itemsToLoad = "metaData"
    m.loadItemsTask1.control = "RUN"
end sub

sub onItemDataLoaded()
    itemData = m.loadItemsTask1.content
    m.loadItemsTask1.unobserveField("content")
    m.loadItemsTask1.content = []
    if not isValidAndNotEmpty(itemData) then
        return
    end if
    focusedItem = getItemFocused()
    if not isValid(focusedItem) then
        return
    end if
    focusedItem.callFunc("setWatched", chainLookupReturn(itemData[0], "json.UserData.Played", false), chainLookupReturn(itemData[0], "json.UserData.UnplayedItemCount", 0))
end sub
'//# sourceMappingURL=./SearchResults.brs.map