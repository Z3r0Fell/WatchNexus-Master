'import "pkg:/source/api/baserequest.bs"
'import "pkg:/source/api/Image.bs"
'import "pkg:/source/api/Items.bs"
'import "pkg:/source/enums/ItemType.bs"
'import "pkg:/source/utils/config.bs"
'import "pkg:/source/utils/deviceCapabilities.bs"

sub init()
    m.top.showItemTitles = "showalways"
    m.top.content = getData()
end sub

function getData()
    data = CreateObject("roSGNode", "ContentNode")
    m.rowItemSizes = []
    m.rowHeights = []
    itemData = m.top.itemData
    if not isValid(itemData)
        return data
    end if
    ' Do this to keep the ordering, AssociateArrays have no order
    type_array = [
        "movie"
        "series"
        "tvchannel"
        "episode"
        "musicartist"
        "musicalbum"
        "audio"
        "person"
        "playlist"
        "program"
    ]
    content_types = {
        "movie": {
            "label": "Movies"
            "count": 0
            size: [
                230
                405
            ]
            imageDimensions: [
                230
                340
            ]
        }
        "episode": {
            "label": "Episodes"
            "count": 0
            size: [
                400
                330
            ]
            imageDimensions: [
                400
                260
            ]
        }
        "musicartist": {
            "label": "Artists"
            "count": 0
            size: [
                400
                305
            ]
            imageDimensions: [
                400
                260
            ]
        }
        "program": {
            "label": "Programs"
            "count": 0
            size: [
                400
                330
            ]
            imageDimensions: [
                400
                260
            ]
        }
        "tvChannel": {
            "label": "Channels"
            "count": 0
            size: [
                400
                305
            ]
            imageDimensions: [
                400
                260
            ]
        }
        "musicalbum": {
            "label": "Albums"
            "count": 0
            size: [
                330
                330
            ]
            imageDimensions: [
                330
                260
            ]
        }
        "audio": {
            "label": "Songs"
            "count": 0
            size: [
                330
                330
            ]
            imageDimensions: [
                330
                260
            ]
        }
        "series": {
            "label": "Shows"
            "count": 0
            size: [
                400
                330
            ]
            imageDimensions: [
                400
                260
            ]
        }
        "person": {
            "label": "People"
            "count": 0
            size: [
                230
                385
            ]
            imageDimensions: [
                230
                340
            ]
        }
        "playlist": {
            "label": "Playlists"
            "count": 0
            size: [
                330
                330
            ]
            imageDimensions: [
                330
                260
            ]
        }
    }
    ' Loop through all items to get count of each item type
    for each item in chainLookup(itemData, "items")
        if isValid(content_types.LookupCI(item.type))
            content_types.LookupCI(item.type).count += 1
        end if
    end for
    ' Loop through each item type in order and create rows if it has items
    for each ctype in type_array
        content_type = content_types.LookupCI(ctype)
        if content_type.count > 0
            addRow(data, content_type, ctype)
            m.rowItemSizes.push(content_type.size)
            m.rowHeights.push(content_type.size[1] + 30)
        end if
    end for
    m.top.rowHeights = m.rowHeights
    m.top.rowItemSize = m.rowItemSizes
    m.top.content = data
    return data
end function

sub addRow(pageData, content, type_filter)
    itemData = m.top.itemData
    row = pageData.CreateChild("ContentNode")
    row.title = content.label
    ' Loop through all items, but only get items that match the passed type
    for each item in chainLookup(itemData, "items")
        if isStringEqual(item.type, type_filter)
            item.imageDimensions = content.imageDimensions
            row.appendChild(item)
        end if
    end for
end sub
'//# sourceMappingURL=./SearchRow.brs.map