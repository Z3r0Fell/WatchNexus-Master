'import "pkg:/source/api/baserequest.bs"
'import "pkg:/source/api/Image.bs"
'import "pkg:/source/enums/AnimationControl.bs"
'import "pkg:/source/enums/AnimationState.bs"
'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/ImageLayout.bs"
'import "pkg:/source/enums/ItemType.bs"
'import "pkg:/source/enums/KeyCode.bs"
'import "pkg:/source/enums/SearchButtonState.bs"
'import "pkg:/source/enums/String.bs"
'import "pkg:/source/enums/TaskControl.bs"
'import "pkg:/source/utils/config.bs"
'import "pkg:/source/utils/deviceCapabilities.bs"
'import "pkg:/source/utils/misc.bs"

sub setupNodes()
    m.toggleDropdownOptionsAnimation = m.top.findNode("toggleDropdownOptionsAnimation")
    m.dropdownOptionsMove = m.top.findNode("dropdownOptionsMove")
    m.itemGridMove = m.top.findNode("itemGridMove")
    m.genreListMove = m.top.findNode("genreListMove")
    m.dropdownOptionsFade = m.top.findNode("dropdownOptionsFade")
    m.options = m.top.findNode("options")
    m.itemGrid = m.top.findNode("itemGrid")
    m.voiceBox = m.top.findNode("voiceBox")
    m.voiceBoxBackground = m.top.findNode("voiceBoxBackground")
    m.backdrop = m.top.findNode("backdrop")
    m.newBackdrop = m.top.findNode("backdropTransition")
    m.emptyText = m.top.findNode("emptyText")
    m.selectedArtistName = m.top.findNode("selectedArtistName")
    m.selectedArtistSongCount = m.top.findNode("selectedArtistSongCount")
    m.selectedArtistAlbumCount = m.top.findNode("selectedArtistAlbumCount")
    m.selectedArtistGenres = m.top.findNode("selectedArtistGenres")
    m.artistLogo = m.top.findNode("artistLogo")
    m.swapAnimation = m.top.findNode("backroundSwapAnimation")
    m.alpha = m.top.findNode("alpha")
    m.alphaMenu = m.alpha.findNode("alphaMenu")
    m.overhang = m.top.getScene().findNode("overhang")
    m.genreList = m.top.findNode("genrelist")
    m.dropdownOptions = m.top.findNode("dropdownOptions")
    m.sortButton = m.top.findNode("sortButton")
    m.sortButton.textColor = "#101010"
    m.sortButton.focusTextColor = "#ffffff"
    m.sortButton.background = "#ffffff"
    m.sortButton.focusBackground = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    m.sortOrderButton = m.top.findNode("sortOrderButton")
    m.sortOrderButton.textColor = "#101010"
    m.sortOrderButton.focusTextColor = "#ffffff"
    m.sortOrderButton.background = "#ffffff"
    m.sortOrderButton.focusBackground = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    m.filterButton = m.top.findNode("filterButton")
    m.filterButton.textColor = "#101010"
    m.filterButton.focusTextColor = "#ffffff"
    m.filterButton.background = "#ffffff"
    m.filterButton.focusBackground = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    m.viewButton = m.top.findNode("viewButton")
    m.viewButton.textColor = "#101010"
    m.viewButton.focusTextColor = "#ffffff"
    m.viewButton.background = "#ffffff"
    m.viewButton.focusBackground = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    setSearchBackground(1)
end sub

sub init()
    m.top.imageDisplayMode = "scaleToZoom"
    m.top.showItemTitles = "showonhover"
    setupNodes()
    m.bypassSearchEvent = false
    m.itemGrid.focusBitmapBlendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    m.genrelist.focusBitmapBlendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    m.overhang.isVisible = false
    m.options.observeField("visible", "onOptionsVisibleChange")
    m.swapAnimation.observeField("state", "swapDone")
    m.loadedRows = 0
    m.loadedItems = 0
    m.data = CreateObject("roSGNode", "ContentNode")
    m.itemGrid.content = m.data
    m.genreData = CreateObject("roSGNode", "ContentNode")
    m.genreList.observeField("itemSelected", "onGenreItemSelected")
    m.genreList.observeField("itemFocused", "onGenreItemFocused")
    m.genreList.content = m.genreData
    m.itemGrid.observeField("itemFocused", "onItemFocused")
    m.itemGrid.observeField("itemSelected", "onItemSelected")
    'Voice filter setup
    m.voiceBox.observeField("text", "onvoiceFilter")
    'backdrop
    m.newBackdrop.observeField("loadStatus", "newBGLoaded")
    'Background Image Queued for loading
    m.queuedBGUri = ""
    'Item sort - maybe load defaults from user prefs?
    m.sortField = "SortName"
    m.sortAscending = true
    m.filter = "All"
    m.loadItemsTask = createObject("roSGNode", "LoadItemsTask2")
    m.loadLogoTask = createObject("roSGNode", "LoadItemsTask2")
    m.getFiltersTask = createObject("roSGNode", "GetFiltersTask")
    'set inital counts for overhang before content is loaded.
    m.loadItemsTask.totalRecordCount = 0
    if not m.global.device.hasVoiceRemote
        m.voiceBox.backgroundUri = "pkg:/images/transparent.png"
        m.voiceBox.translation = "[15, 0]"
        m.voiceBox.width = m.voiceBox.width - 15
    else
        searchPoster = m.voiceBox.getChild(0)
        if isChainValid(searchPoster, "bitmap")
            searchPoster.bitmap = ""
            searchPoster.blendColor = "#ffffff"
        end if
        searchText = m.voiceBox.getChild(1)
        if isChainValid(searchText, "height")
            searchText.vertAlign = "bottom"
            searchText.height = 37
        end if
        m.micIcon = m.voiceBox.getChild(6)
        if isValid(m.micIcon)
            m.micIcon.observeFieldScoped("blendColor", "onMicIconBlendColorChange")
        end if
    end if
end sub

' VoiceTextEditBox.voiceEnabled doesn't have alwaysNotify enabled
' To trigger a change event, we must change the value to something else, then back to the value we want
sub onVoiceEnabledChange()
    m.voiceBox.voiceEnabled = false
    m.voiceBox.voiceEnabled = true
end sub

sub onMicIconBlendColorChange()
    ' DARKGREY: 269488383
    ' WHITE: -1
    ' LIGHTGREY: -1431655681
    ' HIGHLIGHT: -9934849
    if m.voiceBoxBackground.blendColor = -9934849
        if m.micIcon.blendColor <> -1
            m.micIcon.blendColor = "#ffffff"
        end if
    else
        if m.micIcon.blendColor <> 269488383
            m.micIcon.blendColor = "#101010"
        end if
    end if
end sub

sub onSortChange()
    m.global.sceneManager.unobserveFieldScoped("returnData")
    sortChoice = m.global.sceneManager.returnData
    if not isChainValid(sortChoice, "name") then
        return
    end if
    if isStringEqual(sortChoice.LookupCI("name"), m.sortField) then
        return
    end if
    m.sortButton.focus = false
    m.itemGrid.setFocus(m.itemGrid.opacity = 1)
    m.genreList.setFocus(m.genreList.opacity = 1)
    m.sortField = sortChoice.LookupCI("name")
    m.sortButton.text = tr(sortChoice.LookupCI("title"))
    m.sortAscending = true
    set_user_setting("display." + m.settingID + ".sortField", m.sortField)
    m.loadedRows = 0
    m.loadedItems = 0
    m.data = CreateObject("roSGNode", "ContentNode")
    m.itemGrid.content = m.data
    loadInitialItems()
end sub

sub onViewChange()
    m.global.sceneManager.unobserveFieldScoped("returnData")
    viewChoice = m.global.sceneManager.returnData
    if not isChainValid(viewChoice, "name") then
        return
    end if
    if isStringEqual(viewChoice.LookupCI("name"), m.view) then
        return
    end if
    m.viewButton.focus = false
    m.itemGrid.setFocus(m.itemGrid.opacity = 1)
    m.genreList.setFocus(m.genreList.opacity = 1)
    m.view = viewChoice.LookupCI("name")
    m.viewButton.text = tr(viewChoice.LookupCI("title"))
    set_user_setting("display." + m.settingID + ".landing", m.view)
    ' Reset any filtering or search terms
    m.bypassSearchEvent = true
    m.top.searchTerm = ""
    m.top.alphaSelected = ""
    m.loadItemsTask.NameStartsWith = " "
    m.loadItemsTask.searchTerm = ""
    m.filter = "All"
    m.filterOptions = {}
    m.sortField = "SortName"
    m.sortAscending = true
    ' Reset view to defaults
    set_user_setting("display." + m.settingID + ".sortField", m.sortField)
    set_user_setting("display." + m.settingID + ".sortAscending", "true")
    set_user_setting("display." + m.settingID + ".filter", m.filter)
    set_user_setting("display." + m.settingID + ".filterOptions", FormatJson(m.filterOptions))
    m.getFiltersTask.control = "RUN"
    m.loadedRows = 0
    m.loadedItems = 0
    m.data = CreateObject("roSGNode", "ContentNode")
    m.itemGrid.content = m.data
    loadInitialItems()
end sub

sub onSortOrderChange()
    m.global.sceneManager.unobserveFieldScoped("returnData")
    sortOrderChoice = m.global.sceneManager.returnData
    if not isChainValid(sortOrderChoice, "name") then
        return
    end if
    if m.sortAscending = isStringEqual(sortOrderChoice.LookupCI("name"), "Ascending") then
        return
    end if
    m.sortOrderButton.focus = false
    m.itemGrid.setFocus(m.itemGrid.opacity = 1)
    m.genreList.setFocus(m.genreList.opacity = 1)
    m.sortAscending = isStringEqual(sortOrderChoice.LookupCI("name"), "Ascending")
    m.sortOrderButton.text = tr(sortOrderChoice.LookupCI("title"))
    set_user_setting("display." + m.settingID + ".sortAscending", m.sortAscending.toStr())
    m.loadedRows = 0
    m.loadedItems = 0
    m.data = CreateObject("roSGNode", "ContentNode")
    m.itemGrid.content = m.data
    loadInitialItems()
end sub

sub OnScreenHidden()
    if not m.overhang.isVisible
        m.overhang.disableMoveAnimation = true
        m.overhang.isVisible = true
        m.overhang.disableMoveAnimation = false
    end if
end sub

sub OnScreenShown()
    m.overhang.isVisible = false
    if isValid(m.top.lastFocus)
        m.top.lastFocus.setFocus(true)
    else
        m.top.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.top
    end if
end sub

'
'Load initial set of Data
sub loadInitialItems()
    m.loadItemsTask.control = "STOP"
    startLoadingSpinner(false)
    if LCase(m.top.parentItem.json.Type) = "collectionfolder"
        m.top.HomeLibraryItem = m.top.parentItem.Id
    end if
    if m.top.parentItem.backdropUrl <> invalid
        SetBackground(m.top.parentItem.backdropUrl)
    else
        SetBackground("")
    end if
    if m.dropdownOptions.opacity < 1
        toggleDropdownOptions(true)
    end if
    if isValid(m.top.parentItem.json.jumpToFilter)
        m.settingID = "jumpToFilter"
    else
        m.settingID = m.top.parentItem.Id
    end if
    m.sortField = m.global.session.user.settings["display." + m.settingID + ".sortField"]
    m.sortAscending = m.global.session.user.settings["display." + m.settingID + ".sortAscending"]
    m.filter = m.global.session.user.settings["display." + m.settingID + ".filter"]
    m.filterOptions = m.global.session.user.settings["display." + m.settingID + ".filterOptions"]
    m.view = m.global.session.user.settings["display." + m.settingID + ".landing"]
    if not isValidAndNotEmpty(m.sortField) then
        m.sortField = "SortName"
    end if
    if not isValidAndNotEmpty(m.filter) then
        m.filter = "All"
    end if
    if not isValidAndNotEmpty(m.filterOptions) then
        m.filterOptions = "{}"
    end if
    if not isValidAndNotEmpty(m.view) then
        m.view = "ArtistsPresentation"
    end if
    if not isValid(m.sortAscending) then
        m.sortAscending = true
    end if
    if not isStringEqual(type(m.sortAscending), "roBoolean") then
        m.sortAscending = true
    end if
    ' We're inside a genre
    if isStringEqual(m.top.parentItem.json.type, "musicgenre")
        if not isStringEqual(m.view, "albums") then
            m.view = "albums"
        end if
    end if
    m.filterOptions = ParseJson(m.filterOptions)
    m.top.showItemTitles = m.global.session.user.settings["itemgrid.gridTitles"]
    m.loadItemsTask.searchTerm = m.top.searchTerm
    m.emptyText.visible = false
    m.loadItemsTask.sortField = m.sortField
    m.loadItemsTask.sortAscending = m.sortAscending
    m.loadItemsTask.filter = m.filter
    m.loadItemsTask.filterOptions = m.filterOptions
    m.loadItemsTask.startIndex = 0
    ' Load Item Types
    if getCollectionType() = "music"
        m.loadItemsTask.itemType = "MusicArtist"
        m.loadItemsTask.itemId = m.top.parentItem.Id
    end if
    ' By default we load artist grid view
    m.loadItemsTask.view = "Artists"
    m.loadItemsTask.genreIds = ""
    m.itemGrid.translation = "[100, 210]"
    m.itemGrid.numRows = "4"
    m.dropdownOptions.translation = "[100, 60]"
    if m.dropdownOptions.opacity < 1
        m.itemGrid.translation = "[100, 60]"
    else
        m.itemGrid.translation = "[100, 210]"
    end if
    m.dropdownOptionsMove.keyValue = "[[100, 60], [100, 0]]"
    m.itemGridMove.keyValue = "[[100, 210], [100, 60]]"
    m.emptyText.translation = "[0, 540]"
    ' We're inside a genre
    if isStringEqual(m.top.parentItem.json.type, "musicgenre")
        m.loadItemsTask.itemType = "MusicAlbum"
        m.loadItemsTask.recursive = true
        m.loadItemsTask.genreIds = m.top.parentItem.id
        m.loadItemsTask.itemId = m.top.parentItem.parentFolder
    end if
    if isStringEqual(m.view, "albums")
        m.loadItemsTask.itemType = "MusicAlbum"
        m.top.imageDisplayMode = "scaleToFit"
    else if isStringEqual(m.view, "albumartistsgrid")
        m.loadItemsTask.itemType = "AlbumArtists"
    else if isStringEqual(m.view, "albumartistspresentation")
        m.emptyText.translation = "[0, 750]"
        m.loadItemsTask.itemType = "AlbumArtists"
        m.itemGrid.translation = "[100, 670]"
        m.itemGrid.numRows = "2"
        m.dropdownOptions.translation = "[100, 540]"
        if m.dropdownOptions.opacity < 1
            m.itemGrid.translation = "[100, 520]"
        else
            m.itemGrid.translation = "[100, 670]"
        end if
        m.dropdownOptionsMove.keyValue = "[[100, 540], [100, 480]]"
        m.itemGridMove.keyValue = "[[100, 670], [100, 520]]"
    else if isStringEqual(m.view, "ArtistsPresentation")
        m.emptyText.translation = "[0, 750]"
        m.itemGrid.translation = "[100, 670]"
        m.itemGrid.numRows = "2"
        m.dropdownOptions.translation = "[100, 540]"
        if m.dropdownOptions.opacity < 1
            m.itemGrid.translation = "[100, 520]"
        else
            m.itemGrid.translation = "[100, 670]"
        end if
        m.dropdownOptionsMove.keyValue = "[[100, 540], [100, 480]]"
        m.itemGridMove.keyValue = "[[100, 670], [100, 520]]"
    else if isStringEqual(m.view, "genres")
        m.loadItemsTask.itemType = ""
        m.loadItemsTask.recursive = true
        m.loadItemsTask.view = "Genres"
        m.artistLogo.visible = false
        m.selectedArtistName.visible = false
    end if
    setColumnSizes()
    m.loadItemsTask.observeField("content", "ItemDataLoaded")
    m.loadItemsTask.control = "RUN"
    m.getFiltersTask.observeField("filters", "FilterDataLoaded")
    m.getFiltersTask.params = {
        userid: m.global.session.user.id
        parentid: m.top.parentItem.Id
    }
    m.getFiltersTask.control = "RUN"
end sub

sub setColumnSizes()
    numberOfColumns = chainLookupReturn(m.global.session, "user.settings.numberOfColumnsSquare", "6")
    imageWidthData = val(chainLookupReturn(m.global.session, "user.settings.numberOfColumnsSquareData", "270"))
    defaultSize = [
        imageWidthData
        imageWidthData
    ]
    m.itemGrid.itemSize = defaultSize
    m.itemGrid.rowHeights = [
        defaultSize[1]
    ]
    m.itemGrid.numRows = abs(1230 / (defaultSize[1] + m.itemGrid.itemSpacing[1]))
    m.itemGrid.numColumns = numberOfColumns
    m.genreList.itemSize = defaultSize
    m.genreList.rowHeights = [
        defaultSize[1]
    ]
    m.genreList.numRows = abs(1230 / (defaultSize[1] + m.itemGrid.itemSpacing[1]))
    m.genreList.numColumns = numberOfColumns
    m.loadItemsTask.numberOfColumns = numberOfColumns
end sub

'
'Check if options updated and any reloading required
sub onOptionsVisibleChange()
    if m.options.visible then
        return
    end if
    reload = false
    ' Nothing changed
    if isStringEqual(m.options.filter, m.filter)
        if AssocArrayEqual(m.options.filterOptions, m.filterOptions)
            m.filterButton.focus = true
            m.filterButton.setfocus(true)
            return
        end if
    end if
    if m.options.filter <> m.filter
        m.filter = m.options.filter
        reload = true
        set_user_setting("display." + m.settingID + ".filter", m.options.filter)
    end if
    if not isValid(m.options.filterOptions)
        m.filterOptions = {}
    end if
    if not AssocArrayEqual(m.options.filterOptions, m.filterOptions)
        m.filterOptions = m.options.filterOptions
        reload = true
        set_user_setting("display." + m.settingID + ".filterOptions", FormatJson(m.options.filterOptions))
    end if
    if reload
        m.loadedRows = 0
        m.loadedItems = 0
        m.data = CreateObject("roSGNode", "ContentNode")
        m.itemGrid.content = m.data
        loadInitialItems()
    end if
    m.filterButton.focus = false
    m.itemGrid.setFocus(m.itemGrid.opacity = 1)
    m.genreList.setFocus(m.genreList.opacity = 1)
    group = m.global.sceneManager.callFunc("getActiveScene")
    if m.itemGrid.opacity = 1 then
        group.lastFocus = m.itemGrid
    else
        group.lastFocus = m.genreList
    end if
end sub

'
' Filter Data Loaded Event Handler
sub FilterDataLoaded(msg)
    options = setMusicOptions()
    data = msg.GetData()
    m.getFiltersTask.unobserveField("filters")
    if not isValid(data) then
        return
    end if
    ' Add Music filters from the API data
    if inArray([
        "musicartist"
        "albumartists"
    ], LCase(m.loadItemsTask.itemType))
        if isValid(data.genres)
            options.filter.push({
                "Title": tr("Genres")
                "Name": "Genres"
                "Options": data.genres
                "Delimiter": "|"
                "CheckedState": []
            })
        end if
    end if
    if LCase(m.loadItemsTask.itemType) = "musicalbum"
        if isValid(data.genres)
            options.filter.push({
                "Title": tr("Genres")
                "Name": "Genres"
                "Options": data.genres
                "Delimiter": "|"
                "CheckedState": []
            })
        end if
        if isValid(data.Years)
            options.filter.push({
                "Title": tr("Years")
                "Name": "Years"
                "Options": data.Years
                "Delimiter": ","
                "CheckedState": []
            })
        end if
    end if
    setSelectedOptions(options)
    m.options.options = options
end sub

' Data to display when options button selected
sub setSelectedOptions(options)
    ' Set selected view option
    for each o in options.views
        if isStringEqual(o.Name, m.view)
            m.viewButton.text = tr(o.LookupCI("title"))
            o.Selected = true
        end if
    end for
    ' Set selected sort option
    for each o in options.sort
        if isStringEqual(o.Name, m.sortField)
            m.sortButton.text = tr(o.LookupCI("title"))
            o.Selected = true
        end if
    end for
    ' Set selected filter
    for each o in options.filter
        if isStringEqual(o.Name, m.filter)
            o.Selected = true
            m.filterButton.text = tr(o.LookupCI("title"))
            m.options.filter = o.Name
        end if
        ' Select selected filter options
        if isValid(o.options) and isValid(m.filterOptions)
            if o.options.Count() > 0 and m.filterOptions.Count() > 0
                if LCase(o.Name) = LCase(m.filterOptions.keys()[0])
                    selectedFilterOptions = m.filterOptions[m.filterOptions.keys()[0]].split(o.delimiter)
                    checkedState = []
                    for each availableFilterOption in o.options
                        matchFound = false
                        for each selectedFilterOption in selectedFilterOptions
                            if LCase(toString(availableFilterOption).trim()) = LCase(selectedFilterOption.trim())
                                matchFound = true
                            end if
                        end for
                        checkedState.push(matchFound)
                    end for
                    o.checkedState = checkedState
                end if
            end if
        end if
    end for
    m.options.options = options
    if m.sortAscending then
        m.sortOrderButton.text = tr("Ascending")
    else
        m.sortOrderButton.text = tr("Descending")
    end if
end sub

' Set Music view, sort, and filter options
function setMusicOptions() as object
    options = {
        filter: []
    }
    options.views = [
        {
            "Title": tr("Artists (Presentation)")
            "Name": "ArtistsPresentation"
            "Track": {
                "description": tr("Artists (Presentation)")
            }
        }
        {
            "Title": tr("Artists (Grid)")
            "Name": "ArtistsGrid"
            "Track": {
                "description": tr("Artists (Grid)")
            }
        }
        {
            "Title": tr("Album Artists (Presentation)")
            "Name": "AlbumArtistsPresentation"
            "Track": {
                "description": tr("Album Artists (Presentation)")
            }
        }
        {
            "Title": tr("Album Artists (Grid)")
            "Name": "AlbumArtistsGrid"
            "Track": {
                "description": tr("Album Artists (Grid)")
            }
        }
        {
            "Title": tr("Albums")
            "Name": "Albums"
            "Track": {
                "description": tr("Albums")
            }
        }
        {
            "Title": tr("Genres")
            "Name": "Genres"
            "Track": {
                "description": tr("Genres")
            }
        }
    ]
    options.sort = [
        {
            "Title": tr("TITLE")
            "Name": "SortName"
            "Track": {
                "description": tr("TITLE")
            }
        }
        {
            "Title": tr("DATE_ADDED")
            "Name": "DateCreated,SortName"
            "Track": {
                "description": tr("DATE_ADDED")
            }
        }
        {
            "Title": tr("DATE_PLAYED")
            "Name": "DatePlayed,SortName"
            "Track": {
                "description": tr("DATE_PLAYED")
            }
        }
        {
            "Title": tr("RELEASE_DATE")
            "Name": "PremiereDate,SortName"
            "Track": {
                "description": tr("RELEASE_DATE")
            }
        }
        {
            "Title": tr("Random")
            "Name": "Random"
            "Track": {
                "description": tr("Random")
            }
        }
    ]
    options.filter = [
        {
            "Title": tr("All")
            "Name": "All"
            "Track": {
                "description": tr("All")
            }
        }
        {
            "Title": tr("Favorites")
            "Name": "Favorites"
            "Track": {
                "description": tr("Favorites")
            }
        }
    ]
    if inArray([
        "musicartist"
        "albumartists"
    ], LCase(m.loadItemsTask.itemType))
        options.sort = [
            {
                "Title": tr("TITLE")
                "Name": "SortName"
                "Track": {
                    "description": tr("TITLE")
                }
            }
            {
                "Title": tr("DATE_ADDED")
                "Name": "DateCreated,SortName"
                "Track": {
                    "description": tr("DATE_ADDED")
                }
            }
            {
                "Title": tr("Random")
                "Name": "Random"
                "Track": {
                    "description": tr("Random")
                }
            }
        ]
    end if
    if isStringEqual(m.top.parentItem.json.type, "musicgenre")
        options.views = [
            {
                "Title": tr("Albums")
                "Name": "Albums"
                "Track": {
                    "description": tr("Albums")
                }
            }
        ]
    end if
    if isStringEqual(m.view, "genres")
        options.sort = [
            {
                "Title": tr("TITLE")
                "Name": "SortName"
                "Track": {
                    "description": tr("TITLE")
                }
            }
            {
                "Title": tr("Random")
                "Name": "Random"
                "Track": {
                    "description": tr("Random")
                }
            }
        ]
        options.filter = [
            {
                "Title": tr("All")
                "Name": "All"
                "Track": {
                    "description": tr("All")
                }
            }
        ]
    end if
    if isStringEqual(m.view, "albums")
        options.sort = [
            {
                "Title": tr("TITLE")
                "Name": "SortName"
                "Track": {
                    "description": tr("TITLE")
                }
            }
            {
                "Title": tr("Album Artist")
                "Name": "AlbumArtist,SortName"
                "Track": {
                    "description": tr("Album Artist")
                }
            }
            {
                "Title": tr("DATE_ADDED")
                "Name": "DateCreated,SortName"
                "Track": {
                    "description": tr("DATE_ADDED")
                }
            }
            {
                "Title": tr("RELEASE_DATE")
                "Name": "ProductionYear,SortName"
                "Track": {
                    "description": tr("RELEASE_DATE")
                }
            }
            {
                "Title": tr("Random")
                "Name": "Random"
                "Track": {
                    "description": tr("Random")
                }
            }
        ]
    end if
    return options
end function

' Return parent collection type
function getCollectionType() as string
    if m.top.parentItem.collectionType = invalid
        return LCase(m.top.parentItem.Type)
    else
        return LCase(m.top.parentItem.CollectionType)
    end if
end function

' Search string array for search value. Return if it's found
function inStringArray(array, searchValue) as boolean
    for each item in array
        if lcase(item) = lcase(searchValue) then
            return true
        end if
    end for
    return false
end function

'
' Logo Image Loaded Event Handler
sub LogoImageLoaded(msg)
    data = msg.GetData()
    m.loadLogoTask.unobserveField("content")
    m.loadLogoTask.content = []
    if data.Count() > 0
        m.artistLogo.uri = data[0]
        m.artistLogo.visible = true
    else
        m.selectedArtistName.visible = true
    end if
end sub

'
'Handle loaded data, and add to Grid
sub ItemDataLoaded(msg)
    itemData = msg.GetData()
    m.loadItemsTask.unobserveField("content")
    m.loadItemsTask.content = []
    if itemData = invalid
        m.Loading = false
        stopLoadingSpinner()
        return
    end if
    if LCase(m.loadItemsTask.view) = "genres"
        for each item in itemData
            m.genreData.appendChild(item)
        end for
        m.itemGrid.opacity = "0"
        m.genreList.opacity = "1"
        m.itemGrid.setFocus(false)
        m.genreList.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.genreList
        m.loadedItems = m.genreList.content.getChildCount()
        m.loadedRows = m.loadedItems / m.genreList.numColumns
        if m.loadedItems = 0
            m.emptyText.text = tr("NO_ITEMS").Replace("%1", m.top.parentItem.Type)
            m.emptyText.visible = true
            m.voiceBox.setfocus(true)
            setSearchBackground(0)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.voiceBox
        end if
        m.loading = false
        stopLoadingSpinner()
        return
    end if
    ' keep focus on alpha menu if it's active
    if m.top.alphaActive
        m.alphaMenu.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.alphaMenu
    else
        m.itemGrid.opacity = "1"
        m.genreList.opacity = "0"
        m.alphaMenu.setFocus(false)
        m.itemGrid.setFocus(true)
        m.genreList.setFocus(false)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.itemGrid
    end if
    m.data.appendChildren(itemData)
    'Update the stored counts
    m.loadedItems = m.itemGrid.content.getChildCount()
    m.loadedRows = m.loadedItems / m.itemGrid.numColumns
    m.Loading = false
    'If there are no items to display, show message
    if m.loadedItems = 0
        m.artistLogo.visible = false
        m.selectedArtistName.visible = false
        m.selectedArtistGenres.visible = false
        m.selectedArtistSongCount.visible = false
        m.selectedArtistAlbumCount.visible = false
        m.emptyText.text = tr("NO_ITEMS").Replace("%1", m.top.parentItem.Type)
        m.emptyText.visible = true
        m.voiceBox.setfocus(true)
        setSearchBackground(0)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.voiceBox
    end if
    stopLoadingSpinner()
end sub

'
'Set Selected Artist Name
sub SetName(artistName as string)
    m.selectedArtistName.text = artistName
end sub

'
'Set Selected Artist Song Count
sub SetSongCount(totalCount)
    appendText = " " + tr("Songs")
    if totalCount = 1
        appendText = " " + tr("Song")
    end if
    m.selectedArtistSongCount.text = totalCount.tostr() + appendText
end sub

'
'Set Selected Artist Album Count
sub SetAlbumCount(totalCount)
    appendText = " " + tr("Albums")
    if totalCount = 1
        appendText = " " + tr("Album")
    end if
    m.selectedArtistAlbumCount.text = totalCount.tostr() + appendText
end sub

'
'Set Selected Artist Genres
sub SetGenres(artistGenres)
    m.selectedArtistGenres.text = artistGenres.join(", ")
end sub

'
'Set Background Image
sub SetBackground(backgroundUri as string)
    if backgroundUri = ""
        m.backdrop.opacity = 0
    end if
    'If a new image is being loaded, or transitioned to, store URL to load next
    if LCase(m.swapAnimation.state) <> "stopped" or LCase(m.newBackdrop.loadStatus) = "loading"
        m.queuedBGUri = backgroundUri
        return
    end if
    m.newBackdrop.uri = backgroundUri
end sub

'
'Handle new item being focused
sub onItemFocused()
    focusedRow = m.itemGrid.currFocusRow
    if m.itemGrid.isinFocusChain() or m.dropdownOptions.isinFocusChain()
        if focusedRow = 0
            if m.dropdownOptions.opacity < 1
                toggleDropdownOptions(true)
            end if
        else if focusedRow > 0
            if m.dropdownOptions.opacity > 0
                toggleDropdownOptions(false)
            end if
        end if
    end if
    itemInt = m.itemGrid.itemFocused
    ' If no selected item, set background to parent backdrop
    if itemInt = -1
        return
    end if
    m.artistLogo.visible = false
    m.selectedArtistName.visible = false
    m.selectedArtistGenres.visible = false
    m.selectedArtistSongCount.visible = false
    m.selectedArtistAlbumCount.visible = false
    ' Load more data if focus is within last 5 rows, and there are more items to load
    if focusedRow >= m.loadedRows - 5 and m.loadeditems < m.loadItemsTask.totalRecordCount
        loadMoreData()
    end if
    m.selectedFavoriteItem = getItemFocused()
    if isStringEqual(m.view, "albums") or isStringEqual(m.top.parentItem.json.type, "musicgenre")
        return
    end if
    if isStringEqual(m.view, "artistsgrid")
        return
    end if
    if isStringEqual(m.view, "albumartistsgrid")
        return
    end if
    if not m.selectedArtistGenres.visible
        m.selectedArtistGenres.visible = true
    end if
    if not m.selectedArtistSongCount.visible
        m.selectedArtistSongCount.visible = true
    end if
    if not m.selectedArtistAlbumCount.visible
        m.selectedArtistAlbumCount.visible = true
    end if
    if not isChainValid(m.selectedFavoriteItem, "json") then
        return
    end if
    itemData = m.selectedFavoriteItem.json
    if isValid(itemData.SongCount)
        SetSongCount(itemData.SongCount)
    else
        SetSongCount("")
    end if
    if isValid(itemData.AlbumCount)
        SetAlbumCount(itemData.AlbumCount)
    else
        SetAlbumCount("")
    end if
    if isValid(itemData.Genres)
        SetGenres(itemData.Genres)
    else
        SetGenres([])
    end if
    if isValid(itemData.Name)
        SetName(itemData.Name)
    else
        SetName("")
    end if
    m.loadLogoTask.itemId = itemData.id
    m.loadLogoTask.itemType = "LogoImage"
    m.loadLogoTask.observeField("content", "LogoImageLoaded")
    m.loadLogoTask.control = "RUN"
    ' Set Background to item backdrop
    SetBackground(m.selectedFavoriteItem.backdropUrl)
end sub

sub setFieldText(field, value)
    node = m.top.findNode(field)
    if node = invalid or value = invalid then
        return
    end if
    ' Handle non strings... Which _shouldn't_ happen, but hey
    if type(value) = "roInt" or type(value) = "Integer"
        value = str(value)
    else if type(value) = "roFloat" or type(value) = "Float"
        value = str(value)
    else if type(value) <> "roString" and type(value) <> "String"
        value = ""
    end if
    node.text = value
end sub

'
'When Image Loading Status changes
sub newBGLoaded()
    'If image load was sucessful, start the fade swap
    if LCase(m.newBackdrop.loadStatus) = "ready"
        m.swapAnimation.control = "start"
    end if
end sub

'
'Swap Complete
sub swapDone()
    if LCase(m.swapAnimation.state) = "stopped"
        'Set main BG node image and hide transitioning node
        m.backdrop.uri = m.newBackdrop.uri
        m.backdrop.opacity = 1
        m.newBackdrop.opacity = 0
        'If there is another one to load
        if m.newBackdrop.uri <> m.queuedBGUri and m.queuedBGUri <> ""
            SetBackground(m.queuedBGUri)
            m.queuedBGUri = ""
        end if
    end if
end sub

'
'Load next set of items
sub loadMoreData()
    if m.Loading = true then
        return
    end if
    startLoadingSpinner(false)
    m.Loading = true
    m.loadItemsTask.startIndex = m.loadedItems
    m.loadItemsTask.observeField("content", "ItemDataLoaded")
    m.loadItemsTask.control = "RUN"
end sub

'
'Item Selected
sub onItemSelected()
    m.top.selectedItem = m.itemGrid.content.getChild(m.itemGrid.itemSelected)
end sub

'
'Returns Focused Item
function getItemFocused()
    if m.itemGrid.isinFocusChain() and isValid(m.itemGrid.itemFocused)
        return m.itemGrid.content.getChild(m.itemGrid.itemFocused)
    else if m.genreList.isinFocusChain() and isValid(m.genreList.itemFocused)
        return m.genreList.content.getChild(m.genreList.itemFocused)
    end if
    return invalid
end function

'
'Genre Item Selected
sub onGenreItemSelected()
    m.top.selectedItem = m.genreList.content.getChild(m.genreList.itemSelected)
end sub

'
'Genre Item Focused
sub onGenreItemFocused()
    focusedRow = m.genreList.currFocusRow
    if m.genreList.isinFocusChain()
        if focusedRow = 0
            if m.dropdownOptions.opacity < 1
                toggleDropdownOptions(true)
            end if
        else if focusedRow > 0
            if m.dropdownOptions.opacity > 0
                toggleDropdownOptions(false)
            end if
        end if
    end if
    ' Load more data if focus is within last 5 rows, and there are more items to load
    if focusedRow >= m.loadedRows - 5 and m.loadeditems < m.loadItemsTask.totalRecordCount
        loadMoreData()
    end if
end sub

sub toggleDropdownOptions(runInReverse = false as boolean)
    m.dropdownOptionsFade.reverse = runInReverse
    m.dropdownOptionsMove.reverse = runInReverse
    m.itemGridMove.reverse = runInReverse
    m.genreListMove.reverse = runInReverse
    if not isStringEqual(m.toggleDropdownOptionsAnimation.state, "running")
        m.toggleDropdownOptionsAnimation.control = "start"
    end if
end sub

sub processDropdownState(searchTerm as string)
    if not isStringEqual(searchTerm, "")
        resetDropdownsToDefaultState()
        setDropdownDisabledState(true)
        return
    end if
    setDropdownDisabledState(false)
end sub

sub setDropdownDisabledState(disabledState = false as boolean)
    m.sortButton.disabled = disabledState
    m.sortOrderButton.disabled = disabledState
    m.filterButton.disabled = disabledState
end sub

sub resetDropdownsToDefaultState()
    m.filter = "All"
    m.filterOptions = {}
    if isStringEqual(getCollectionType(), "boxset")
        m.sortField = "PremiereDate,SortName"
    else if isStringEqual(getCollectionType(), "mylist")
        m.sortField = "OrderAdded"
    else
        m.sortField = "SortName"
    end if
    m.sortAscending = true
    ' Reset view to defaults
    set_user_setting("display." + m.settingID + ".sortField", m.sortField)
    set_user_setting("display." + m.settingID + ".sortAscending", "true")
    set_user_setting("display." + m.settingID + ".filter", m.filter)
    set_user_setting("display." + m.settingID + ".filterOptions", FormatJson(m.filterOptions))
    if not isStringEqual(m.view, "Genres")
        set_user_setting(("display." + bslib_toString(m.top.mediaType) + "library.defaultview"), m.view)
    end if
    m.getFiltersTask.control = "RUN"
end sub

sub onSearchTermChanged()
    if m.top.searchTerm = "" then
        m.voiceBox.hintText = tr("Press OK to type")
    else
        m.voiceBox.hintText = m.top.searchTerm
    end if
    onVoiceEnabledChange()
    if isStringEqual(m.loadItemsTask.searchTerm, m.top.searchTerm) then
        return
    end if
    setSearchBackground(1)
    processDropdownState(m.top.searchTerm)
    if m.bypassSearchEvent
        m.bypassSearchEvent = false
        return
    end if
    m.loadedRows = 0
    m.loadedItems = 0
    m.data = CreateObject("roSGNode", "ContentNode")
    m.itemGrid.content = m.data
    m.genreData = CreateObject("roSGNode", "ContentNode")
    m.genreList.content = m.genreData
    loadInitialItems()
end sub

sub alphaSelectedChanged()
    ' Prevent voicebox change double firing
    if m.voiceBox.text = ""
        ' Allow user to toggle by clicking letter twice
        if isStringEqual(m.loadItemsTask.nameStartsWith, m.top.alphaSelected)
            m.top.alphaSelected = ""
        end if
    end if
    m.loadedRows = 0
    m.loadedItems = 0
    m.data = CreateObject("roSGNode", "ContentNode")
    m.itemGrid.content = m.data
    m.genreData = CreateObject("roSGNode", "ContentNode")
    m.genreList.content = m.genreData
    m.loadItemsTask.nameStartsWith = m.top.alphaSelected
    m.voiceBox.text = ""
    m.top.searchTerm = ""
    loadInitialItems()
end sub

sub unfocusAllButtons()
    setSearchBackground(1)
    m.sortButton.focus = false
    m.sortOrderButton.focus = false
    m.filterButton.focus = false
    m.viewButton.focus = false
end sub

sub onvoiceFilter()
    if not isValidAndNotEmpty(m.voiceBox.text) then
        return
    end if
    unfocusAllButtons()
    if isStringEqual(m.voiceBox.text.trim(), "reset search") then
        m.voiceBox.text = ""
    end if
    if isStringEqual(m.voiceBox.text.trim(), "clear search") then
        m.voiceBox.text = ""
    end if
    m.voiceBox.hintText = m.voiceBox.text
    ' If user searched for a letter, selected it from the alpha menu
    if m.voiceBox.text.len() = 1
        alphaMenu = m.top.findNode("alphaMenu")
        intConversion = m.voiceBox.text.ToInt() ' non numeric input returns as 0
        if m.voiceBox.text = "0" or (isValid(intConversion) and intConversion <> 0)
            alphaMenu.jumpToItem = 0
        else
            ' loop through each option until we find a match
            for i = 1 to alphaMenu.numRows - 1
                alphaMenuOption = alphaMenu.content.getChild(i)
                if isStringEqual(alphaMenuOption.TITLE, m.voiceBox.text)
                    alphaMenu.jumpToItem = i
                    exit for
                end if
            end for
        end if
        m.top.alphaSelected = m.voiceBox.text
        return
    end if
    m.top.searchTerm = m.voiceBox.text.trim()
end sub

' Using the user's cursor position, determine which dropdown is above them
function getOverhangingButton()
    if m.itemGrid.isinFocusChain() then
        gridNode = m.itemGrid
    else
        gridNode = m.genreList
    end if
    if gridNode.numColumns = 4
        buttonList = [
            m.voiceBox
            m.sortButton
            m.filterButton
            m.viewButton
        ]
        return buttonList[gridNode.currFocusColumn]
    end if
    buttonList = [
        m.voiceBox
        m.sortButton
        m.sortOrderButton
        m.filterButton
        m.viewButton
    ]
    columnDisplacement = (gridNode.numColumns / buttonList.count())
    calculatedButtonIndex = CInt(((gridNode.currFocusColumn + 1) / columnDisplacement) - 1)
    if calculatedButtonIndex < 0 then
        calculatedButtonIndex = 0
    end if
    if calculatedButtonIndex >= buttonList.count() then
        calculatedButtonIndex = buttonList.count() - 1
    end if
    return buttonList[calculatedButtonIndex]
end function

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        return false
    end if
    if key = "left" and m.voiceBox.isinFocusChain()
        m.itemGrid.setFocus(m.itemGrid.opacity = 1)
        m.genreList.setFocus(m.genreList.opacity = 1)
        m.voiceBox.setFocus(false)
        setSearchBackground(1)
        group = m.global.sceneManager.callFunc("getActiveScene")
        if m.itemGrid.opacity = 1 then
            group.lastFocus = m.itemGrid
        else
            group.lastFocus = m.genreList
        end if
    end if
    if isStringEqual(key, "up")
        if m.itemGrid.isinFocusChain() or m.genreList.isinFocusChain()
            ' In case user quickly moves out of grid without focused row getting updated
            if m.dropdownOptions.opacity < 1
                toggleDropdownOptions(true)
            end if
            overhangButton = getOverhangingButton()
            if overhangButton.isSubType("VoiceTextEditBox")
                setSearchBackground(0)
            else
                overhangButton.focus = true
            end if
            overhangButton.setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = overhangButton
            return true
        end if
    end if
    if isStringEqual(key, "OK")
        if m.voiceBox.isinFocusChain()
            buttonData = [
                tr("Search")
            ]
            m.global.sceneManager.callFunc("keyboardDialog", "searchLibrary", tr("Search this library"), [
                ""
            ], buttonData, m.top.searchTerm, m.top.parentItem.Id)
            return true
        end if
        if m.sortButton.isinFocusChain()
            if m.sortButton.disabled then
                return false
            end if
            sortData = {
                data: m.options.options.sort
            }
            m.global.sceneManager.callFunc("radioDialog", tr("Sort By"), sortData)
            m.global.sceneManager.observeFieldScoped("returnData", "onSortChange")
            return true
        end if
        if m.sortOrderButton.isinFocusChain()
            if m.sortOrderButton.disabled then
                return false
            end if
            sortOrderData = {
                data: [
                    {
                        Title: tr("Ascending")
                        Name: "ascending"
                        Track: {
                            description: tr("Ascending")
                        }
                    }
                    {
                        Title: tr("Descending")
                        Name: "descending"
                        Track: {
                            description: tr("Descending")
                        }
                    }
                ]
            }
            if m.sortAscending
                sortOrderData.data[0].selected = true
            else
                sortOrderData.data[1].selected = true
            end if
            m.global.sceneManager.callFunc("radioDialog", tr("Sort Order"), sortOrderData)
            m.global.sceneManager.observeFieldScoped("returnData", "onSortOrderChange")
            return true
        end if
        if m.filterButton.isinFocusChain()
            if m.filterButton.disabled then
                return false
            end if
            m.options.visible = true
            m.options.findNode("filterMenu").setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.options
            return true
        end if
        if m.viewButton.isinFocusChain()
            viewData = {
                data: m.options.options.views
            }
            m.global.sceneManager.callFunc("radioDialog", tr("TAB_VIEW"), viewData)
            m.global.sceneManager.observeFieldScoped("returnData", "onViewChange")
            return true
        end if
    end if
    if m.dropdownOptions.isinFocusChain()
        if isStringEqual(key, "left")
            if m.voiceBox.isinFocusChain()
                setSearchBackground(1)
                m.sortButton.focus = false
                m.sortOrderButton.focus = false
                m.viewButton.focus = false
                m.filterButton.focus = false
                m.top.alphaActive = true
                m.alphaMenu.setFocus(true)
                group = m.global.sceneManager.callFunc("getActiveScene")
                group.lastFocus = m.alphaMenu
                return true
            end if
            if m.sortButton.isinFocusChain()
                m.voiceBox.setFocus(true)
                setSearchBackground(0)
                m.sortButton.focus = false
                group = m.global.sceneManager.callFunc("getActiveScene")
                group.lastFocus = m.voiceBox
                return true
            end if
            if m.sortOrderButton.isinFocusChain()
                m.sortButton.focus = true
                m.sortButton.setFocus(true)
                m.sortOrderButton.focus = false
                group = m.global.sceneManager.callFunc("getActiveScene")
                group.lastFocus = m.sortButton
                return true
            end if
            if m.filterButton.isinFocusChain()
                m.filterButton.focus = false
                m.sortOrderButton.focus = true
                m.sortOrderButton.setFocus(true)
                group = m.global.sceneManager.callFunc("getActiveScene")
                group.lastFocus = m.sortOrderButton
                return true
            end if
            if m.viewButton.isinFocusChain()
                m.viewButton.focus = false
                m.filterButton.focus = true
                m.filterButton.setFocus(true)
                group = m.global.sceneManager.callFunc("getActiveScene")
                group.lastFocus = m.filterButton
                return true
            end if
        end if
        if isStringEqual(key, "right")
            if m.voiceBox.isinFocusChain()
                setSearchBackground(1)
                m.sortButton.focus = true
                m.sortButton.setFocus(true)
                group = m.global.sceneManager.callFunc("getActiveScene")
                group.lastFocus = m.sortButton
                return true
            end if
            if m.sortButton.isinFocusChain()
                m.sortButton.focus = false
                m.sortOrderButton.focus = true
                m.sortOrderButton.setFocus(true)
                group = m.global.sceneManager.callFunc("getActiveScene")
                group.lastFocus = m.sortOrderButton
                return true
            end if
            if m.sortOrderButton.isinFocusChain()
                m.sortOrderButton.focus = false
                m.filterButton.focus = true
                m.filterButton.setFocus(true)
                group = m.global.sceneManager.callFunc("getActiveScene")
                group.lastFocus = m.filterButton
                return true
            end if
            if m.filterButton.isinFocusChain()
                m.filterButton.focus = false
                m.viewButton.focus = true
                m.viewButton.setFocus(true)
                group = m.global.sceneManager.callFunc("getActiveScene")
                group.lastFocus = m.viewButton
                return true
            end if
        end if
        if isStringEqual(key, "down")
            if m.loadedItems = 0 then
                return false
            end if
            setSearchBackground(1)
            m.sortButton.focus = false
            m.sortOrderButton.focus = false
            m.viewButton.focus = false
            m.filterButton.focus = false
            m.itemGrid.setFocus(m.itemGrid.opacity = 1)
            m.genreList.setFocus(m.genreList.opacity = 1)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.itemGrid
            return true
        end if
    end if
    if isStringEqual(key, "options")
        focusedItem = getItemFocused()
        if not isValid(focusedItem) then
            return false
        end if
        popupTitle = focusedItem.LookupCI("title")
        if isValid(popupTitle)
            if isChainValid(focusedItem, "json.AlbumArtist")
                popupTitle = (bslib_toString(chainLookup(focusedItem, "json.AlbumArtist")) + " - " + bslib_toString(popupTitle))
            end if
        end if
        if isStringEqual(focusedItem.LookupCI("type"), "musicalbum")
            dialogData = [
                tr("Play Album")
                tr("Shuffle Play Album")
                tr("Instant Mix Album")
                tr("Add To Playlist")
            ]
            m.global.sceneManager.callFunc("optionDialog", "libraryitem", (function(popupTitle, tr)
                    __bsConsequent = popupTitle
                    if __bsConsequent <> invalid then
                        return __bsConsequent
                    else
                        return tr("Options")
                    end if
                end function)(popupTitle, tr), [], dialogData, {
                id: focusedItem.LookupCI("id")
            })
        end if
        return true
    end if
    if isStringEqual(key, "back")
        ' If user pressed back whole scrolled down the grid, reset to item 1
        if m.itemGrid.isinFocusChain() or m.genreList.isinFocusChain()
            if m.itemGrid.isinFocusChain() then
                gridComponent = m.itemGrid
            else
                gridComponent = m.genreList
            end if
            if gridComponent.itemFocused = 0
                reclaimResources()
                m.global.sceneManager.callfunc("popScene")
                return true
            end if
            gridComponent.jumpToItem = 0
            return true
        end if
        reclaimResources()
        m.global.sceneManager.callfunc("popScene")
        return true
    end if
    if key = "left"
        if m.itemGrid.isinFocusChain()
            m.top.alphaActive = true
            m.itemGrid.setFocus(false)
            m.alphaMenu.setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.alphaMenu
            return true
        else if m.genreList.isinFocusChain()
            m.top.alphaActive = true
            m.genreList.setFocus(false)
            m.alphaMenu.setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.alphaMenu
            return true
        end if
    else if key = "right" and m.alpha.isinFocusChain()
        m.top.alphaActive = false
        m.alphaMenu.setFocus(false)
        m.itemGrid.setFocus(m.itemGrid.opacity = 1)
        m.genreList.setFocus(m.genreList.opacity = 1)
        group = m.global.sceneManager.callFunc("getActiveScene")
        if m.itemGrid.opacity = 1 then
            group.lastFocus = m.itemGrid
        else
            group.lastFocus = m.genreList
        end if
        return true
    else if key = "play"
        itemToPlay = getItemFocused()
        if itemToPlay <> invalid
            m.top.quickPlayNode = itemToPlay
            return true
        end if
    end if
    return false
end function

sub reclaimResources()
    m.loadItemsTask.control = "STOP"
    m.loadItemsTask.content = []
    m.data = CreateObject("roSGNode", "ContentNode")
    m.itemGrid.content = m.data
    m.genreData = CreateObject("roSGNode", "ContentNode")
    m.genreList.content = m.genreData
end sub

sub setSearchBackground(state)
    if state = 0
        m.voiceBox.textColor = "#ffffff"
        m.voiceBox.hintTextColor = "#ffffff"
        m.voiceBoxBackground.blendColor = "0xff6867FF"
        return
    end if
    m.voiceBox.textColor = "#777777"
    m.voiceBox.hintTextColor = "#777777"
    m.voiceBoxBackground.blendColor = "#ffffff"
end sub
'//# sourceMappingURL=./MusicLibraryView.brs.map