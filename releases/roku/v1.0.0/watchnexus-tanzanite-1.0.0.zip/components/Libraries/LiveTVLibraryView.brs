'import "pkg:/source/api/baserequest.bs"
'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/ImageLayout.bs"
'import "pkg:/source/enums/KeyCode.bs"
'import "pkg:/source/enums/String.bs"
'import "pkg:/source/enums/TaskControl.bs"
'import "pkg:/source/utils/config.bs"
'import "pkg:/source/utils/deviceCapabilities.bs"
'import "pkg:/source/utils/misc.bs"





sub init()
    m.top.imageDisplayMode = "scaleToZoom"
    m.top.showItemTitles = "showonhover"
    overhang = m.top.getScene().findNode("overhang")
    overhang.isVisible = false
    m.options = m.top.findNode("options")
    m.tvGuide = invalid
    m.channelFocused = invalid
    m.data = CreateObject("roSGNode", "ContentNode")
    m.itemGrid = m.top.findNode("itemGrid")
    m.itemGrid.focusBitmapBlendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    m.itemGrid.observeField("itemFocused", "onItemFocused")
    m.itemGrid.observeField("itemSelected", "onItemSelected")
    m.itemGrid.content = m.data
    m.emptyText = m.top.findNode("emptyText")
    m.loadedRows = 0
    m.loadedItems = 0
    group = m.global.sceneManager.callFunc("getActiveScene")
    group.lastFocus = m.itemGrid
    'Voice filter setup
    m.voiceBox = m.top.findNode("voiceBox")
    m.voiceBox.voiceEnabled = true
    m.voiceBox.active = true
    m.voiceBox.observeField("text", "onvoiceFilter")
    'set voice help text
    m.voiceBox.hintText = tr("Use voice remote to search")
    'Item sort - maybe load defaults from user prefs?
    m.sortField = "SortName"
    m.sortAscending = true
    m.filter = "All"
    m.loadItemsTask = createObject("roSGNode", "LoadItemsTask2")
    setColumnSizes("portrait")
    'set inital counts for overhang before content is loaded.
    m.loadItemsTask.totalRecordCount = 0
    m.alpha = m.top.findNode("alpha")
    m.alphaMenu = m.alpha.findNode("alphaMenu")
    m.top.gridTitles = m.global.session.user.settings["itemgrid.gridTitles"]
end sub

sub setColumnSizes(layout = "portrait" as string)
    if isStringEqual(layout, "portrait")
        numberOfColumns = chainLookupReturn(m.global.session, "user.settings.numberOfColumnsPortrait", "7")
        imageWidthData = val(chainLookupReturn(m.global.session, "user.settings.numberOfColumnsPortraitData", "230"))
    else
        numberOfColumns = chainLookupReturn(m.global.session, "user.settings.numberOfColumnsLandscape", "4")
        imageWidthData = val(chainLookupReturn(m.global.session, "user.settings.numberOfColumnsLandscapeData", "400"))
    end if
    if isStringEqual(m.top.showItemTitles, "hidealways")
        if isStringEqual(layout, "portrait") then
            aspectRatio = 1.52173
        else
            aspectRatio = .825
        end if
    else
        if isStringEqual(layout, "portrait") then
            aspectRatio = 1.69565
        else
            aspectRatio = .925
        end if
    end if
    defaultSize = [
        imageWidthData
        CInt(imageWidthData * aspectRatio)
    ]
    m.itemGrid.itemSize = defaultSize
    m.itemGrid.rowHeights = [
        defaultSize[1]
    ]
    m.itemGrid.numRows = abs(1230 / (defaultSize[1] + m.itemGrid.itemSpacing[1]))
    m.itemGrid.numColumns = numberOfColumns
    m.loadItemsTask.numberOfColumns = numberOfColumns
end sub

'Load initial set of Data
sub loadInitialItems()
    m.loadItemsTask.control = "stop"
    startLoadingSpinner()
    if m.top.parentItem.json.Type = "CollectionFolder"
        m.top.HomeLibraryItem = m.top.parentItem.Id
    end if
    ' Read view/sort/filter settings
    ' Translate between app and server nomenclature
    viewSetting = m.global.session.user.settings["display.livetv.landing"]
    if viewSetting = "guide"
        m.view = "tvGuide"
    else
        m.view = "livetv"
        if isValid(m.tvGuide)
            m.tvGuide.opacity = 0
        end if
        m.alpha.visible = true
        m.itemGrid.opacity = 1
    end if
    m.sortField = m.global.session.user.settings["display.livetv.sortField"]
    sortAscendingStr = m.global.session.user.settings["display.livetv.sortAscending"]
    m.filter = m.global.session.user.settings["display.livetv.filter"]
    if not isValidAndNotEmpty(m.filter) then
        m.filter = "All"
    end if
    if not isValidAndNotEmpty(m.sortField)
        m.sortField = "SortName"
    end if
    if sortAscendingStr = invalid or sortAscendingStr = true
        m.sortAscending = true
    else
        m.sortAscending = false
    end if
    m.loadItemsTask.itemId = m.top.parentItem.Id
    ' if we already searched for this alpha text than reset filter
    if m.loadItemsTask.nameStartsWith = m.top.alphaSelected
        m.loadItemsTask.nameStartsWith = ""
        m.top.alphaSelected = ""
    else
        m.loadItemsTask.nameStartsWith = m.alpha.letterSelected
    end if
    m.loadItemsTask.searchTerm = m.voiceBox.text
    m.emptyText.visible = false
    m.loadItemsTask.sortField = m.sortField
    m.loadItemsTask.sortAscending = m.sortAscending
    m.loadItemsTask.filter = m.filter
    m.loadItemsTask.startIndex = 0
    ' Load Item Types
    m.loadItemsTask.itemType = "TvChannel"
    m.loadItemsTask.itemId = " "
    ' For LiveTV, we want to "Fit" the item images, not zoom
    m.top.imageDisplayMode = "scaleToFit"
    if m.global.session.user.settings["display.livetv.landing"] = "guide" and m.options.view <> "livetv"
        showTvGuide()
    end if
    m.loadItemsTask.observeField("content", "ItemDataLoaded")
    startLoadingSpinner(false)
    m.loadItemsTask.control = "RUN"
    SetUpOptions()
end sub

' Data to display when options button selected
sub setSelectedOptions(options)
    ' Set selected view option
    for each o in options.views
        if o.Name = m.view
            o.Selected = true
            o.Ascending = m.sortAscending
            m.options.view = o.Name
        end if
    end for
    ' Set selected sort option
    for each o in options.sort
        if o.Name = m.sortField
            o.Selected = true
            o.Ascending = m.sortAscending
            m.options.sortField = o.Name
        end if
    end for
    ' Set selected filter
    for each o in options.filter
        if o.Name = m.filter
            o.Selected = true
            m.options.filter = o.Name
        end if
    end for
    m.options.options = options
end sub

' Set Live TV view, sort, and filter options
sub setLiveTvOptions(options)
    options.views = [
        {
            "Title": tr("Channels")
            "Name": "livetv"
        }
        {
            "Title": tr("TV Guide")
            "Name": "tvGuide"
        }
    ]
    options.sort = [
        {
            "Title": tr("TITLE")
            "Name": "SortName"
        }
    ]
    options.filter = [
        {
            "Title": tr("All")
            "Name": "All"
        }
        {
            "Title": tr("Favorites")
            "Name": "Favorites"
        }
    ]
    options.favorite = [
        {
            "Title": tr("Favorite")
            "Name": "Favorite"
        }
    ]
end sub

' Return parent collection type
function getCollectionType() as string
    if m.top.parentItem.collectionType = invalid
        return m.top.parentItem.Type
    else
        return m.top.parentItem.CollectionType
    end if
end function

' Search string array for search value. Return if it's found
function inStringArray(array, searchValue) as boolean
    for each item in array
        if lcase(item) = lcase(searchValue) then
            return true
        end if
    end for
    return false
end function

' Data to display when options button selected
sub SetUpOptions()
    options = {}
    options.filter = []
    options.favorite = []
    setLiveTvOptions(options)
    ' Set selected view option
    for each o in options.views
        if o.Name = m.view
            o.Selected = true
            o.Ascending = m.sortAscending
            m.options.view = o.Name
        end if
    end for
    ' Set selected sort option
    for each o in options.sort
        if o.Name = m.sortField
            o.Selected = true
            o.Ascending = m.sortAscending
            m.options.sortField = o.Name
        end if
    end for
    ' Set selected filter option
    for each o in options.filter
        if o.Name = m.filter
            o.Selected = true
            m.options.filter = o.Name
        end if
    end for
    m.options.options = options
end sub

'Handle loaded data, and add to Grid
sub ItemDataLoaded(msg)
    itemData = msg.GetData()
    m.loadItemsTask.unobserveField("content")
    m.loadItemsTask.content = []
    if not isValid(itemData)
        m.Loading = false
        stopLoadingSpinner()
        return
    end if
    for each item in itemData
        m.data.appendChild(item)
    end for
    ' keep focus on alpha menu when loading new data
    if m.top.alphaActive
        m.alphaMenu.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.alphaMenu
    else
        if not isStringEqual(m.global.session.user.settings["display.livetv.landing"], "guide") or isStringEqual(m.options.view, "livetv")
            m.itemGrid.setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.itemGrid
        end if
    end if
    'Update the stored counts
    m.loadedItems = m.itemGrid.content.getChildCount()
    m.loadedRows = m.loadedItems / m.itemGrid.numColumns
    m.Loading = false
    'If there are no items to display, show message
    if m.loadedItems = 0
        if isStringEqual(m.options.view, "tvGuide")
            m.emptyText.translation = "[0,650]"
            m.emptyText.text = tr("No channels found matching your search criteria")
        else
            m.emptyText.translation = "[0,540]"
            m.emptyText.text = tr("NO_ITEMS").Replace("%1", m.top.parentItem.Type)
        end if
        m.emptyText.visible = true
    end if
    if not isStringEqual(m.global.session.user.settings["display.livetv.landing"], "guide") or isStringEqual(m.options.view, "livetv")
        stopLoadingSpinner()
    end if
end sub

'Handle new item being focused
sub onItemFocused()
    focusedRow = m.itemGrid.currFocusRow
    itemInt = m.itemGrid.itemFocused
    if itemInt = -1
        return
    end if
    m.selectedFavoriteItem = m.itemGrid.content.getChild(m.itemGrid.itemFocused)
    ' Load more data if focus is within last 5 rows, and there are more items to load
    if m.loadItemsTask.totalRecordCount > 14
        if focusedRow >= m.loadedRows - m.itemGrid.numRows and m.loadeditems < m.loadItemsTask.totalRecordCount
            loadMoreData()
        end if
    end if
end sub

'Load next set of items
sub loadMoreData()
    if m.Loading = true then
        return
    end if
    startLoadingSpinner(false)
    m.Loading = true
    m.loadItemsTask.startIndex = m.loadedItems
    m.loadItemsTask.observeField("content", "ItemDataLoaded")
    m.loadItemsTask.control = "RUN"
end sub

'Item Selected
sub onItemSelected()
    m.top.selectedItem = m.itemGrid.content.getChild(m.itemGrid.itemSelected)
end sub

sub alphaSelectedChanged()
    if m.top.alphaSelected <> ""
        m.loadedRows = 0
        m.loadedItems = 0
        m.data = CreateObject("roSGNode", "ContentNode")
        m.itemGrid.content = m.data
        m.loadItemsTask.searchTerm = ""
        m.VoiceBox.text = ""
        loadInitialItems()
    end if
end sub

sub onvoiceFilter()
    if m.VoiceBox.text = "" then
        return
    end if
    if isStringEqual(m.voiceBox.text, "reset search") then
        m.voiceBox.text = ""
    end if
    if isStringEqual(m.voiceBox.text, "clear search") then
        m.voiceBox.text = ""
    end if
    m.loadedRows = 0
    m.loadedItems = 0
    m.data = CreateObject("roSGNode", "ContentNode")
    m.itemGrid.content = m.data
    m.top.alphaSelected = ""
    m.loadItemsTask.NameStartsWith = " "
    m.loadItemsTask.searchTerm = m.voiceBox.text
    m.loadItemsTask.recursive = true
    ' If user searched for a letter, selected it from the alpha menu
    if m.voiceBox.text.len() = 1
        alphaMenu = m.top.findNode("alphaMenu")
        intConversion = m.voiceBox.text.ToInt() ' non numeric input returns as 0
        if m.voiceBox.text = "0" or (isValid(intConversion) and intConversion <> 0)
            alphaMenu.jumpToItem = 0
        else
            ' loop through each option until we find a match
            for i = 1 to alphaMenu.numRows - 1
                alphaMenuOption = alphaMenu.content.getChild(i)
                if Lcase(alphaMenuOption.TITLE) = Lcase(m.voiceBox.text)
                    alphaMenu.jumpToItem = i
                    exit for
                end if
            end for
        end if
    end if
    loadInitialItems()
end sub

'Check if options updated and any reloading required
sub optionsClosed()
    reload = false
    ' Check if view option changed
    if not isStringEqual(m.options.view, m.view)
        if isStringEqual(m.options.view, "tvGuide")
            m.view = "tvGuide"
            set_user_setting("display.livetv.landing", "guide")
            showTVGuide()
            return
        else
            m.view = "livetv"
            set_user_setting("display.livetv.landing", "channels")
            if isValid(m.tvGuide)
                m.tvGuide.opacity = 0
            end if
            m.alpha.visible = true
            m.itemGrid.opacity = 1
            if isValid(m.tvGuide)
                ' Try to hide the TV Guide
                m.top.removeChild(m.tvGuide)
            end if
        end if
        reload = true
    end if
    ' Check if sort options changed
    if not isStringEqual(m.options.sortField, m.sortField) or not (m.options.sortAscending = m.sortAscending)
        m.sortField = m.options.sortField
        m.sortAscending = m.options.sortAscending
        reload = true
        set_user_setting("display.livetv.sortField", m.sortField)
        set_user_setting("display.livetv.sortAscending", m.sortAscending.tostr())
    end if
    ' Check if filter option changed
    if not isStringEqual(m.options.filter, m.filter)
        m.filter = m.options.filter
        reload = true
        'Store filter setting
        set_user_setting("display.livetv.filter", m.options.filter)
    end if
    if reload
        m.loadedRows = 0
        m.loadedItems = 0
        m.data = CreateObject("roSGNode", "ContentNode")
        m.itemGrid.content = m.data
        loadInitialItems()
    end if
    m.itemGrid.setFocus(m.itemGrid.opacity = 1)
    group = m.global.sceneManager.callFunc("getActiveScene")
    if m.itemGrid.opacity = 1 then
        group.lastFocus = m.itemGrid
    else
        group.lastFocus = m.tvGuide
    end if
    if isValid(m.tvGuide)
        m.tvGuide.lastFocus.setFocus(true)
        group.lastFocus = m.tvGuide.lastFocus
        if isChainValid(m.tvGuide, "lastFocus.hasFocus")
            m.tvGuide.lastFocus.hasFocus = m.tvGuide.lastFocus.hasFocus
        end if
    end if
end sub

sub showTVGuide()
    if not isValid(m.tvGuide)
        m.tvGuide = createObject("roSGNode", "Schedule")
        m.top.signalBeacon("EPGLaunchInitiate") ' Required Roku Performance monitoring
        m.tvGuide.observeField("watchChannel", "onChannelSelected")
        m.tvGuide.observeField("focusedChannel", "onChannelFocused")
    end if
    m.tvGuide.filter = m.filter
    m.tvGuide.searchTerm = m.voiceBox.text
    m.top.insertChild(m.tvGuide, 1)
    m.scheduleGrid = m.top.findNode("scheduleGrid")
    m.tvGuide.lastFocus.setFocus(true)
    group = m.global.sceneManager.callFunc("getActiveScene")
    group.lastFocus = m.tvGuide.lastFocus
    m.alpha.visible = false
    m.tvGuide.opacity = 1
    m.itemGrid.opacity = 0
end sub

sub onChannelSelected(msg)
    node = msg.getRoSGNode()
    m.top.lastFocus = lastFocusedChild(node)
    if node.watchChannel <> invalid
        ' Clone the node when it's reused/update in the TimeGrid it doesn't automatically start playing
        m.top.selectedItem = node.watchChannel.clone(false)
        ' Make sure to set watchChanel to invalid in case the user hits back and then selects
        ' the same channel on the guide (without moving away from the currently selected channel)
        m.tvGuide.watchChannel = invalid
    end if
end sub

sub onChannelFocused(msg)
    node = msg.getRoSGNode()
    m.channelFocused = node.focusedChannel
end sub

'Returns Focused Item
function getItemFocused()
    if m.itemGrid.isinFocusChain() and isValid(m.itemGrid.itemFocused)
        return m.itemGrid.content.getChild(m.itemGrid.itemFocused)
    else if isValid(m.scheduleGrid) and m.scheduleGrid.isinFocusChain() and isValid(m.scheduleGrid.itemFocused)
        return m.scheduleGrid.content.getChild(m.scheduleGrid.itemFocused)
    end if
    return invalid
end function

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        return false
    end if
    if m.itemGrid.opacity = 1
        topGrp = m.itemGrid
    else
        topGrp = m.scheduleGrid
    end if
    searchGrp = m.top.findNode("voiceBox")
    if key = "left" and searchGrp.isinFocusChain()
        topGrp.setFocus(true)
        searchGrp.setFocus(false)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = topGrp
    end if
    if key = "options"
        if m.options.visible = true
            m.options.visible = false
            m.top.removeChild(m.options)
            optionsClosed()
        else
            channelSelected = m.channelFocused
            itemSelected = m.selectedFavoriteItem
            if itemSelected <> invalid
                m.options.selectedFavoriteItem = itemSelected
            end if
            if channelSelected <> invalid
                if channelSelected.type = "TvChannel"
                    m.options.selectedFavoriteItem = channelSelected
                end if
            end if
            m.options.visible = true
            m.top.appendChild(m.options)
            m.options.setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.options
        end if
        return true
    else if key = "back"
        if m.options.visible = true
            m.options.visible = false
            optionsClosed()
            return true
        else
            m.global.sceneManager.callfunc("popScene")
            m.loadItemsTask.control = "stop"
            return true
        end if
    else if key = "OK"
        markupGrid = m.top.findNode("itemGrid")
        itemToPlay = getItemFocused()
        if itemToPlay <> invalid and itemToPlay.type = "Photo"
            ' Spawn photo player task
            photoPlayer = CreateObject("roSgNode", "PhotoDetails")
            photoPlayer.itemsNode = markupGrid
            photoPlayer.itemIndex = markupGrid.itemFocused
            m.global.sceneManager.callfunc("pushScene", photoPlayer)
            return true
        end if
    else if key = "play"
        itemToPlay = getItemFocused()
        if itemToPlay <> invalid
            m.top.quickPlayNode = itemToPlay
            return true
        end if
    else if key = "left" and topGrp.isinFocusChain() and m.alpha.visible
        m.top.alphaActive = true
        topGrp.setFocus(false)
        m.alphaMenu.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.alphaMenu
        return true
    else if key = "right" and m.alpha.isinFocusChain()
        m.top.alphaActive = false
        m.alphaMenu.setFocus(false)
        topGrp.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = topGrp
        return true
    end if
    return false
end function
'//# sourceMappingURL=./LiveTVLibraryView.brs.map