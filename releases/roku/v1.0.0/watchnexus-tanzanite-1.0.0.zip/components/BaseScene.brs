'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/KeyCode.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.top.backgroundURI = ""
    m.spinner = m.top.findNode("spinner")
end sub

' Triggered when the isLoading boolean component field is changed
sub isLoadingChanged()
    m.spinner.visible = m.top.isLoading
end sub

sub setBackgroundImage(backgroundURI as string)
    imageBackground = m.top.findNode("imageBackground")
    if not isValid(imageBackground) then
        return
    end if
    imageBackground.uri = backgroundURI
end sub

sub onJumpToChange()
    if not isValidAndNotEmpty(m.top.jumpTo) then
        return
    end if
    if not isValid(m.top.jumpTo.selectiontype) then
        return
    end if
    m.global.jumpTo = m.top.jumpTo
    m.top.jumpTo = {}
end sub

' Triggered when the disableRemote boolean component field is changed
sub disableRemoteChanged()
    if m.top.disableRemote
        dialog = createObject("roSGNode", "ProgressDialog")
        dialog.id = "invisibiledialog"
        dialog.visible = false
        dialog.opacity = 0
        m.top.dialog = dialog
    else
        if isValid(m.top.dialog)
            m.top.dialog.close = true
        end if
    end if
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        return false
    end if
    if key = "back"
        m.global.sceneManager.callFunc("popScene")
        return true
    end if
    if key = "options"
        group = m.global.sceneManager.callFunc("getActiveScene")
        if isValid(group) and isValid(group.optionsAvailable) and group.optionsAvailable
            group.lastFocus = group.focusedChild
            ' User opened the menu while on the user avatar
            scene = m.top.getScene()
            if isValid(scene)
                overhang = scene.findNode("overhang")
                if isValid(overhang)
                    overlayCurrentUserSelection = overhang.findNode("overlayCurrentUserSelection")
                    if overlayCurrentUserSelection.visible
                        group.lastFocus = overhang
                    end if
                end if
            end if
            ' Home uses the user avatar to access options
            if group.isSubType("Home") then
                return true
            end if
            panel = group.findNode("options")
            panel.visible = true
            panel.findNode("panelList").setFocus(true)
        end if
        return true
    end if
    if key = "replay"
        focusAudioMiniPlayer()
        return true
    end if
    return false
end function
'//# sourceMappingURL=./BaseScene.brs.map