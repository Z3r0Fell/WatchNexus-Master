'import "pkg:/source/enums/AnimationControl.bs"
'import "pkg:/source/enums/AnimationState.bs"
'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/ItemType.bs"
'import "pkg:/source/enums/KeyCode.bs"
'import "pkg:/source/enums/TaskControl.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.top.filter = "All"
    m.originalOptions = {}
    m.submitButton = m.top.findNode("submitButton")
    m.submitButton.background = "#c8fafa"
    m.submitButton.color = "#101010"
    m.submitButton.focusBackground = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    m.submitButton.focusColor = "#ffffff"
    overlay = m.top.findNode("overlay")
    overlay.color = "#101010"
    background = m.top.findNode("background")
    background.color = "#101420"
    headerText = m.top.findNode("headerText")
    headerText.font.size = 45
    headerBorder = m.top.findNode("headerBorder")
    headerBorder.color = "#c8fafa"
    m.filterMenu = m.top.findNode("filterMenu")
    m.filterMenu.focusBitmapBlendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    m.filterMenu.focusFootprintBlendColor = "#ff9a99"
    m.filterMenu.focusedColor = "#ffffff"
    filterOptionsBackdrop = m.top.findNode("filterOptionsBackdrop")
    filterOptionsBackdrop.color = "#aaaaaa"
    m.filterOptionsMenu = m.top.findNode("filterOptionsMenu")
    m.filterOptionsMenu.focusBitmapBlendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    m.filterOptionsMenu.focusFootprintBlendColor = "#ff9a99"
    m.filterOptionsMenu.focusedColor = "#ffffff"
    m.filterMenu.observeField("itemFocused", "onFilterFocusChange")
    m.filterNames = []
    ' Animation
    m.showChecklistAnimation = m.top.findNode("showChecklistAnimation")
    m.hideChecklistAnimation = m.top.findNode("hideChecklistAnimation")
end sub

sub showChecklist()
    if m.filterOptionsMenu.opacity = 0
        if m.showChecklistAnimation.state = "stopped"
            m.showChecklistAnimation.control = "start"
        end if
    end if
end sub

sub hideChecklist()
    if m.filterOptionsMenu.opacity = 1
        if m.hideChecklistAnimation.state = "stopped"
            m.hideChecklistAnimation.control = "start"
        end if
    end if
end sub

sub onFilterFocusChange()
    if not isFilterMenuDataValid()
        hideChecklist()
        return
    end if
    if m.filterMenu.content.getChild(m.filterMenu.itemFocused).getChildCount() > 0
        showChecklist()
    else
        hideChecklist()
    end if
    m.filterOptionsMenu.content = m.filterMenu.content.getChild(m.filterMenu.itemFocused)
    if isValid(m.filterMenu.content.getChild(m.filterMenu.itemFocused).checkedState)
        m.filterOptionsMenu.checkedState = m.filterMenu.content.getChild(m.filterMenu.itemFocused).checkedState
    else
        m.filterOptionsMenu.checkedState = []
    end if
end sub

' Check if data for Filter Menu is valid
function isFilterMenuDataValid() as boolean
    if not isValid(m.filterMenu) or not isValid(m.filterMenu.content) or not isValid(m.filterMenu.itemFocused)
        return false
    end if
    if not isValid(m.filterMenu.content.getChild(m.filterMenu.itemFocused))
        return false
    end if
    return true
end function

sub optionsSet()
    ' Filter Tab
    if isValid(m.top.options.filter)
        filterContent = CreateObject("roSGNode", "ContentNode")
        index = 0
        m.selectedFilterIndex = 0
        for each filterItem in m.top.options.filter
            entry = filterContent.CreateChild("OptionNode")
            entry.title = filterItem.Title
            entry.name = filterItem.Name
            entry.delimiter = filterItem.Delimiter
            if isValid(filterItem.options)
                for each filterItemOption in filterItem.options
                    entryOption = entry.CreateChild("ContentNode")
                    entryOption.title = toString(filterItemOption)
                end for
                entry.checkedState = filterItem.checkedState
            end if
            m.filterNames.push(filterItem.Name)
            if isValid(filterItem.selected) and filterItem.selected
                m.selectedFilterIndex = index
            end if
            index = index + 1
        end for
        m.filterMenu.content = filterContent
        m.filterMenu.checkedItem = m.selectedFilterIndex
    else
        filterContent = CreateObject("roSGNode", "ContentNode")
        entry = filterContent.CreateChild("ContentNode")
        entry.title = tr("All")
        m.filterNames.push("All")
        m.filterMenu.content = filterContent
        m.filterMenu.checkedItem = 0
    end if
    m.originalOptions = {
        filterData: m.top.options
        filter: m.top.filter
        filterOptions: m.top.filterOptions
    }
    m.filterMenu.jumpToItem = 0
    group = m.global.sceneManager.callFunc("getActiveScene")
    group.lastFocus = m.filterMenu
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    ' User pressed OK from inside the filter's options
    if key = "OK"
        if m.filterOptionsMenu.isInFocusChain()
            selectedOptions = []
            for i = 0 to m.filterOptionsMenu.checkedState.count() - 1
                if m.filterOptionsMenu.checkedState[i]
                    selectedValue = toString(m.filterOptionsMenu.content.getChild(i).title)
                    selectedValue = selectedValue.replace("Photo Album", "photoalbum")
                    selectedOptions.push(selectedValue)
                end if
            end for
            if selectedOptions.Count() > 0
                m.filterMenu.checkedItem = m.filterMenu.itemFocused
                m.selectedFilterIndex = m.filterMenu.itemFocused
                m.top.filter = m.filterMenu.content.getChild(m.filterMenu.itemFocused).Name
                newFilter = {}
                newFilter[m.top.filter] = selectedOptions.join(m.filterMenu.content.getChild(m.filterMenu.itemFocused).delimiter)
                m.top.filterOptions = newFilter
            else
                m.filterMenu.checkedItem = 0
                m.selectedFilterIndex = 0
                m.top.filter = m.filterNames[0]
                m.top.filterOptions = {}
            end if
            m.filterMenu.content.getChild(m.filterMenu.itemFocused).checkedState = m.filterOptionsMenu.checkedState
            return true
        end if
    end if
    if not press then
        return false
    end if
    if key = "right"
        if not m.filterMenu.isInFocusChain() then
            return false
        end if
        ' Handle Filter screen
        if not isFilterMenuDataValid() then
            return false
        end if
        ' If filter has no options, select it
        if m.filterMenu.content.getChild(m.filterMenu.itemFocused).getChildCount() = 0
            return true
        end if
        ' Selected filter has options, move cursor to it
        m.filterOptionsMenu.setFocus(true)
        m.filterMenu.setFocus(false)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.filterOptionsMenu
        return true
    end if
    if key = "down"
        if m.filterMenu.isInFocusChain()
            m.submitButton.focus = true
            m.submitButton.setfocus(true)
            return true
        end if
    end if
    if key = "up"
        if m.submitButton.isInFocusChain()
            m.submitButton.focus = false
            m.filterMenu.setfocus(true)
            return true
        end if
    end if
    if key = "back"
        if isValidAndNotEmpty(m.originalOptions)
            m.top.filter = m.originalOptions.LookupCI("filter")
            m.top.filterOptions = m.originalOptions.LookupCI("filterOptions")
            m.top.options = m.originalOptions.LookupCI("filterData")
        end if
        m.top.visible = false
        m.submitButton.focus = false
        m.filterMenu.jumpToItem = 0
        return true
    end if
    if key = "left"
        ' User wants to escape filter options
        if m.filterOptionsMenu.isInFocusChain()
            m.filterOptionsMenu.setFocus(false)
            m.filterMenu.setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.filterMenu
            return true
        end if
    end if
    if key = "OK"
        if m.submitButton.isInFocusChain()
            m.originalOptions = {
                filterData: m.top.options
                filter: m.top.filter
                filterOptions: m.top.filterOptions
            }
            m.top.visible = false
            m.submitButton.focus = false
            m.filterMenu.jumpToItem = 0
        end if
        if m.filterMenu.isInFocusChain()
            ' Handle Filter screen
            if not isFilterMenuDataValid() then
                return false
            end if
            ' If filter has no options, select it
            if m.filterMenu.content.getChild(m.filterMenu.itemFocused).getChildCount() = 0
                m.filterMenu.checkedItem = m.filterMenu.itemFocused
                m.selectedFilterIndex = m.filterMenu.itemFocused
                m.top.filter = m.filterNames[m.selectedFilterIndex]
                m.top.filterOptions = {}
                return true
            end if
            ' Selected filter has options, move cursor to it
            m.filterOptionsMenu.setFocus(true)
            m.filterMenu.setFocus(false)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.filterOptionsMenu
            return true
        end if
        return true
    end if
    return false
end function
'//# sourceMappingURL=./LibraryFilterDialog.brs.map