'import "pkg:/source/utils/config.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.itemPoster = m.top.findNode("itemPoster")
    m.itemIcon = m.top.findNode("itemIcon")
    m.posterText = m.top.findNode("posterText")
    m.itemText = m.top.findNode("itemText")
    m.backdrop = m.top.findNode("backdrop")
    m.itemPoster.observeField("loadStatus", "onPosterLoadStatusChanged")
    m.unplayedCount = m.top.findNode("unplayedCount")
    m.unplayedEpisodeCount = m.top.findNode("unplayedEpisodeCount")
    m.playedIndicator = m.top.findNode("playedIndicator")
    m.checkmark = m.top.findNode("checkmark")
    m.checkmark.width = 90
    m.checkmark.height = 60
    m.itemText.translation = [
        0
        m.itemPoster.height + 7
    ]
    m.itemText.visible = m.gridTitles = "showalways"
    ' Add some padding space when Item Titles are always showing
    if m.itemText.visible then
        m.itemText.maxWidth = 250
    end if
    ' grab data from ItemGrid node
    m.itemGrid = m.top.GetParent().GetParent() 'Parent is MarkupGrid and it's parent is the ItemGrid
    if isValid(m.itemGrid)
        if isValid(m.itemGrid.imageDisplayMode)
            m.itemPoster.loadDisplayMode = m.itemGrid.imageDisplayMode
        end if
        if isValid(m.itemGrid.gridTitles)
            m.gridTitles = m.itemGrid.gridTitles
        end if
    end if
end sub

sub itemContentChanged()
    m.backdrop.blendColor = "#00a4db" ' set default in case global var is invalid
    localGlobal = m.global
    if isValid(localGlobal) and isValid(localGlobal.constants) and isValid(localGlobal.constants.poster_bg_pallet)
        posterBackgrounds = localGlobal.constants.poster_bg_pallet
        m.backdrop.blendColor = posterBackgrounds[rnd(posterBackgrounds.count()) - 1]
    end if
    itemData = m.top.itemContent
    if itemData = invalid then
        return
    end if
    if itemData.type = "Movie"
        if isValid(itemData.json) and isValid(itemData.json.UserData) and isValid(itemData.json.UserData.Played) and itemData.json.UserData.Played
            m.playedIndicator.visible = true
        end if
        m.itemPoster.uri = itemData.PosterUrl
        m.itemIcon.uri = itemData.iconUrl
        m.itemText.text = itemData.Title
    else if itemData.type = "Series"
        if isValid(localGlobal) and isValid(localGlobal.session) and isValid(localGlobal.session.user) and isValid(localGlobal.session.user.settings)
            if localGlobal.session.user.settings["ui.tvshows.disableUnwatchedEpisodeCount"] = false
                if isValid(itemData.json) and isValid(itemData.json.UserData) and isValid(itemData.json.UserData.UnplayedItemCount)
                    if itemData.json.UserData.UnplayedItemCount > 0
                        m.unplayedCount.visible = true
                        m.unplayedEpisodeCount.text = itemData.json.UserData.UnplayedItemCount
                    else
                        m.unplayedCount.visible = false
                        m.unplayedEpisodeCount.text = ""
                    end if
                end if
            end if
        end if
        if isValid(itemData.json) and isValid(itemData.json.UserData) and isValid(itemData.json.UserData.Played) and itemData.json.UserData.Played = true
            m.playedIndicator.visible = true
        end if
        m.itemPoster.uri = itemData.PosterUrl
        m.itemIcon.uri = itemData.iconUrl
        m.itemText.text = itemData.Title
    else if itemData.type = "Boxset"
        m.itemPoster.uri = itemData.PosterUrl
        m.itemIcon.uri = itemData.iconUrl
        m.itemText.text = itemData.Title
    else if itemData.type = "TvChannel"
        m.itemPoster.uri = itemData.PosterUrl
        m.itemIcon.uri = itemData.iconUrl
        m.itemText.text = itemData.Title
    else if itemData.type = "Folder"
        m.itemPoster.uri = itemData.PosterUrl
        'm.itemIcon.uri = itemData.iconUrl
        m.itemText.text = itemData.Title
        m.itemPoster.loadDisplayMode = m.itemGrid.imageDisplayMode
    else if itemData.type = "Video"
        m.itemPoster.uri = itemData.PosterUrl
        m.itemIcon.uri = itemData.iconUrl
        m.itemText.text = itemData.Title
    else if itemData.type = "Playlist"
        m.itemPoster.uri = itemData.PosterUrl
        m.itemIcon.uri = itemData.iconUrl
        m.itemText.text = itemData.Title
    else if itemData.type = "Photo"
        m.itemPoster.uri = itemData.PosterUrl
        m.itemIcon.uri = itemData.iconUrl
        m.itemText.text = itemData.Title
    else if itemData.type = "Episode"
        m.itemPoster.uri = itemData.PosterUrl
        m.itemIcon.uri = itemData.iconUrl
        if isValid(itemData.json) and isValid(itemData.json.SeriesName)
            m.itemText.text = itemData.json.SeriesName + " - " + itemData.Title
        else
            m.itemText.text = itemData.Title
        end if
        if not isValid(m.topParent)
            m.topParent = m.top.GetParent().GetParent()
        end if
        ' Adjust to wide posters for "View All Next Up"
        if m.topParent.overhangTitle = tr("View All Next Up")
            m.itemPoster.height = 300
            m.itemPoster.width = 400
            m.itemPoster.loadDisplayMode = "scaleToFit"
            m.backdrop.height = 300
            m.backdrop.width = 400
            m.backdrop.loadDisplayMode = "scaleToFit"
            m.itemText.translation = [
                0
                m.itemPoster.height + 7
            ]
            m.itemText.maxWidth = 400
        end if
    else if itemData.type = "MusicArtist"
        m.itemPoster.uri = itemData.PosterUrl
        m.itemText.text = itemData.Title
        m.itemPoster.height = 290
        m.itemPoster.width = 290
        m.itemText.translation = [
            0
            m.itemPoster.height + 7
        ]
        m.backdrop.height = 290
        m.backdrop.width = 290
        m.posterText.height = 200
        m.posterText.width = 280
    else if isValid(itemData.json.type) and itemData.json.type = "MusicAlbum"
        m.itemPoster.uri = itemData.PosterUrl
        m.itemText.text = itemData.Title
        m.itemPoster.height = 290
        m.itemPoster.width = 290
        m.itemText.translation = [
            0
            m.itemPoster.height + 7
        ]
        m.backdrop.height = 290
        m.backdrop.width = 290
        m.posterText.height = 200
        m.posterText.width = 280
    else
        print ("Unhandled Grid Item Type " + bslib_toString(itemData.type))
    end if
    'If Poster not loaded, ensure "blue box" is shown until loaded
    if m.itemPoster.loadStatus <> "ready"
        m.backdrop.visible = true
        m.posterText.visible = true
    end if
    m.posterText.text = m.itemText.text
end sub

'
'Display or hide title Visibility on focus change
sub focusChanged()
    if m.top.itemHasFocus = true
        m.itemText.repeatCount = -1
    else
        m.itemText.repeatCount = 0
    end if
    if m.gridTitles = "showonhover"
        m.itemText.visible = m.top.itemHasFocus
    end if
end sub

'Hide backdrop and text when poster loaded
sub onPosterLoadStatusChanged()
    if m.itemPoster.loadStatus = "ready"
        m.backdrop.visible = false
        m.posterText.visible = false
    end if
end sub
'//# sourceMappingURL=./GridItem.brs.map