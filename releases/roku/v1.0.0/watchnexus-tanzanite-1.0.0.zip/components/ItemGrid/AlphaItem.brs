'import "pkg:/source/utils/misc.bs"
'import "pkg:/source/enums/ColorPalette.bs"

sub init()
    m.letterText = m.top.findNode("letterText")
    m.letterText.color = "#ffffff"
    m.letterText.font.size = 25
end sub

sub showContent()
    m.letterText.text = m.top.itemContent.title
end sub
'//# sourceMappingURL=./AlphaItem.brs.map