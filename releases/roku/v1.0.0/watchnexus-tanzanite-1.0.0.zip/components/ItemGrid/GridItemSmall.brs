'import "pkg:/source/enums/ImageLayout.bs"
'import "pkg:/source/enums/PosterLoadStatus.bs"
'import "pkg:/source/utils/config.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.itemPoster = m.top.findNode("itemPoster")
    m.itemIcon = m.top.findNode("itemIcon")
    m.posterText = m.top.findNode("posterText")
    m.title = m.top.findNode("title")
    m.posterText.font.size = 30
    m.title.font.size = 25
    m.backdrop = m.top.findNode("backdrop")
    m.playedIndicator = m.top.findNode("playedIndicator")
    m.itemPoster.observeField("loadStatus", "onPosterLoadStatusChanged")
    'Parent is MarkupGrid and it's parent is the ItemGrid
    m.topParent = m.top.GetParent().GetParent()
    if not isValid(m.topParent.showItemTitles)
        m.topParent = m.topParent.GetParent().GetParent()
    end if
    m.title.visible = false
    'Get the imageDisplayMode for these grid items
    if m.topParent.imageDisplayMode <> invalid
        m.itemPoster.loadDisplayMode = m.topParent.imageDisplayMode
    end if
end sub

sub onHeightChanged()
    calculatedHeight = m.top.height
    showItemTitles = chainLookupReturn(m.topParent, "showItemTitles", "showonhover")
    if not isStringEqual(showItemTitles, "hidealways")
        calculatedHeight -= 40
    end if
    m.backdrop.height = calculatedHeight
    m.itemPoster.height = calculatedHeight
    m.posterText.height = calculatedHeight
    m.title.translation = [
        0
        calculatedHeight + 25
    ]
end sub

sub onWidthChanged()
    m.backdrop.width = m.top.width
    m.itemPoster.width = m.top.width
    m.posterText.width = m.top.width
    m.title.maxWidth = m.top.width
    m.itemIcon.translation = [
        m.top.width
        10
    ]
    m.playedIndicator.translation = [
        m.top.width - m.playedIndicator.width
        22
    ]
end sub

sub itemContentChanged()
    m.backdrop.blendColor = "#101010"
    m.title.visible = false
    if isValid(m.topParent.showItemTitles)
        if LCase(m.topParent.showItemTitles) = "showalways"
            m.title.visible = true
        end if
    end if
    itemData = m.top.itemContent
    if not isValid(itemData) then
        return
    end if
    showWatchedCheckmark = true
    if isChainValid(itemData, "json.passedData.libraryID")
        showWatchedCheckmark = chainLookupReturn(m.global.session, ("user.settings." + bslib_toString(itemData.json.passedData.libraryID) + "-showWatchedCheckmark"), true)
    end if
    m.playedIndicator.data = {
        showWatchedCheckmark: showWatchedCheckmark
        played: chainLookupReturn(itemData, "json.UserData.Played", false)
        unplayedCount: chainLookupReturn(itemData, "json.UserData.UnplayedItemCount", 0)
    }
    m.itemPoster.uri = getPosterURL(itemData)
    if isValidAndNotEmpty(itemData.LookupCI("fullNameWithShowTitle"))
        m.posterText.text = itemData.LookupCI("fullNameWithShowTitle")
    else
        m.posterText.text = itemData.title
    end if
    m.title.text = m.posterText.text
    'If Poster not loaded, ensure "blue box" is shown until loaded
    if m.itemPoster.loadStatus <> "ready"
        m.backdrop.visible = true
        m.posterText.visible = true
    end if
end sub

function getPosterURL(itemData) as string
    posterURL = itemData.PosterUrl
    posterOrientation = chainLookupReturn(m.global, "session.user.settings.libraryPosterOrientation", "default")
    ' If user has not set a library level setting, check the user level setting
    if isChainValid(itemData, "json.passedData.libraryID")
        if isChainValid(m.global.session, ("user.settings." + bslib_toString(itemData.json.passedData.libraryID) + "-useLandscapeImages"))
            useLandscapeImages = chainLookupReturn(m.global.session, ("user.settings." + bslib_toString(itemData.json.passedData.libraryID) + "-useLandscapeImages"), false)
            if useLandscapeImages then
                posterOrientation = "landscape"
            else
                posterOrientation = "default"
            end if
        end if
    end if
    if inArray([
        "default"
        "portrait"
    ], posterOrientation)
        posterURL = itemData.PosterUrl
    else if isValidAndNotEmpty(itemData.landscapePosterURL)
        posterURL = itemData.landscapePosterURL
    else if isValidAndNotEmpty(itemData.backdropURL)
        posterURL = itemData.backdropURL
    end if
    ' Adjust image dimensions as needed
    posterURL = posterURL.replace("maxHeight=720", ("maxHeight=" + bslib_toString(m.itemPoster.height)))
    posterURL = posterURL.replace("maxHeight=331", ("maxHeight=" + bslib_toString(m.itemPoster.height)))
    posterURL = posterURL.replace("maxWidth=1280", ("maxWidth=" + bslib_toString(m.itemPoster.width)))
    posterURL = posterURL.replace("maxWidth=464", ("maxWidth=" + bslib_toString(m.itemPoster.width)))
    return posterURL
end function

sub focusChanged()
    if m.top.itemHasFocus = true
        m.title.repeatCount = -1
    else
        m.title.repeatCount = 0
    end if
    if isValid(m.topParent.showItemTitles)
        if LCase(m.topParent.showItemTitles) = "showonhover"
            m.title.visible = m.top.itemHasFocus
        end if
    end if
end sub

'Hide backdrop and text when poster loaded
sub onPosterLoadStatusChanged()
    if isStringEqual(m.itemPoster.loadStatus, "failed")
        ' Image failed to load, try to fall back to default poster image
        if not isStringEqual(m.itemPoster.uri, m.top.itemContent.PosterUrl)
            m.itemPoster.uri = m.top.itemContent.PosterUrl
            return
        end if
        ' No image loaded, ensure text is displayed
        m.backdrop.visible = true
        m.posterText.visible = true
    end if
    if isStringEqual(m.itemPoster.loadStatus, "ready")
        m.backdrop.visible = false
        m.posterText.visible = false
    end if
end sub
'//# sourceMappingURL=./GridItemSmall.brs.map