'import "pkg:/source/enums/AnimationControl.bs"
'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/utils/config.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.titleGroup = m.top.findNode("title_group")
    m.itemPoster = m.top.findNode("itemPoster")
    m.posterText = m.top.findNode("posterText")
    m.posterText.font.size = 26
    m.subText = m.top.findNode("subText")
    m.subText.font.size = 23
    m.backdrop = m.top.findNode("backdrop")
    m.itemProgress = m.top.findNode("progress")
    m.itemProgress.color = "#6867ff"
    m.itemProgressBackground = m.top.findNode("progressBackground")
    m.showProgressBarAnimation = m.top.findNode("showProgressBar")
    m.showProgressBarField = m.top.findNode("showProgressBarField")
    m.itemPoster.observeField("loadStatus", "onPosterLoadStatusChanged")
    'Parent is MarkupGrid and it's parent is the ItemGrid
    m.topParent = m.top.GetParent().GetParent()
    'Get the imageDisplayMode for these grid items
    if m.topParent.imageDisplayMode <> invalid
        m.itemPoster.loadDisplayMode = m.topParent.imageDisplayMode
    end if
    m.gridTitles = m.global.session.user.settings["itemgrid.gridTitles"]
end sub

sub onHeightChanged()
    calculatedHeight = m.top.height
    showItemTitles = chainLookupReturn(m.topParent, "showItemTitles", "showonhover")
    if not isStringEqual(showItemTitles, "hidealways")
        calculatedHeight -= 65
    end if
    m.backdrop.height = calculatedHeight
    m.itemPoster.height = calculatedHeight
    m.titleGroup.translation = [
        0
        calculatedHeight + 20
    ]
end sub

sub onWidthChanged()
    m.backdrop.width = m.top.width
    m.itemPoster.width = m.top.width
    m.posterText.maxwidth = m.top.width
    m.subText.maxWidth = m.top.width
end sub

sub drawProgressBar(itemData)
    m.itemProgressBackground.width = m.itemPoster.width
    m.itemProgressBackground.visible = true
    m.showProgressBarField.keyValue = [
        0
        m.itemPoster.width * (itemData.json.userdata.PlayedPercentage / 100)
    ]
    m.showProgressBarAnimation.control = "start"
end sub

sub itemContentChanged()
    m.backdrop.blendColor = "#101010"
    itemData = m.top.itemContent
    if not isValid(itemData) then
        return
    end if
    if LCase(itemData.type) = "musicalbum"
        m.backdrop.uri = "pkg:/images/icons/album.png"
    else if LCase(itemData.type) = "musicartist"
        m.backdrop.uri = "pkg:/images/missingArtist.png"
    else if LCase(itemData.json.type) = "musicgenre"
        m.backdrop.uri = "pkg:/images/icons/musicFolder.png"
    end if
    if isChainValid(itemData, "json.userdata.PlayedPercentage")
        if itemData.json.userdata.PlayedPercentage > 0
            drawProgressBar(itemData)
        end if
    end if
    m.itemPoster.uri = itemData.PosterUrl
    m.posterText.text = itemData.title
    m.subText.text = itemData.json.AlbumArtist
    'If Poster not loaded, ensure "blue box" is shown until loaded
    if m.itemPoster.loadStatus <> "ready"
        m.backdrop.visible = true
    end if
    if m.top.itemHasFocus then
        focusChanged()
    end if
end sub

'Display or hide title Visibility on focus change
sub focusChanged()
    if m.top.itemHasFocus = true
        m.posterText.repeatCount = -1
    else
        m.posterText.repeatCount = 0
    end if
end sub

'Hide backdrop and text when poster loaded
sub onPosterLoadStatusChanged()
    if m.itemPoster.loadStatus = "ready"
        m.backdrop.visible = false
    end if
end sub
'//# sourceMappingURL=./AudioBookGridItem.brs.map