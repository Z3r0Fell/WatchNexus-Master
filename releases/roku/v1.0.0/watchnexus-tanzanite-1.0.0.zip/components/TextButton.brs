'import "pkg:/source/enums/ColorPalette.bs"

sub init()
    m.top.iconSide = "left"
    m.buttonBackground = m.top.findNode("buttonBackground")
    m.buttonIcon = m.top.findNode("buttonIcon")
    m.buttonText = m.top.findNode("buttonText")
    m.top.observeField("background", "onBackgroundChanged")
    m.top.observeField("textColor", "onTextColorChanged")
    m.top.observeField("icon", "onIconChanged")
    m.top.observeField("iconSide", "onIconSideChanged")
    m.top.observeField("fontSize", "onFontSizeChanged")
    m.top.observeField("text", "onTextChanged")
    m.top.observeField("height", "onHeightChanged")
    m.top.observeField("width", "onWidthChanged")
    m.top.observeField("padding", "onPaddingChanged")
    m.top.observeField("focus", "onFocusChanged")
    m.top.observeField("disabled", "onDisabledChanged")
    m.top.observeField("iconBlendColor", "onIconBlendColorChanged")
end sub

sub onTextColorChanged()
    m.top.unobserveField("textColor")
    m.buttonText.color = m.top.textColor
end sub

sub onFontSizeChanged()
    m.top.unobserveField("fontSize")
    m.buttonText.font.size = m.top.fontSize
    setIconSize()
end sub

sub onIconSideChanged()
    m.top.unobserveField("iconSide")
    setIconSize()
end sub

sub onFocusChanged()
    if m.top.disabled
        if m.top.focus then
            m.buttonBackground.blendColor = "#101010"
        else
            m.buttonBackground.blendColor = "#777777"
        end if
        if m.top.focus then
            m.buttonText.color = "#777777"
        else
            m.buttonText.color = m.top.textColor
        end if
        return
    end if
    if m.top.focus
        m.buttonText.color = m.top.focusTextColor
        m.buttonBackground.blendColor = m.top.focusBackground
        if m.top.focusIcon <> "" then
            m.buttonIcon.uri = m.top.focusIcon
        else
            m.buttonIcon.uri = m.top.icon
        end if
    else
        m.buttonText.color = m.top.textColor
        m.buttonBackground.blendColor = m.top.background
        m.buttonIcon.uri = m.top.icon
    end if
end sub

sub onDisabledChanged()
    if m.top.disabled then
        m.buttonBackground.blendColor = "#777777"
    else
        m.buttonBackground.blendColor = m.top.background
    end if
    onFocusChanged()
end sub

sub onBackgroundChanged()
    m.top.unobserveField("background")
    m.buttonBackground.blendColor = m.top.background
end sub

sub onIconChanged()
    m.top.unobserveField("icon")
    m.buttonIcon.uri = m.top.icon
end sub

sub onIconBlendColorChanged()
    m.buttonIcon.blendcolor = m.top.iconBlendColor
end sub

sub onTextChanged()
    m.buttonText.text = m.top.text
end sub

sub setIconSize()
    height = m.buttonBackground.height
    width = m.buttonBackground.width
    if height > 0 and width > 0
        ' TODO: Use smallest number between them
        m.buttonIcon.height = m.top.height
        m.buttonText.height = m.top.height
        if m.top.padding > 0
            m.buttonIcon.height = m.buttonIcon.height - m.top.padding
        end if
        m.buttonIcon.width = m.buttonIcon.height
        ' Set Icon translation
        if LCase(m.top.iconSide) = "right"
            m.buttonIcon.translation = [
                m.buttonBackground.width - m.top.padding - m.buttonIcon.width
                ((height - m.buttonIcon.height) / 2)
            ]
            m.buttonText.translation = [
                m.top.padding
                0
            ]
        else
            m.buttonIcon.translation = [
                m.top.padding
                ((height - m.buttonIcon.height) / 2)
            ]
            m.buttonText.translation = [
                m.top.padding + m.buttonIcon.width + 20
                0
            ]
        end if
        ' Set text max width
        m.buttonText.maxWidth = m.top.width - m.top.padding - m.buttonIcon.width - 40
    end if
end sub

sub onHeightChanged()
    m.top.unobserveField("height")
    m.buttonBackground.height = m.top.height
    setIconSize()
end sub

sub onWidthChanged()
    m.top.unobserveField("width")
    m.buttonBackground.width = m.top.width
    setIconSize()
end sub

sub onPaddingChanged()
    m.top.unobserveField("padding")
    setIconSize()
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        return false
    end if
    if key = "right" and m.top.focus
        m.top.escape = "right"
    end if
    if key = "left" and m.top.focus
        m.top.escape = "left"
    end if
    return false
end function
'//# sourceMappingURL=./TextButton.brs.map