'import "pkg:/source/enums/AnimationControl.bs"
'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/KeyCode.bs"
'import "pkg:/source/enums/PlaybackMethod.bs"
'import "pkg:/source/enums/String.bs"
'import "pkg:/source/enums/SubtitleSelection.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.buttons = m.top.findNode("buttons")
    m.buttons.buttons = [
        tr("Subtitles")
        tr("Audio")
        tr("Video")
        tr("Options")
    ]
    m.buttons.selectedIndex = 0
    m.buttons.setFocus(true)
    m.selectedItem = 0
    m.selectedAudioIndex = 0
    m.selectedVideoIndex = 0
    m.selectedSubtitleIndex = -1
    m.optionMenu = m.top.findNode("optionMenu")
    m.optionMenu.focusBitmapBlendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    m.optionMenu.focusedColor = "#ffffff"
    m.menus = [
        m.top.findNode("subtitleMenu")
        m.top.findNode("audioMenu")
        m.top.findNode("videoMenu")
        m.optionMenu
    ]
    m.videoNames = []
    m.audioNames = []
    m.top.findNode("videoMenu").focusBitmapBlendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    m.top.findNode("videoMenu").focusedColor = "#ffffff"
    m.top.findNode("audioMenu").focusBitmapBlendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    m.top.findNode("audioMenu").focusedColor = "#ffffff"
    m.top.findNode("subtitleMenu").focusBitmapBlendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    m.top.findNode("subtitleMenu").focusedColor = "#ffffff"
    ' Animation
    m.fadeAnim = m.top.findNode("fadeAnim")
    m.fadeOutAnimOpacity = m.top.findNode("outOpacity")
    m.fadeInAnimOpacity = m.top.findNode("inOpacity")
    m.buttons.observeField("focusedIndex", "buttonFocusChanged")
    m.buttons.focusedIndex = m.selectedItem
end sub

sub optionsSet()
    forceTranscodeSetting = chainLookupReturn(m.global.session, "user.settings.`playback.media.forceTranscode`", "playNormally")
    if not isStringEqual("playNormally", forceTranscodeSetting)
        normalOption = m.optionMenu.content.getChild(0)
        normalOption.title = tr("Play Normally - disabled because of selected force transcoding setting")
        if isStringEqual(forceTranscodeSetting, "forceTranscodeAllowRemux")
            transcodeOption = m.optionMenu.content.getChild(2)
            transcodeOption.title = tr("Force Transcode (Allow Remux) - disabled because of selected force transcoding setting")
            m.optionMenu.checkedItem = 1
        end if
        if isStringEqual(forceTranscodeSetting, "forceTranscodeDisableRemux")
            transcodeOption = m.optionMenu.content.getChild(1)
            transcodeOption.title = tr("Force Transcode (Remux Disabled) - disabled because of selected force transcoding setting")
            m.optionMenu.checkedItem = 2
        end if
    else if isStringEqual(m.global.queueManager.callFunc("getForceTranscode"), "forceTranscodeAllowRemux")
        m.optionMenu.checkedItem = 1
    else if isStringEqual(m.global.queueManager.callFunc("getForceTranscode"), "forceTranscodeDisableRemux")
        m.optionMenu.checkedItem = 2
    else
        m.optionMenu.checkedItem = 0
    end if
    '  subtitle Tab
    if isValid(m.top.Options.subtitles)
        subtitleContent = CreateObject("roSGNode", "ContentNode")
        index = 0
        selectedSubtitleIndex = 0
        for each subtitle in m.top.options.subtitles
            entry = subtitleContent.CreateChild("SubtitleTrackListData")
            entry.json = subtitle.json
            entry.title = subtitle.Title
            entry.description = subtitle.Title
            entry.StreamIndex = subtitle.StreamIndex
            if isValid(subtitle.Selected) and subtitle.Selected
                selectedSubtitleIndex = index
                entry.selected = true
            end if
            index = index + 1
        end for
        m.menus[0].content = subtitleContent
        m.menus[0].jumpToItem = selectedSubtitleIndex
        m.menus[0].checkedItem = selectedSubtitleIndex
        m.selectedSubtitleIndex = selectedSubtitleIndex
    end if
    '  audio Tab
    if isValid(m.top.Options.audios)
        audioContent = CreateObject("roSGNode", "ContentNode")
        index = 0
        selectedAudioIndex = 0
        for each audio in m.top.options.audios
            entry = audioContent.CreateChild("AudioTrackListData")
            entry.title = audio.Title
            entry.description = audio.Description
            entry.streamIndex = audio.StreamIndex
            entry.streamName = audio.RokuTrackName
            m.audioNames.push(audio.Name)
            if audio.Selected <> invalid and audio.Selected
                selectedAudioIndex = index
                entry.selected = true
                m.top.audioStreamName = audio.LookupCI("RokuTrackName")
                m.top.audioStreamIndex = audio.LookupCI("streamIndex")
            end if
            index = index + 1
        end for
        m.menus[1].content = audioContent
        m.menus[1].jumpToItem = selectedAudioIndex
        m.menus[1].checkedItem = selectedAudioIndex
        m.selectedAudioIndex = selectedAudioIndex
    end if
    '  Videos Tab
    if isValid(m.top.options.videos)
        viewContent = CreateObject("roSGNode", "ContentNode")
        index = 0
        selectedViewIndex = 0
        for each view in m.top.options.videos
            entry = viewContent.CreateChild("VideoTrackListData")
            entry.title = view.Title
            entry.description = view.Description
            entry.streamId = view.streamId
            entry.video_codec = view.video_codec
            entry.codec = view.codec
            m.videoNames.push(view.Name)
            if isValid(view.Selected) and view.Selected
                selectedViewIndex = index
                entry.selected = true
                m.top.videoStreamId = view.streamId
            end if
            index = index + 1
        end for
        m.menus[2].content = viewContent
        m.menus[2].jumpToItem = selectedViewIndex
        m.menus[2].checkedItem = selectedViewIndex
        m.selectedVideoIndex = selectedViewIndex
    end if
end sub

' Switch menu shown when button focus changes
sub buttonFocusChanged()
    if m.buttons.focusedIndex = m.selectedItem then
        return
    end if
    m.fadeOutAnimOpacity.fieldToInterp = m.menus[m.selectedItem].id + ".opacity"
    m.fadeInAnimOpacity.fieldToInterp = m.menus[m.buttons.focusedIndex].id + ".opacity"
    m.fadeAnim.control = "start"
    m.selectedItem = m.buttons.focusedIndex
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if key = "down" or (key = "OK" and m.top.findNode("buttons").hasFocus())
        m.top.findNode("buttons").setFocus(false)
        m.menus[m.selectedItem].setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.menus[m.selectedItem]
        m.menus[m.selectedItem].drawFocusFeedback = true
        'If user presses down from button menu, focus first item.  If OK, focus checked item
        if key = "down"
            m.menus[m.selectedItem].jumpToItem = 0
        else
            m.menus[m.selectedItem].jumpToItem = m.menus[m.selectedItem].itemSelected
        end if
        return true
    end if
    if key = "OK"
        if m.menus[m.selectedItem].isInFocusChain()
            selMenu = m.menus[m.selectedItem]
            selIndex = selMenu.itemSelected
            'Handle Videos menu
            if m.selectedItem = 2
                if m.selectedVideoIndex = selIndex
                else
                    selMenu.content.GetChild(m.selectedVideoIndex).selected = false
                    newSelection = selMenu.content.GetChild(selIndex)
                    newSelection.selected = true
                    m.selectedVideoIndex = selIndex
                    m.top.videoStreamId = newSelection.streamId
                    m.top.video_codec = newSelection.video_codec
                    m.top.codec = newSelection.codec
                end if
                ' Then it is Audio options
            else if m.selectedItem = 1
                if m.selectedAudioIndex = selIndex
                else
                    selMenu.content.GetChild(m.selectedAudioIndex).selected = false
                    newSelection = selMenu.content.GetChild(selIndex)
                    newSelection.selected = true
                    m.selectedAudioIndex = selIndex
                    m.top.audioStreamName = newSelection.LookupCI("streamName")
                    m.top.audioStreamIndex = newSelection.LookupCI("streamIndex")
                end if
                ' Then it is Subtitle options
            else if m.selectedItem = 0
                if m.selectedSubtitleIndex = selIndex
                else
                    selMenu.content.GetChild(m.selectedSubtitleIndex).selected = false
                    newSelection = selMenu.content.GetChild(selIndex)
                    newSelection.selected = true
                    m.selectedSubtitleIndex = selIndex
                    m.top.subtitleStream = newSelection
                    m.global.queueManager.callFunc("setPreferredSubtitleTrack", newSelection)
                end if
            else if m.selectedItem = 3 ' Options Menu
                if isStringEqual("forceTranscodeAllowRemux", chainLookupReturn(m.global.session, "user.settings.`playback.media.forceTranscode`", "playNormally"))
                    m.optionMenu.checkedItem = 1
                end if
                if isStringEqual("forceTranscodeDisableRemux", chainLookupReturn(m.global.session, "user.settings.`playback.media.forceTranscode`", "playNormally"))
                    m.optionMenu.checkedItem = 2
                end if
                if m.optionMenu.checkedItem = 0
                    m.global.queueManager.callFunc("setForceTranscode", "playNormally")
                else if m.optionMenu.checkedItem = 1
                    m.global.queueManager.callFunc("setForceTranscode", "forceTranscodeAllowRemux", "")
                else if m.optionMenu.checkedItem = 2
                    m.global.queueManager.callFunc("setForceTranscode", "forceTranscodeDisableRemux", m.top.codec)
                end if
            end if
        end if
        return true
    end if
    if key = "back" or key = "up"
        if m.menus[m.selectedItem].isInFocusChain()
            m.buttons.setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.buttons
            m.menus[m.selectedItem].drawFocusFeedback = false
            return true
        end if
    end if
    if key = "options"
        m.menus[m.selectedItem].drawFocusFeedback = false
        return false
    end if
    return false
end function
'//# sourceMappingURL=./MovieOptions.brs.map