'import "pkg:/source/utils/config.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.top.optionsAvailable = true
    m.top.overhangVisible = false
    m.slideshowTimer = m.top.findNode("slideshowTimer")
    m.slideshowTimer.observeField("fire", "nextSlide")
    m.status = m.top.findNode("status")
    m.textBackground = m.top.findNode("background")
    m.statusTimer = m.top.findNode("statusTimer")
    m.statusTimer.observeField("fire", "statusUpdate")
    m.slideshow = m.global.session.user.settings["photos.slideshow"]
    m.random = m.global.session.user.settings["photos.random"]
    m.showStatusAnimation = m.top.findNode("showStatusAnimation")
    m.hideStatusAnimation = m.top.findNode("hideStatusAnimation")
    m.videoPlayer = m.top.findNode("videoPlayer")
    m.videoPlayer.disableScreenSaver = true
    itemContentChanged()
end sub

sub itemContentChanged()
    m.LoadLibrariesTask = createObject("roSGNode", "LoadPhotoTask")
    if isValid(m.top.itemsNode)
        if isValid(m.top.itemsNode.content)
            m.LoadLibrariesTask.itemNodeContent = m.top.itemsNode.content.getChild(m.top.itemIndex)
        else if isValidAndNotEmpty(m.top.itemsNode.id)
            m.LoadLibrariesTask.itemNodeContent = m.top.itemsNode
        end if
    else if isValid(m.top.itemsArray)
        itemContent = m.top.itemsArray[m.top.itemIndex]
        m.LoadLibrariesTask.itemArrayContent = itemContent
    else
        return
    end if
    m.LoadLibrariesTask.observeField("results", "onPhotoLoaded")
    m.LoadLibrariesTask.control = "RUN"
end sub

sub onPhotoLoaded()
    stopLoadingSpinner()
    if m.LoadLibrariesTask.results <> invalid
        photo = m.top.findNode("photo")
        photo.uri = m.LoadLibrariesTask.results
        if m.slideshow = true or m.random = true
            ' user has requested either a slideshow or random...
            m.slideshowTimer.control = "start"
        end if
    else
        'Show user error here (for example if it's not a supported image type)
        message_dialog("This image type is not supported.")
    end if
end sub

sub nextSlide()
    m.slideshowTimer.control = "stop"
    if m.slideshow = true
        if isValidToContinue(m.top.itemIndex + 1)
            m.top.itemIndex++
            m.slideshowTimer.control = "start"
            return
        end if
    else if m.random = true
        index = invalid
        if isValid(m.top.itemsNode)
            if isValidAndNotEmpty(m.top.itemsNode.content)
                index = rnd(m.top.itemsNode.content.getChildCount() - 1)
            else
                ' we're dealing with a single photo
                return
            end if
        else if isValid(m.top.itemsArray)
            if m.top.itemsArray.count() > 0
                index = rnd(m.top.itemsArray.count() - 1)
            end if
        end if
        if isValid(index) and isValidToContinue(index)
            m.top.itemIndex = index
            m.slideshowTimer.control = "start"
            return
        end if
    end if
    ' We're not moving to a new image, enable the screensaver
    if m.videoPlayer.disableScreenSaver
        m.videoPlayer.disableScreenSaver = false
    end if
end sub

sub statusUpdate()
    m.statusTimer.control = "stop"
    m.hideStatusAnimation.control = "start"
end sub

' JFScreen hook.
' Used to ensure tasks are stopped
sub OnScreenHidden()
    m.slideshowTimer.control = "stop"
    m.statusTimer.control = "stop"
end sub

' isSlideshow component field has changed
sub isSlideshowChanged()
    m.slideshow = m.top.isSlideshow
end sub

' isRandom component field has changed
sub isRandomChanged()
    m.random = m.top.isRandom
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        return false
    end if
    if key = "right"
        if isValidToContinue(m.top.itemIndex + 1)
            m.videoPlayer.disableScreenSaver = true
            m.slideshowTimer.control = "stop"
            m.top.itemIndex++
        end if
        return true
    end if
    if key = "left"
        if isValidToContinue(m.top.itemIndex - 1)
            m.videoPlayer.disableScreenSaver = true
            m.slideshowTimer.control = "stop"
            m.top.itemIndex--
        end if
        return true
    end if
    if key = "play"
        if m.slideshowTimer.control = "start"
            ' stop the slideshow if the user hits "pause"
            m.slideshowTimer.control = "stop"
            m.status.text = tr("Slideshow Paused")
            if m.textBackground.opacity = 0
                m.showStatusAnimation.control = "start"
            end if
            m.statusTimer.control = "start"
            m.videoPlayer.disableScreenSaver = false
        else
            if not isValidToContinue(m.top.itemIndex + 1) then
                return false
            end if
            ' start the slideshow if the user hits "play"
            m.status.text = tr("Slideshow Resumed")
            if m.textBackground.opacity = 0
                m.showStatusAnimation.control = "start"
            end if
            m.slideshow = true
            m.statusTimer.control = "start"
            m.slideshowTimer.control = "start"
            m.videoPlayer.disableScreenSaver = true
        end if
        return true
    end if
    if key = "options"
        ' Options (random etc) is done on itemGrid
        return true
    end if
    return false
end function

function isValidToContinue(index as integer)
    if isValid(m.top.itemsNode)
        if isValidAndNotEmpty(m.top.itemsNode.content)
            if index >= 0 and index < m.top.itemsNode.content.getChildCount()
                return true
            end if
        else if isValidAndNotEmpty(m.top.itemsNode) and index = 0
            return true
        end if
    else if isValidAndNotEmpty(m.top.itemsArray)
        if index >= 0 and index < m.top.itemsArray.count()
            return true
        end if
    end if
    return false
end function
'//# sourceMappingURL=./PhotoDetails.brs.map