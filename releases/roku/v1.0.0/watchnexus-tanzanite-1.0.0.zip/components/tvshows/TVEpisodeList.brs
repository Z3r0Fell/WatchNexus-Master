'import "pkg:/source/enums/AnimationControl.bs"
'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.scrollBarThumbSlideAnimation = m.top.findnode("scrollBarThumbSlideAnimation")
    m.scrollBarThumbSlideInterpolator = m.top.findnode("scrollBarThumbSlideInterpolator")
    m.scrollBar = m.top.findnode("scrollBar")
    m.thumb = m.top.findnode("thumb")
    m.thumbStep = 0
    m.scrollBar.opacity = .75
    m.scrollBar.color = "0x00000077"
    m.thumb.color = "#aaaaaa"
    m.firstUnwatched = 0
    m.top.content = setData()
    updateSize()
    m.top.observeFieldscoped("numColumns", "onNumColumnsChange")
    m.top.observeFieldscoped("currFocusRow", "onCurrFocusRowChange")
    m.top.observeFieldscoped("clippingRect", "onclippingRectChange")
    if chainLookupReturn(m.global.session, "user.settings.`ui.tvshows.startListFromUnwatched`", false)
        m.top.jumpToItem = m.firstUnwatched
    end if
    calculateButtonThumbProperties()
end sub

sub onclippingRectChange()
    m.scrollBar.height = m.top.clippingRect.height * .90
    calculateButtonThumbProperties()
end sub

sub onNumColumnsChange()
    updateSize()
    calculateButtonThumbProperties()
    onCurrFocusRowChange()
    m.top.content = setData()
end sub

sub hideScrollbar()
    m.scrollBar.visible = false
end sub

sub calculateButtonThumbProperties()
    if not isValid(m.scrollBar)
        hideScrollbar()
        return
    end if
    if not isValid(m.top.content)
        hideScrollbar()
        return
    end if
    if m.top.content.getChildCount() < 3
        hideScrollbar()
        return
    end if
    m.scrollBar.visible = true
    rowCount = Fix(m.top.content.getChildCount() / m.top.numColumns)
    displayedRows = rowCount
    if (m.top.content.getChildCount() / m.top.numColumns) > rowCount
        displayedRows += 1
    end if
    m.thumb.height = m.scrollBar.height / displayedRows
    m.thumbStep = m.thumb.height
end sub

sub onCurrFocusRowChange()
    m.scrollBarThumbSlideInterpolator.keyValue = [
        m.thumb.translation
        [
            0
            m.thumbStep * m.top.currFocusRow
        ]
    ]
    m.scrollBarThumbSlideAnimation.control = "start"
end sub

sub updateSize()
    m.top.itemSpacing = [
        20
        20
    ]
    if m.top.numColumns = 1
        m.top.itemSize = [
            1620
            300
        ]
        return
    end if
    ' Size of the individual episodes
    m.top.itemSize = [
        805
        200
    ]
end sub

sub setupRows()
    updateSize()
    objects = m.top.objects
    m.top.numRows = objects.items.count()
    if chainLookupReturn(m.global.session, "user.settings.TVSeasonDetails-twocolumnepisodelist", true) then
        m.top.numColumns = 2
    else
        m.top.numColumns = 1
    end if
    m.top.content = setData()
    calculateButtonThumbProperties()
    if chainLookupReturn(m.global.session, "user.settings.`ui.tvshows.startListFromUnwatched`", false)
        m.top.jumpToItem = m.firstUnwatched
    end if
end sub

function setData()
    data = CreateObject("roSGNode", "ContentNode")
    if not isValid(m.top.objects) then
        return data
    end if
    i = 0
    m.firstUnwatched = -1
    for each item in m.top.objects.items
        if m.firstUnwatched = -1
            if not chainLookupReturn(item, "watched", false)
                m.firstUnwatched = i
                exit for
            end if
        end if
        i++
    end for
    data.appendChildren(m.top.objects.items)
    m.top.doneLoading = true
    return data
end function

function onKeyEvent(key as string, press as boolean) as boolean
    return false
end function
'//# sourceMappingURL=./TVEpisodeList.brs.map