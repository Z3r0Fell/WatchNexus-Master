'import "pkg:/source/api/Items.bs"
'import "pkg:/source/api/baserequest.bs"
'import "pkg:/source/utils/config.bs"
'import "pkg:/source/api/Image.bs"
'import "pkg:/source/utils/deviceCapabilities.bs"

sub init()
    m.top.functionName = "getExtras"
end sub

sub getExtras()
    if isValid(m.top.seasonID) and m.top.seasonID <> ""
        m.top.results = TVSeasonExtras(m.top.seasonID)
    end if
end sub
'//# sourceMappingURL=./TVExtrasTask.brs.map