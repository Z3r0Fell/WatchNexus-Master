'import "pkg:/source/utils/config.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.title = m.top.findNode("title")
    m.title.text = tr("Loading...")
    m.overview = m.top.findNode("overview")
    m.poster = m.top.findNode("poster")
    m.rating = m.top.findnode("rating")
    m.infoBar = m.top.findnode("infoBar")
    m.progressBackground = m.top.findNode("progressBackground")
    m.progressBar = m.top.findnode("progressBar")
    m.playedIndicator = m.top.findNode("playedIndicator")
end sub

sub onWidthChanged()
    setposterSize()
    textWidth = m.top.width - m.poster.width - 65
    if isValid(m.title)
        m.title.maxWidth = textWidth
    end if
    if isValid(m.overview)
        m.overview.width = textWidth
    end if
    setFontSizes()
    setVerticalMargins()
end sub

sub setVerticalMargins()
    text = m.top.findnode("text")
    if not isValid(text) then
        return
    end if
    fullsize = m.top.width > 1000
    if fullsize then
        verticalMargin = 20
    else
        verticalMargin = 10
    end if
    text.itemSpacings = ("[" + bslib_toString(verticalMargin) + "]")
end sub

sub setposterSize()
    fullsize = m.top.width > 1000
    if fullsize then
        m.poster.height = 300
    else
        m.poster.height = 200
    end if
    m.poster.width = m.poster.height * 1.165
    m.playedIndicator.translation = [
        m.poster.width - 60
        0
    ]
    m.progressBackground.translation = [
        0
        m.poster.height - 14
    ]
    if m.progressBackground.visible
        itemData = m.top.itemContent
        if not isValid(itemData) then
            return
        end if
        m.progressBackground.width = m.poster.width
        progressWidthInPixels = int(m.progressBackground.width * chainLookup(itemData.json, "UserData.PlayedPercentage") / 100)
        m.progressBar.width = progressWidthInPixels
    end if
end sub

sub setFontSizes()
    fullsize = m.top.width > 1000
    if isValid(m.overview)
        if fullsize then
            m.overview.font.size = 30
        else
            m.overview.font.size = 25
        end if
        if fullsize then
            m.overview.maxLines = 4
        else
            m.overview.maxLines = 3
        end if
        if fullsize then
            m.overview.height = 180
        else
            m.overview.height = 130
        end if
    end if
    if isValid(m.title)
        if fullsize then
            m.title.font.size = 33
        else
            m.title.font.size = 27
        end if
    end if
    communityRating = m.top.findNode("communityRating")
    if isValid(communityRating)
        if fullsize then
            communityRating.font.size = 26
        else
            communityRating.font.size = 23
        end if
    end if
    runtime = m.top.findNode("runtime")
    if isValid(runtime)
        if fullsize then
            runtime.font.size = 26
        else
            runtime.font.size = 23
        end if
    end if
    endtime = m.top.findNode("endtime")
    if isValid(endtime)
        if fullsize then
            endtime.font.size = 26
        else
            endtime.font.size = 23
        end if
    end if
    aired = m.top.findNode("aired")
    if isValid(aired)
        if fullsize then
            aired.font.size = 26
        else
            aired.font.size = 23
        end if
    end if
end sub

sub itemContentChanged()
    itemData = m.top.itemContent
    if not isValid(itemData) then
        return
    end if
    m.playedIndicator.data = {
        played: chainLookupReturn(itemData, "watched", false)
        unplayedCount: chainLookupReturn(itemData, "json.UserData.UnplayedItemCount", 0)
    }
    m.overview.text = itemData.overview
    if not isChainValid(itemData, "json") then
        return
    end if
    if isValid(itemData.json.indexNumber)
        indexNumber = (bslib_toString(itemData.json.indexNumber) + ". ")
        if isValid(itemData.json.indexNumberEnd)
            indexNumber = (bslib_toString(itemData.json.indexNumber) + "-" + bslib_toString(itemData.json.indexNumberEnd) + ". ")
        end if
    else
        indexNumber = ""
    end if
    m.title.text = indexNumber + itemData.title
    imageUrl = itemData.posterURL
    if m.global.session.user.settings["ui.tvshows.blurunwatched"] = true
        if isStringEqual(itemData.LookupCI("Type"), "Episode")
            if not chainLookupReturn(itemData, "json.UserData.played", false)
                imageUrl += "&blur=15"
            end if
        end if
    end if
    m.poster.uri = imageUrl
    if isValid(itemData.json.LookupCI("PremiereDate"))
        airDate = CreateObject("roDateTime")
        airDate.FromISO8601String(itemData.json.LookupCI("PremiereDate"))
        m.top.findNode("aired").text = tr("Aired") + ": " + airDate.AsDateString("short-month-no-weekday")
    end if
    if isValid(itemData.json.LookupCI("RunTimeTicks"))
        if type(itemData.json.RunTimeTicks) = "roInt" or type(itemData.json.RunTimeTicks) = "LongInteger"
            runTime = getRuntime()
            if runTime < 2
                m.top.findNode("runtime").text = "1 " + tr("min")
            else
                m.top.findNode("runtime").text = (bslib_toString(stri(runTime).trim()) + " " + bslib_toString(tr("mins")))
            end if
            if m.global.session.user.settings["ui.design.hideclock"] <> true
                m.top.findNode("endtime").text = tr("Ends at %1").Replace("%1", getEndTime())
            end if
        end if
    end if
    if chainLookupReturn(m.global.session, "user.settings.`ui.itemdetail.showRatings`", true)
        if isValid(itemData.json.LookupCI("communityRating"))
            m.top.findNode("star").visible = true
            m.top.findNode("communityRating").text = str(int(itemData.json.LookupCI("communityRating") * 10) / 10)
        else
            m.top.findNode("star").visible = false
        end if
    else
        m.rating.visible = false
        m.infoBar.itemSpacings = [
            20
            -25
            20
            20
        ]
    end if
    ' Add progress bar on bottom (if applicable)
    if chainLookupReturn(itemData, "json.UserData.PlayedPercentage", 0) > 0
        m.progressBackground.width = m.poster.width
        m.progressBackground.visible = true
        progressWidthInPixels = int(m.progressBackground.width * chainLookup(itemData.json, "UserData.PlayedPercentage") / 100)
        m.progressBar.width = progressWidthInPixels
        m.progressBar.visible = true
    else
        m.progressBackground.visible = false
        m.progressBar.visible = false
    end if
end sub

function getRuntime() as integer
    itemData = m.top.itemContent.json
    ' A tick is .1ms, so 1/10,000,000 for ticks to seconds,
    ' then 1/60 for seconds to minutess... 1/600,000,000
    return int(itemData.RunTimeTicks / 600000000.0)
end function

function getEndTime() as string
    itemData = m.top.itemContent.json
    date = CreateObject("roDateTime")
    duration_s = int(itemData.RunTimeTicks / 10000000.0)
    date.fromSeconds(date.asSeconds() + duration_s)
    date.toLocalTime()
    return formatTime(date)
end function

sub focusChanged()
    if m.top.itemHasFocus = true
        ' text to speech for accessibility
        if m.global.device.isAudioGuideEnabled = true
            txt2Speech = CreateObject("roTextToSpeech")
            txt2Speech.Flush()
            txt2Speech.Say(m.title.text)
            txt2Speech.Say(m.overview.text)
        end if
    end if
end sub
'//# sourceMappingURL=./TVEpisodeListItem.brs.map