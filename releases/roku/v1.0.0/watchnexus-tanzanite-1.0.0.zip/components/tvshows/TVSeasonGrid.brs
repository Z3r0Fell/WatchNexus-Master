'import "pkg:/source/enums/AnimationControl.bs"
'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/KeyCode.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.scrollBarThumbSlideAnimation = m.top.findnode("scrollBarThumbSlideAnimation")
    m.scrollBarThumbSlideInterpolator = m.top.findnode("scrollBarThumbSlideInterpolator")
    m.scrollBar = m.top.findnode("scrollBar")
    m.thumb = m.top.findnode("thumb")
    m.thumbStep = 0
    m.displayedRows = 1
    m.scrollBar.opacity = .75
    m.scrollBar.color = "0x00000077"
    m.thumb.color = "#aaaaaa"
    m.top.observeFieldscoped("itemFocused", "onItemFocusedChange")
    m.top.observeFieldscoped("numRows", "onNumRowsChange")
    m.top.observeFieldscoped("content", "contentChanged")
    m.top.observeFieldscoped("clippingRect", "onclippingRectChange")
end sub

sub onclippingRectChange()
    m.scrollBar.height = m.top.clippingRect.height * .90
    calculateButtonThumbProperties()
    onItemFocusedChange()
end sub

sub onNumRowsChange()
    calculateButtonThumbProperties()
    onItemFocusedChange()
end sub

sub hideScrollbar()
    m.scrollBar.visible = false
end sub

sub calculateButtonThumbProperties()
    if not isValid(m.scrollBar)
        hideScrollbar()
        return
    end if
    if not isValid(m.top.content)
        hideScrollbar()
        return
    end if
    if m.top.content.getChildCount() < 9
        hideScrollbar()
        return
    end if
    m.scrollBar.visible = true
    rowCount = Fix(m.top.content.getChildCount() / m.top.numColumns)
    displayedRows = rowCount
    if (m.top.content.getChildCount() / m.top.numColumns) > rowCount
        displayedRows += 1
    end if
    m.thumb.height = m.scrollBar.height / displayedRows
    m.thumbStep = m.thumb.height
end sub

sub onItemFocusedChange()
    m.scrollBarThumbSlideInterpolator.keyValue = [
        m.thumb.translation
        [
            0
            m.thumbStep * Fix(m.top.itemFocused / 8)
        ]
    ]
    m.scrollBarThumbSlideAnimation.control = "start"
end sub

sub contentChanged()
    calculateButtonThumbProperties()
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not m.top.isInFocusChain() then
        return false
    end if
    if not press then
        return false
    end if
    ' If user presses down and there is an incomplete row below the current row
    ' move cursor to last item on row below it
    if isStringEqual(key, "down")
        if m.displayedRows = 1 then
            return false
        end if
        if m.top.currFocusRow + 1 = m.displayedRows - 1
            if m.top.content.getChildCount() - (m.top.itemFocused + 1) < 8
                m.top.animateToItem = m.top.content.getChildCount() - 1
                return true
            end if
        end if
    end if
    return false
end function
'//# sourceMappingURL=./TVSeasonGrid.brs.map