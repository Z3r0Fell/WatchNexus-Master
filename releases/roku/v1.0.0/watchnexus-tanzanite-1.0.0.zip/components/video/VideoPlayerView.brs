'import "pkg:/source/api/Image.bs"
'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/ImageType.bs"
'import "pkg:/source/enums/ItemType.bs"
'import "pkg:/source/enums/KeyCode.bs"
'import "pkg:/source/enums/MediaPlaybackState.bs"
'import "pkg:/source/enums/MediaSegmentAction.bs"
'import "pkg:/source/enums/MediaSegmentType.bs"
'import "pkg:/source/enums/PlaybackMethod.bs"
'import "pkg:/source/enums/String.bs"
'import "pkg:/source/enums/SubtitleSelection.bs"
'import "pkg:/source/enums/TaskControl.bs"
'import "pkg:/source/enums/TimerControl.bs"
'import "pkg:/source/enums/VideoControl.bs"
'import "pkg:/source/utils/config.bs"
'import "pkg:/source/utils/misc.bs"


sub init()
    m.top.observeField("availableAudioTracks", "onAvailableAudioTracksChanged")
    m.subtitleOffset = 0
    m.LoadProgramDetailsTask = createObject("roSGNode", "LoadProgramDetailsTask")
    m.LoadProgramDetailsTask.observeField("programDetails", "onProgramDetailsLoaded")
    ' Hide the overhang on init to prevent showing 2 clocks
    m.top.getScene().findNode("overhang").visible = false
    currentItem = m.global.queueManager.callFunc("getCurrentItem")
    m.top.id = currentItem.id
    m.top.seekMode = "accurate"
    m.playbackEnum = {
        null: -10
    }
    preferredSubtitle = m.global.queueManager.callFunc("getPreferredSubtitleTrack")
    if isChainValid(preferredSubtitle, "StreamIndex") then
        m.top.SelectedSubtitle = preferredSubtitle.StreamIndex
    else
        m.top.SelectedSubtitle = -2
    end if
    m.originalClosedCaptionState = invalid
    ' Load meta data
    m.LoadMetaDataTask = CreateObject("roSGNode", "LoadVideoContentTask")
    m.LoadMetaDataTask.selectedSubtitleIndex = m.top.SelectedSubtitle
    m.LoadMetaDataTask.itemId = currentItem.id
    m.LoadMetaDataTask.itemType = currentItem.type
    m.LoadMetaDataTask.selectedAudioStreamIndex = currentItem.selectedAudioStreamIndex
    m.LoadMetaDataTask.observeField("content", "onVideoContentLoaded")
    m.LoadMetaDataTask.control = "RUN"
    m.PreloadTrickplayImagesTask = CreateObject("roSGNode", "PreloadTrickplayImagesTask")
    m.PreloadTrickplayImagesTask.videoID = currentItem.id
    m.canUseFastReplace = false
    m.positionTranslation = m.top.trickPlayBar.getChild(3)
    m.positionText = m.top.trickPlayBar.getChild(8)
    m.top.trickplaybar.observeField("visible", "onTrickPlayBarVisibleChange")
    m.positionText.observeField("text", "onTrickPlayBarTextChange")
    m.chapterList = m.top.findNode("chapterList")
    m.chapterMenu = m.top.findNode("chapterMenu")
    m.chapterMenu.focusBitmapBlendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    m.chapterMenu.color = "#ffffff"
    m.chapterMenu.focusedColor = "#ffffff"
    m.chapterContent = m.top.findNode("chapterContent")
    m.osd = m.top.findNode("osd")
    m.osd.observeField("action", "onOSDAction")
    m.clock = m.osd.findNode("clock")
    currentTimeTimer = m.clock.findNode("currentTimeTimer")
    currentTimeTimer.observeField("fire", "setVideoEndingTime")
    m.playbackTimer = m.top.findNode("playbackTimer")
    m.bufferCheckTimer = m.top.findNode("bufferCheckTimer")
    m.top.observeField("state", "onState")
    m.top.observeField("content", "onContentChange")
    m.top.observeField("selectedSubtitle", "onSubtitleChange")
    m.top.observeField("audioIndex", "onAudioIndexChange")
    ' Get sibling data and pass to OSD
    setSiblingData()
    ' Custom Caption Function
    m.top.observeField("allowCaptions", "onAllowCaptionsChange")
    m.playbackTimer.observeField("fire", "ReportPlayback")
    m.bufferPercentage = 0 ' Track whether content is being loaded
    m.playReported = false
    m.bufferCheckTimer.duration = 30
    m.playbackRetries = 0 ' Track retry attempts for buffering failures
    m.lastBufferError = 0 ' Timestamp of last buffering error
    if m.global.session.user.settings["ui.design.hideclock"] = true
        clockNode = findNodeBySubtype(m.top, "clock")
        if clockNode[0] <> invalid then
            clockNode[0].parent.removeChild(clockNode[0].node)
        end if
    end if
    m.videoEndingTime = m.top.findNode("videoEndingTime")
    m.subtitleSyncValue = m.top.findNode("subtitleSyncValue")
    m.subtitleSyncValue.font.size = 26
    m.subtitleSyncValue.text = (bslib_toString(tr("Current Offset")) + ": 0 ms")
    m.subtitleTimingButtons = m.top.findNode("subtitleTimingButtons")
    m.subtitleTimingButtons.color = "0x00000090"
    m.subtitleSyncPlus100 = m.top.findNode("subtitleSyncPlus100")
    m.subtitleSyncPlus100.fontSize = 25
    m.subtitleSyncPlus100.background = "#101010"
    m.subtitleSyncPlus100.color = "#ffffff"
    m.subtitleSyncPlus100.focusBackground = "0xff6867FF"
    m.subtitleSyncPlus100.focusColor = "#ffffff"
    m.subtitleSyncPlus500 = m.top.findNode("subtitleSyncPlus500")
    m.subtitleSyncPlus500.fontSize = 25
    m.subtitleSyncPlus500.background = "#101010"
    m.subtitleSyncPlus500.color = "#ffffff"
    m.subtitleSyncPlus500.focusBackground = "0xff6867FF"
    m.subtitleSyncPlus500.focusColor = "#ffffff"
    m.subtitleSyncMinus100 = m.top.findNode("subtitleSyncMinus100")
    m.subtitleSyncMinus100.fontSize = 25
    m.subtitleSyncMinus100.background = "#101010"
    m.subtitleSyncMinus100.color = "#ffffff"
    m.subtitleSyncMinus100.focusBackground = "0xff6867FF"
    m.subtitleSyncMinus100.focusColor = "#ffffff"
    m.subtitleSyncMinus500 = m.top.findNode("subtitleSyncMinus500")
    m.subtitleSyncMinus500.fontSize = 25
    m.subtitleSyncMinus500.background = "#101010"
    m.subtitleSyncMinus500.color = "#ffffff"
    m.subtitleSyncMinus500.focusBackground = "0xff6867FF"
    m.subtitleSyncMinus500.focusColor = "#ffffff"
    m.subtitleSyncReset = m.top.findNode("subtitleSyncReset")
    m.subtitleSyncReset.fontSize = 25
    m.subtitleSyncReset.background = "#101010"
    m.subtitleSyncReset.color = "#ffffff"
    m.subtitleSyncReset.focusBackground = "0xff6867FF"
    m.subtitleSyncReset.focusColor = "#ffffff"
    m.nextUp = m.top.findNode("nextUp")
    m.nextUpInfoLoaded = false
    m.skipSegmentButton = m.top.findNode("skipSegment")
    m.skipSegmentButton.background = "#c8fafa"
    m.skipSegmentButton.color = "#101010"
    m.skipSegmentButton.focusBackground = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    m.skipSegmentButton.focusColor = "#ffffff"
    'Play Next Episode button
    m.nextupbuttonseconds = m.global.session.user.settings["playback.nextupbuttonseconds"].ToInt()
    ' Skip segment tracking
    m.mediaSegmentDismissed = {}
    m.currentSegmentType = invalid
    m.checkedForNextEpisode = false
    m.getNextEpisodeTask = createObject("roSGNode", "GetNextEpisodeTask")
    m.getNextEpisodeTask.observeField("nextEpisodeData", "onNextEpisodeDataLoaded")
    m.top.retrievingBar.filledBarBlendColor = "#6867ff"
    m.top.bufferingBar.filledBarBlendColor = "#6867ff"
    m.top.trickPlayBar.filledBarBlendColor = "#6867ff"
end sub

sub onAvailableAudioTracksChanged()
    if not isValidAndNotEmpty(m.top.availableAudioTracks) then
        return
    end if
    preferredAudioTrackName = m.global.queueManager.callFunc("getPreferredAudioTrackName")
    for each audioTrack in m.top.availableAudioTracks
        if isStringEqual(audioTrack.LookupCI("name"), preferredAudioTrackName)
            m.global.queueManager.callFunc("setPreferredAudioTrackIndex", audioTrack.LookupCI("Track").toint())
            m.top.audioIndex = audioTrack.LookupCI("Track")
            ' Save the current video position
            if m.top.position <> 0
                m.global.queueManager.callFunc("setTopStartingPoint", int(m.top.position) * 10000000&)
            end if
            m.top.control = "STOP"
            m.LoadMetaDataTask.selectedAudioStreamIndex = m.top.audioIndex
            m.LoadMetaDataTask.itemId = m.top.id
            m.LoadMetaDataTask.observeField("content", "onVideoContentLoaded")
            m.LoadMetaDataTask.control = "RUN"
            exit for
        end if
    end for
end sub

' setSiblingData: Set the icon and title text for the previous and next items
'
sub setSiblingData()
    previousItemTitleText = m.global.queueManager.callFunc("getPreviousItemTitleAndIcon")
    if isValidAndNotEmpty(previousItemTitleText)
        m.osd.previousItemIcon = previousItemTitleText[0]
        m.osd.previousItemTitleText = previousItemTitleText[1]
    else
        m.osd.previousItemIcon = ""
        m.osd.previousItemTitleText = ""
    end if
    nextItemTitleText = m.global.queueManager.callFunc("getNextItemTitleAndIcon")
    if isValidAndNotEmpty(nextItemTitleText)
        m.osd.nextItemIcon = nextItemTitleText[0]
        m.osd.nextItemTitleText = nextItemTitleText[1]
    else
        m.osd.nextItemIcon = ""
        m.osd.nextItemTitleText = ""
    end if
end sub

' handleChapterSkipAction: Handles user command to skip chapters in playing video
'
sub handleChapterSkipAction(action as string)
    if not isValidAndNotEmpty(m.chapters) then
        return
    end if
    currentChapter = getCurrentChapterIndex()
    if action = "chapternext"
        gotoChapter = currentChapter + 1
        ' If there is no next chapter, exit
        if gotoChapter > m.chapters.count() - 1 then
            return
        end if
        newPosition = m.chapters[gotoChapter].StartPositionTicks / 10000000#
        m.top.seek = newPosition
        setVideoEndingTime(newPosition)
        m.positionText.text = secondsToHuman(newPosition, true)
        return
    end if
    if action = "chapterback"
        gotoChapter = currentChapter - 1
        ' If there is no previous chapter, restart current chapter
        if gotoChapter < 0 then
            gotoChapter = 0
        end if
        newPosition = m.chapters[gotoChapter].StartPositionTicks / 10000000#
        m.top.seek = newPosition
        setVideoEndingTime(newPosition)
        m.positionText.text = secondsToHuman(newPosition, true)
        return
    end if
end sub

' handleItemSkipAction: Handles user command to skip items
'
' @param {string} action - skip action to take
sub handleItemSkipAction(action as string)
    if action = "itemnext"
        ' If there is something next in the queue, play it
        if m.global.queueManager.callFunc("getPosition") < m.global.queueManager.callFunc("getCount") - 1
            m.top.control = "STOP"
            m.global.sceneManager.callFunc("clearPreviousScene")
            m.global.queueManager.callFunc("moveForward")
            m.global.queueManager.callFunc("playQueue")
        end if
        return
    end if
    if action = "itemback"
        ' If there is something previous in the queue, play it
        if m.global.queueManager.callFunc("getPosition") > 0
            m.top.control = "STOP"
            m.global.sceneManager.callFunc("clearPreviousScene")
            m.global.queueManager.callFunc("moveBack")
            m.global.queueManager.callFunc("playQueue")
        end if
        return
    end if
end sub

' handleHideAction: Handles action to hide OSD menu
'
' @param {boolean} resume - controls whether or not to resume video playback when sub is called
'
sub handleHideAction(resume as boolean)
    m.osd.visible = false
    m.chapterList.visible = false
    m.osd.showChapterList = false
    m.chapterList.setFocus(false)
    m.osd.hasFocus = false
    m.osd.setFocus(false)
    m.top.setFocus(true)
    if resume
        m.top.control = "RESUME"
    end if
end sub

' handleChapterListAction: Handles action to show chapter list
'
sub handleChapterListAction()
    m.chapterList.visible = m.osd.showChapterList
    if not m.chapterList.visible then
        return
    end if
    m.chapterMenu.jumpToItem = getCurrentChapterIndex()
    positionChapterList()
    m.osd.hasFocus = false
    m.osd.setFocus(false)
    m.chapterMenu.setFocus(true)
end sub

' getCurrentChapterIndex: Finds current chapter index
'
' @return {integer} indicating index of current chapter within chapter data or 0 if chapter lookup fails
'
function getCurrentChapterIndex() as integer
    if not isValidAndNotEmpty(m.chapters) then
        return 0
    end if
    ' Give a 15 second buffer to compensate for user expectation and roku video position inaccuracy
    ' Web client uses 10 seconds, but this wasn't enough for Roku in testing
    currentPosition = m.top.position + 15
    currentChapter = 0
    for i = m.chapters.count() - 1 to 0 step -1
        if currentPosition >= (m.chapters[i].StartPositionTicks / 10000000#)
            currentChapter = i
            exit for
        end if
    end for
    return currentChapter
end function

' handleVideoPlayPauseAction: Handles action to either play or pause the video content
'
sub handleVideoPlayPauseAction()
    ' If video is paused, resume it
    if m.top.state = "paused"
        handleHideAction(true)
        return
    end if
    ' Pause video
    m.top.control = "PAUSE"
end sub

' handleShowSubtitleMenuAction: Handles action to show subtitle selection menu
'
sub handleShowSubtitleMenuAction()
    m.top.selectSubtitlePressed = true
end sub

' handleShowAudioMenuAction: Handles action to show audio selection menu
'
sub handleShowAudioMenuAction()
    m.top.selectAudioPressed = true
end sub

' handleShowVideoInfoPopupAction: Handles action to show video info popup
'
sub handleShowVideoInfoPopupAction()
    m.top.selectPlaybackInfoPressed = true
end sub

' handleShowVideoOverviewPopupAction: Handles action to show video overview popup
'
sub handleShowVideoOverviewPopupAction()
    if not isValidAndNotEmpty(m.overview)
        m.overview = "No overview data available"
    end if
    overviewPopupTitle = m.top.content.title
    if m.top.content.live
        if isValidAndNotEmpty(m.osd.itemSubtitleText)
            overviewPopupTitle = m.osd.itemSubtitleText
        else if isValidAndNotEmpty(m.osd.itemTitleText)
            overviewPopupTitle = m.osd.itemTitleText
        end if
    end if
    m.global.sceneManager.callFunc("standardDialog", overviewPopupTitle, {
        data: [
            "<p>" + m.overview + "</p>"
        ]
    })
end sub

' onOSDAction: Process action events from OSD to their respective handlers
'
sub onOSDAction()
    action = LCase(m.osd.action)
    if action = "hide"
        handleHideAction(false)
        return
    end if
    if action = "play"
        handleHideAction(true)
        return
    end if
    if action = "chapterback" or action = "chapternext"
        handleChapterSkipAction(action)
        return
    end if
    if action = "chapterlist"
        handleChapterListAction()
        return
    end if
    if action = "videoplaypause"
        handleVideoPlayPauseAction()
        return
    end if
    if action = "showsubtitlemenu"
        handleShowSubtitleMenuAction()
        return
    end if
    if action = "showaudiomenu"
        handleShowAudioMenuAction()
        return
    end if
    if action = "showvideoinfopopup"
        handleShowVideoInfoPopupAction()
        return
    end if
    if isStringEqual(action, "showvideooverviewpopup")
        handleShowVideoOverviewPopupAction()
        return
    end if
    if action = "itemback" or action = "itemnext"
        handleItemSkipAction(action)
        return
    end if
    if action = "showsyncmenu"
        handleShowsyncmenuAction()
        return
    end if
end sub

sub handleShowsyncmenuAction()
    ' Hide the OSD
    handleHideAction(false)
    m.subtitleTimingButtons.visible = true
    m.subtitleSyncPlus100.focus = true
    m.subtitleSyncPlus100.setfocus(true)
end sub

sub hidesyncmenuAction()
    m.subtitleSyncPlus100.setFocus(false)
    m.subtitleSyncPlus100.focus = false
    m.subtitleSyncPlus500.setFocus(false)
    m.subtitleSyncPlus500.focus = false
    m.subtitleSyncMinus100.setFocus(false)
    m.subtitleSyncMinus100.focus = false
    m.subtitleSyncMinus500.setFocus(false)
    m.subtitleSyncMinus500.focus = false
    m.subtitleSyncReset.setFocus(false)
    m.subtitleSyncReset.focus = false
    m.top.setFocus(true)
    m.subtitleTimingButtons.visible = false
end sub

' Only setup caption items if captions are allowed
sub onAllowCaptionsChange()
    if not m.top.allowCaptions then
        return
    end if
    m.captionGroup = m.top.findNode("captionGroup")
    m.captionGroup.createchildren(9, "LayoutGroup")
    m.captionTask = createObject("roSGNode", "captionTask")
    m.captionTask.observeField("currentCaption", "updateCaption")
    m.captionTask.observeField("useThis", "checkCaptionMode")
    m.top.observeField("subtitleTrack", "loadCaption")
    m.top.observeField("globalCaptionMode", "toggleCaption")
    if m.global.session.user.settings["playback.subs.custom"]
        m.top.suppressCaptions = true
        toggleCaption()
    else
        m.top.suppressCaptions = false
    end if
end sub

' Set caption url to server subtitle track
sub loadCaption()
    if m.top.suppressCaptions
        m.captionTask.url = m.top.subtitleTrack
    end if
end sub

' Toggles visibility of custom subtitles and sets captionTask's player state
sub toggleCaption()
    m.captionTask.playerState = m.top.state + m.top.globalCaptionMode
    if LCase(m.top.globalCaptionMode) = "on"
        m.captionTask.playerState = m.top.state + m.top.globalCaptionMode + "w"
        m.captionGroup.visible = true
    else
        m.captionGroup.visible = false
    end if
end sub

' Removes old subtitle lines and adds new subtitle lines
sub updateCaption()
    m.captionGroup.removeChildrenIndex(m.captionGroup.getChildCount(), 0)
    m.captionGroup.appendChildren(m.captionTask.currentCaption)
end sub

' Event handler for when selectedSubtitle changes
sub onSubtitleChange()
    switchWithoutRefresh = true
    if m.top.SelectedSubtitle <> -1
        ' If the global caption mode is off, then Roku can't display the subtitles natively and needs a video stop/start
        if LCase(m.top.globalCaptionMode) <> "on" then
            switchWithoutRefresh = false
        end if
    end if
    ' If previous sustitle was encoded, then we need to a video stop/start to change subtitle content
    if m.top.previousSubtitleWasEncoded then
        switchWithoutRefresh = false
    end if
    if switchWithoutRefresh then
        return
    end if
    ' Save the current video position
    m.global.queueManager.callFunc("setTopStartingPoint", int(m.top.position) * 10000000&)
    m.top.control = "STOP"
    m.LoadMetaDataTask.selectedSubtitleIndex = m.top.SelectedSubtitle
    m.LoadMetaDataTask.itemId = m.top.id
    m.LoadMetaDataTask.observeField("content", "onVideoContentLoaded")
    m.LoadMetaDataTask.control = "RUN"
end sub

' Event handler for when audioIndex changes
sub onAudioIndexChange()
    ' Skip initial audio index setting
    if m.top.position = 0 then
        return
    end if
    ' Save the current video position
    m.global.queueManager.callFunc("setTopStartingPoint", int(m.top.position) * 10000000&)
    m.top.control = "STOP"
    m.LoadMetaDataTask.selectedAudioStreamIndex = m.top.audioIndex
    m.LoadMetaDataTask.itemId = m.top.id
    m.LoadMetaDataTask.observeField("content", "onVideoContentLoaded")
    m.LoadMetaDataTask.control = "RUN"
end sub

sub onPlaybackErrorDialogClosed(msg)
    sourceNode = msg.getRoSGNode()
    sourceNode.unobserveField("buttonSelected")
    sourceNode.unobserveField("wasClosed")
    m.global.sceneManager.callFunc("popScene")
end sub

sub onPlaybackErrorButtonSelected(msg)
    sourceNode = msg.getRoSGNode()
    sourceNode.close = true
end sub

sub showPlaybackErrorDialog(errorMessage as string)
    dialog = createObject("roSGNode", "Dialog")
    dialog.title = tr("Error During Playback")
    dialog.buttons = [
        tr("OK")
    ]
    dialog.message = errorMessage
    dialog.observeField("buttonSelected", "onPlaybackErrorButtonSelected")
    dialog.observeField("wasClosed", "onPlaybackErrorDialogClosed")
    m.top.getScene().dialog = dialog
end sub

sub onVideoContentLoaded()
    m.LoadMetaDataTask.unobserveField("content")
    m.LoadMetaDataTask.control = "STOP"
    videoContent = m.LoadMetaDataTask.content
    m.LoadMetaDataTask.content = []
    stopLoadingSpinner()
    hidesyncmenuAction()
    ' If we have nothing to play, return to previous screen
    if not isValid(videoContent)
        showPlaybackErrorDialog(tr("There was an error retrieving the data for this item from the server."))
        return
    end if
    if not isValid(videoContent[0])
        showPlaybackErrorDialog(tr("There was an error retrieving the data for this item from the server."))
        return
    end if
    m.isTranscoded = videoContent[0].isTranscoded
    burnInSubtitles = chainLookupReturn(m.global, "session.user.settings.`playback.subs.burnin`", true)
    if m.isTranscoded and burnInSubtitles
        videoContent[0].content.SubtitleTracks = []
    end if
    m.top.content = videoContent[0].content
    m.top.PlaySessionId = videoContent[0].PlaySessionId
    m.top.videoId = videoContent[0].id
    m.top.container = videoContent[0].container
    m.top.mediaSourceId = videoContent[0].mediaSourceId
    m.top.fullSubtitleData = videoContent[0].fullSubtitleData
    m.top.fullAudioData = videoContent[0].fullAudioData
    m.top.audioIndex = videoContent[0].audioIndex
    m.top.transcodeParams = videoContent[0].transcodeparams
    m.chapters = videoContent[0].chapters
    m.overview = videoContent[0].overview
    m.trickplay = videoContent[0].trickplay
    m.top.showID = videoContent[0].showID
    m.mediaSegments = videoContent[0].mediaSegments
    m.osd.itemTitleText = m.top.content.title
    m.trickplayDataFinal = invalid
    if isValidAndNotEmpty(m.trickplay)
        trickplayData = m.trickplay.LookupCI(m.top.id)
        if isValidAndNotEmpty(trickplayData)
            m.trickplayDataFinal = trickplayData.lookupCI(trickplayData.keys()[0])
            if isValidAndNotEmpty(m.trickplayDataFinal)
                ' Convert interval to seconds
                m.iconInterval = m.trickplayDataFinal.Interval / 1000
                m.canUseFastReplace = (m.trickplayDataFinal.TileHeight * m.trickplayDataFinal.Height) * (m.trickplayDataFinal.TileWidth * m.trickplayDataFinal.Width) < 2000000
                m.PreloadTrickplayImagesTask.numImagesToLoad = fix(m.trickplayDataFinal.ThumbnailCount / (m.trickplayDataFinal.TileHeight * m.trickplayDataFinal.TileWidth))
                m.PreloadTrickplayImagesTask.trickplayWidth = m.trickplayDataFinal.Width
                m.PreloadTrickplayImagesTask.method = "ADD"
                m.PreloadTrickplayImagesTask.control = "RUN"
            end if
        end if
    end if
    ' If video is an episode, attempt to add season and episode numbers to OSD
    if m.top.content.contenttype = 4
        if isValid(videoContent[0].seasonNumber)
            m.osd.seasonNumber = videoContent[0].seasonNumber
        end if
        if isValid(videoContent[0].episodeNumber)
            m.osd.episodeNumber = videoContent[0].episodeNumber
        end if
        if isValid(videoContent[0].episodeNumberEnd)
            m.osd.episodeNumberEnd = videoContent[0].episodeNumberEnd
        end if
    end if
    ' Attempt to add logo to OSD
    if isValidAndNotEmpty(videoContent[0].logoImage)
        m.osd.logoImage = videoContent[0].logoImage
        ' Don't show both the logo and the video title if this isn't an episode or trailer
        if m.top.content.contenttype <> 4 and videoContent[0].extraType <> "trailer"
            m.osd.itemTitleText = ""
        end if
    end if
    populateChapterMenu()
    if m.LoadMetaDataTask.isIntro
        ' Disable trackplay bar for intro videos
        m.top.enableTrickPlay = false
    else
        ' Allow custom captions for non intro videos unless the video is being transcoded and burn subtitles are enabled
        m.top.allowCaptions = not (m.isTranscoded and burnInSubtitles)
    end if
    ' Allow default subtitles
    m.top.unobserveField("selectedSubtitle")
    ' Set subtitleTrack property if subs are natively supported by Roku
    selectedSubtitle = invalid
    updatedSubtitleData = []
    for each subtitle in m.top.fullSubtitleData
        if m.isTranscoded and burnInSubtitles
            subtitle.IsEncoded = true
            updatedSubtitleData.push(subtitle)
        end if
        if subtitle.Index = videoContent[0].selectedSubtitle
            selectedSubtitle = subtitle
            exit for
        end if
    end for
    if m.isTranscoded and burnInSubtitles
        m.top.fullSubtitleData = updatedSubtitleData
        m.top.globalCaptionMode = "Off"
    end if
    if isValid(selectedSubtitle)
        availableSubtitleTrackIndex = availSubtitleTrackIdx(selectedSubtitle.Track.TrackName)
        if availableSubtitleTrackIndex <> -1
            if not selectedSubtitle.IsEncoded
                if selectedSubtitle.IsForced
                    ' If IsForced, make sure to remember the Roku global setting so we can set it back when the video is done playing.
                    m.originalClosedCaptionState = m.top.globalCaptionMode
                end if
                m.top.globalCaptionMode = "On"
                m.top.subtitleTrack = m.top.availableSubtitleTracks[availableSubtitleTrackIndex].TrackName
            end if
        end if
    end if
    if not (m.isTranscoded and burnInSubtitles)
        m.top.selectedSubtitle = videoContent[0].selectedSubtitle
    end if
    m.top.observeField("selectedSubtitle", "onSubtitleChange")
    if isValid(m.top.audioIndex)
        m.top.audioTrack = m.top.audioIndex.toStr()
    else
        m.top.audioTrack = "2"
    end if
    m.top.setFocus(true)
    m.top.control = "PLAY"
end sub

sub displayTrickplayImage(trickPosition as integer)
    if not isValid(m.trickplayDataFinal) then
        return
    end if
    ' Index of trickplay image that matches seek timestamp - out of all trickplay images
    iconIndex = fix(trickPosition / m.iconInterval)
    ' Index of tileset that trickplay image is located in
    tileIndex = Fix(iconIndex / (m.trickplayDataFinal.TileHeight * m.trickplayDataFinal.TileWidth))
    ' Index of trickplay image within tileset
    tileIconIndex = iconIndex - (tileIndex * (m.trickplayDataFinal.TileHeight * m.trickplayDataFinal.TileWidth))
    ' Index of row trickplay image is on within tileset
    iconRow = fix(tileIconIndex / m.trickplayDataFinal.TileHeight)
    ' Index of column trickplay image is on within tileset
    iconColumn = tileIconIndex mod m.trickplayDataFinal.TileWidth
    ' Translation values for trickplay images
    offsetHoriz = 100
    offsetVert = 900 - m.trickplayDataFinal.Height
    ' If we can get translation data for the trickplaybar's thumb icon, use it so the trickplay images can move left/right with seeking
    if isValid(m.positionTranslation)
        if m.positionTranslation.translation[0] = 0 then
            return
        end if
        offsetHoriz = m.positionTranslation.translation[0] - 50
    end if
    if offsetHoriz < 0 then
        offsetHoriz = 0
    end if
    trickplayImage = m.top.findNode("trickplayImage")
    ' Trickplayimage node doesn't exist, create it
    if not isValid(trickplayImage)
        newTrickplayImage = createObject("roSGNode", "Poster")
        newTrickplayImage.uri = ("tmp:/" + bslib_toString(m.top.id) + "-" + bslib_toString(tileIndex) + ".jpg")
        newTrickplayImage.id = "trickplayImage"
        newTrickplayImage.loadDisplayMode = "noScale"
        newTrickplayImage.height = m.trickplayDataFinal.Height * m.trickplayDataFinal.TileHeight
        newTrickplayImage.width = m.trickplayDataFinal.Width * m.trickplayDataFinal.TileWidth
        newTrickplayImage.translation = ("[" + bslib_toString(offsetHoriz - (iconColumn * m.trickplayDataFinal.Width)) + ",  " + bslib_toString(offsetVert - (iconRow * m.trickplayDataFinal.Height)) + "]")
        newTrickplayImage.clippingRect = ("[" + bslib_toString(iconColumn * m.trickplayDataFinal.Width) + ", " + bslib_toString(iconRow * m.trickplayDataFinal.Height) + ", " + bslib_toString(m.trickplayDataFinal.Width) + ", " + bslib_toString(m.trickplayDataFinal.Height) + "]")
        m.top.appendChild(newTrickplayImage)
        return
    end if
    ' If we've changed tiles, remove existing trickplayImage node
    ' Otherwise loading the next image will fail. 'cause Roku.
    if trickplayImage.uri <> ("tmp:/" + bslib_toString(m.top.id) + "-" + bslib_toString(tileIndex) + ".jpg")
        if not m.canUseFastReplace
            m.top.removeChild(trickplayImage)
            return
        end if
        trickplayImage.uri = ("tmp:/" + bslib_toString(m.top.id) + "-" + bslib_toString(tileIndex) + ".jpg")
    end if
    ' Move clippingRect to next trickplay image within tileset - offsetting translation by an equal amount so it doesn't move
    trickplayImage.translation = ("[" + bslib_toString(offsetHoriz - (iconColumn * m.trickplayDataFinal.Width)) + ",  " + bslib_toString(offsetVert - (iconRow * m.trickplayDataFinal.Height)) + "]")
    trickplayImage.clippingRect = ("[" + bslib_toString(iconColumn * m.trickplayDataFinal.Width) + ", " + bslib_toString(iconRow * m.trickplayDataFinal.Height) + ", " + bslib_toString(m.trickplayDataFinal.Width) + ", " + bslib_toString(m.trickplayDataFinal.Height) + "]")
end sub

' populateChapterMenu: ' Parse chapter data from API and appeand to chapter list menu
'
sub populateChapterMenu()
    ' Clear any existing chapter list data
    m.chapterContent.clear()
    if not isValidAndNotEmpty(m.chapters)
        chapterItem = CreateObject("roSGNode", "ContentNode")
        chapterItem.title = tr("No Chapter Data Found")
        chapterItem.playstart = m.playbackEnum.null
        m.chapterContent.appendChild(chapterItem)
        return
    end if
    for each chapter in m.chapters
        chapterItem = CreateObject("roSGNode", "ContentNode")
        chapterItem.title = chapter.Name
        chapterItem.playstart = chapter.StartPositionTicks / 10000000#
        m.chapterContent.appendChild(chapterItem)
    end for
end sub

' Event handler for when video content field changes
sub onContentChange()
    if not isValid(m.top.content) then
        return
    end if
    m.top.observeField("position", "onPositionChanged")
end sub

sub onNextEpisodeDataLoaded()
    m.checkedForNextEpisode = true
    ' If there is no next episode, disable next episode button
    if m.getNextEpisodeTask.nextEpisodeData.Items.count() <> 2
        m.nextupbuttonseconds = 0
    end if
end sub

sub hideSegmentSkipButton()
    m.currentSegmentEndTicks = 0
    m.currentSegmentType = invalid
    m.skipSegmentButton.visible = false
    m.skipSegmentButton.text = ""
    m.skipSegmentButton.setFocus(false)
    m.skipSegmentButton.focus = false
    hideNextItem()
    m.top.setFocus(true)
end sub

sub displaySegmentSkipButton(segmentType as string, endticks as double)
    m.currentSegmentEndTicks = endticks
    m.currentSegmentType = segmentType
    if isValidAndNotEmpty(m.mediaSegmentDismissed) and m.mediaSegmentDismissed.DoesExist(m.currentSegmentType) then
        return
    end if
    ' Check if user has specific instructions for this media segment type
    userSetting = m.global.session.user.settings[("playback.mediasegments." + bslib_toString(segmentType))]
    if isValid(userSetting)
        ' User doesn't want anything to happen for this media segment type
        if isStringEqual(userSetting, "none") then
            return
        end if
        ' User wants to auto-skip this media segment type
        if isStringEqual(userSetting, "skip")
            skipCurrentSegment()
            return
        end if
    end if
    ' Check if button is already showing
    if isStringEqual(m.skipSegmentButton.text, tr(("Skip " + bslib_toString(segmentType)))) then
        return
    end if
    if m.osd.visible then
        return
    end if ' Don't show if OSD is visible
    if isStringEqual(segmentType, "outro")
        if m.nextupbuttonseconds = 0 then
            return
        end if ' is the button disabled?
        displayNextItem()
    end if
    m.skipSegmentButton.visible = true
    m.skipSegmentButton.text = tr(("Skip " + bslib_toString(segmentType)))
    m.skipSegmentButton.setFocus(true)
    m.skipSegmentButton.focus = true
end sub

sub hideNextItem()
    m.nextUp.visible = false
end sub

sub displayNextItem()
    ' Disable for mixed playlists
    if m.global.queueManager.callFunc("getQueueUniqueTypes").count() <> 1 then
        return
    end if
    ' Disable if we're at the end of the queue
    if m.global.queueManager.callFunc("getPosition") >= m.global.queueManager.callFunc("getCount") - 1 then
        return
    end if
    ' Only show if next in queue is an episode
    currentQueuePosition = m.global.queueManager.callFunc("getPosition")
    nextItem = m.global.queueManager.callFunc("getItemByIndex", currentQueuePosition + 1)
    if not isValid(nextItem) then
        return
    end if
    if not isStringEqual(nextItem.lookupCI("Type"), "episode") then
        return
    end if
    if m.nextUpInfoLoaded
        m.nextUp.visible = true
        return
    end if
    imageTags = nextItem.lookupCI("ImageTags")
    nextItemPoster = m.top.findNode("nextItemPoster")
    if isValid(nextItemPoster)
        nextItemPoster.uri = ImageURL(nextItem.lookupCI("id"), "Primary", {
            "maxHeight": 124
            "maxWidth": 150
            "Tag": chainLookupReturn(imageTags, "Primary", ("cacheBuster" + bslib_toString(rnd(99999))))
        })
    end if
    nextItemSeriesTitle = m.top.findNode("nextItemSeriesTitle")
    if isValid(nextItemSeriesTitle)
        nextItemSeriesTitle.font.size = 25
        nextItemSeriesTitle.text = nextItem.lookupCI("SeriesName")
    end if
    nextItemEpisodeTitle = m.top.findNode("nextItemEpisodeTitle")
    if isValid(nextItemEpisodeTitle)
        seasonName = (function(nextItem)
                __bsConsequent = nextItem.lookupCI("SeasonName")
                if __bsConsequent <> invalid then
                    return __bsConsequent
                else
                    return ""
                end if
            end function)(nextItem)
        seasonName = seasonName.Replace("Season ", "S")
        if isValid(nextItem.lookupCI("IndexNumber")) then
            episodeNumber = ("E" + bslib_toString(nextItem.lookupCI("IndexNumber")))
        else
            episodeNumber = ""
        end if
        nextItemEpisodeTitle.font.size = 22
        nextItemEpisodeTitle.text = (bslib_toString(seasonName) + bslib_toString(episodeNumber) + " - " + bslib_toString(nextItem.lookupCI("name")))
    end if
    m.nextUp.visible = true
    m.nextUpInfoLoaded = true
end sub

sub checkSegmentSkipButton()
    if not isValidAndNotEmpty(m.mediaSegments) then
        return
    end if
    matchFound = false
    currentPositionTicks = int(m.top.position) * 10000000&
    for i = 0 to m.mediaSegments.TotalRecordCount - 1
        mediaSegment = m.mediaSegments.items[i]
        if currentPositionTicks < mediaSegment.StartTicks then
            continue for
        end if
        ' Don't display skip button if we are within 5 seconds of the segment end time
        if currentPositionTicks >= (mediaSegment.EndTicks - 50000000) then
            continue for
        end if
        ' Current position is between media segment's start and end ticks. Display a skip button
        displaySegmentSkipButton(mediaSegment.type, mediaSegment.EndTicks)
        matchFound = true
        exit for
    end for
    ' Check if no match was found but the skip segment button is visible
    if not matchFound
        if m.skipSegmentButton.visible
            hideSegmentSkipButton()
        end if
    end if
end sub

' When Video Player state changes
sub onPositionChanged()
    ' Pass video position data into OSD
    if m.top.duration = 0
        m.osd.progressPercentage = 0
    else
        m.osd.progressPercentage = m.top.position / m.top.duration
    end if
    ' Ensure position text is accurate
    m.positionText.text = secondsToHuman(m.top.position, true)
    m.osd.positionTime = m.top.position
    m.osd.remainingPositionTime = m.top.duration - m.top.position
    ' Update the caption task playback position.
    ' The position is calculated in milliseconds based on the current
    ' video playback position plus the configured subtitle offset.
    if isValid(m.captionTask)
        newPos = Int(m.top.position * 1000) + m.subtitleOffset
        m.captionTask.currentPos = newPos
    end if
    ' Check if dialog is open
    m.dialog = m.top.getScene().findNode("dialogBackground")
    if not isValid(m.dialog)
        ' Do not show Next Episode button for intro videos
        if not m.LoadMetaDataTask.isIntro
            checkSegmentSkipButton()
        end if
    end if
end sub

'
' When Video Player state changes
sub onState(msg)
    if isValid(m.captionTask)
        m.captionTask.playerState = m.top.state + m.top.globalCaptionMode
    end if
    ' Pass video state into OSD
    m.osd.playbackState = m.top.state
    ' When buffering, start timer to monitor buffering process
    if isStringEqual(m.top.state, "buffering") and m.bufferCheckTimer <> invalid
        ' start timer
        m.bufferCheckTimer.control = "start"
        m.bufferCheckTimer.ObserveField("fire", "bufferCheck")
    else if isStringEqual(m.top.state, "error")
        print "Error: " m.top.errorCode, m.top.errorMsg, " ErrorStr: " m.top.errorStr
        print m.top.errorInfo
        if not m.playReported and m.top.transcodeAvailable
            m.top.retryWithTranscoding = true ' If playback was not reported, retry with transcoding
            ' Stop playback and exit player
            m.top.control = "STOP"
            m.top.backPressed = true
        else if not m.playReported and m.top.content.live
            if m.playbackRetries < 3
                print "Live TV playback failed - retrying with remux forced"
                m.playbackRetries = m.playbackRetries + 1
                m.global.queueManager.callFunc("setForceTranscode", "forceLiveTvRemux")
                m.top.control = "STOP"
                m.LoadMetaDataTask.itemId = m.top.id
                m.LoadMetaDataTask.observeField("content", "onVideoContentLoaded")
                m.LoadMetaDataTask.control = "RUN"
            else
                print "Live TV playback failed after " + m.playbackRetries.ToStr() + " attempts - showing error and exiting"
                showPlaybackErrorDialog(tr("Live TV Playback Failed"))
                ' Stop playback and exit player
                m.top.control = "STOP"
                m.top.backPressed = true
                return
            end if
        else
            ' Reset retry counter if more than 30 seconds have passed since last error
            currentTime = CreateObject("roDateTime").AsSeconds()
            if m.playbackRetries > 0 and (currentTime - m.lastBufferError) > 30
                print "Playback stabilized - resetting retry count from " + m.playbackRetries.ToStr()
                m.playbackRetries = 0
            end if
            ' Attempt to retry playback up to REPLAY_RETRIES times before showing error
            if m.playbackRetries < 3
                m.playbackRetries = m.playbackRetries + 1
                m.lastBufferError = currentTime
                print "Player error encountered - retry attempt " + m.playbackRetries.ToStr() + " of " + 3.ToStr()
                ' Stop and restart playback from current position
                currentPosition = m.top.position
                m.top.control = "STOP"
                m.top.seek = currentPosition
                m.top.control = "PLAY"
            else
                ' All retries exhausted, show error and exit
                print "Playback failed after " + 3.ToStr() + " retry attempts"
                showPlaybackErrorDialog(tr("Error During Playback"))
                ' Stop playback and exit player
                m.top.control = "STOP"
                m.top.backPressed = true
            end if
        end if
    else if isStringEqual(m.top.state, "playing")
        ' Reset retry counter when playback is successful
        if m.playbackRetries > 0
            print "Playback resumed successfully after retry"
            m.playbackRetries = 0
            m.bufferCheckTimer.duration = 30
        end if
        ' Check if next episode is available
        if isValid(m.top.showID)
            if m.top.showID <> "" and not m.checkedForNextEpisode and m.top.content.contenttype = 4
                m.getNextEpisodeTask.showID = m.top.showID
                m.getNextEpisodeTask.videoID = m.top.id
                m.getNextEpisodeTask.control = "RUN"
            end if
        end if
        if m.playReported = false
            ReportPlayback("start")
            m.playReported = true
        else
            ReportPlayback()
        end if
        m.playbackTimer.control = "start"
    else if isStringEqual(m.top.state, "paused")
        m.playbackTimer.control = "stop"
        ReportPlayback()
    else if isStringEqual(m.top.state, "stopped")
        m.playbackTimer.control = "stop"
        ReportPlayback("stop")
        m.playReported = false
    else if isStringEqual(m.top.state, "finished")
        m.playbackTimer.control = "stop"
        ReportPlayback("stop")
        m.playReported = false
    end if
end sub

sub onTrickPlayBarVisibleChange()
    trickplayImage = m.top.findNode("trickplayImage")
    if isValid(trickplayImage)
        trickplayImage.visible = m.top.trickPlayBar.visible
    end if
    if not m.top.content.live
        if isValid(m.videoEndingTime)
            m.videoEndingTime.visible = m.top.trickPlayBar.visible
        end if
    end if
    ' Don't show both the trickplay bar and the skip segment button at the same time
    if m.top.trickPlayBar.visible
        if m.skipSegmentButton.visible
            hideSegmentSkipButton()
        end if
    end if
end sub

sub setVideoEndingTime(videoSeekPosition = 0 as integer)
    m.clock = m.osd.findNode("clock")
    if not isValid(m.clock) then
        return
    end if
    if not isValid(m.top.content) then
        return
    end if
    if m.top.content.live then
        return
    end if
    currentTime = m.clock.callFunc("getCurrentTime")
    remainingTime = getremainingTime(videoSeekPosition)
    videoEndingTime = m.clock.callFunc("getFormattedTime", (currentTime + remainingTime), false)
    m.videoEndingTime.text = videoEndingTime
    m.osd.videoEndingTime = videoEndingTime
end sub

function getRemainingTime(videoSeekPosition = 0 as integer)
    if not isChainValid(m.positionText, "text")
        return m.top.duration - m.top.position
    end if
    seekTime = 0#
    seekPosition = m.positionText.text.split(":")
    if seekPosition.count() = 3
        ' hours -> seconds
        seekTime += seekPosition[0].toint() * 3600
        ' minutes -> seconds
        seekTime += seekPosition[1].toint() * 60
    end if
    ' minutes -> seconds
    if seekPosition.count() = 2
        seekTime += seekPosition[0].toint() * 60
    end if
    ' add seconds
    seekTime += seekPosition[seekPosition.count() - 1].toint()
    if videoSeekPosition > 0
        seekTime = videoSeekPosition
    end if
    if seekTime = 0 then
        seekTime = m.top.position
    else
        seekTime = seekTime
    end if
    return m.top.duration - seekTime
end function

sub onTrickPlayBarTextChange()
    if not m.top.trickPlayBar.visible then
        return
    end if
    m.nextupbuttonseconds = m.global.session.user.settings["playback.nextupbuttonseconds"].ToInt()
    m.currentSegmentType = invalid
    m.mediaSegmentDismissed = {}
    setVideoEndingTime(0)
    ' If Roku has pulled thumbnailtiles from the video stream, use them instead
    if not m.global.session.user.settings["playback.trickplay.forcecustom"]
        if isValidAndNotEmpty(m.top.thumbnailTiles)
            return
        end if
    end if
    if not isValid(m.positionText)
        displayTrickplayImage(m.top.position)
        return
    end if
    seekTime = 0
    seekPosition = m.positionText.text.split(":")
    if seekPosition.count() = 3
        ' hours -> seconds
        seekTime += seekPosition[0].toint() * 3600
        ' minutes -> seconds
        seekTime += seekPosition[1].toint() * 60
    end if
    ' minutes -> seconds
    if seekPosition.count() = 2
        seekTime += seekPosition[0].toint() * 60
    end if
    ' add seconds
    seekTime += seekPosition[seekPosition.count() - 1].toint()
    if seekTime = 0 then
        seekTime = m.top.position
    else
        seekTime = seekTime
    end if
    displayTrickplayImage(seekTime)
end sub

'
' Report playback to server
sub ReportPlayback(state = "update" as string)
    if m.top.position = invalid then
        return
    end if
    params = {
        "ItemId": m.top.id
        "PlaySessionId": m.top.PlaySessionId
        "PositionTicks": int(m.top.position) * 10000000& 'Ensure a LongInteger is used
        "IsPaused": isStringEqual(m.top.state, "paused")
    }
    if isValid(m.top.content) and isValid(m.top.content.live) and m.top.content.live
        params.append({
            "MediaSourceId": m.top.transcodeParams.MediaSourceId
            "LiveStreamId": m.top.transcodeParams.LiveStreamId
        })
        m.bufferCheckTimer.duration = 30
    end if
    if inArray([
        "stop"
        "finished"
    ], state) and isValid(m.originalClosedCaptionState)
        m.top.globalCaptionMode = m.originalClosedCaptionState
        m.originalClosedCaptionState = invalid
    end if
    ' Report playstate via worker task
    playstateTask = m.global.playstateTask
    playstateTask.setFields({
        status: state
        params: params
    })
    playstateTask.control = "RUN"
end sub

'
' Check the the buffering has not hung
sub bufferCheck(msg)
    if m.top.state <> "buffering"
        ' If video is not buffering, stop timer
        m.bufferCheckTimer.control = "stop"
        m.bufferCheckTimer.unobserveField("fire")
        return
    end if
    if m.top.bufferingStatus <> invalid
        ' Check that the buffering percentage is increasing
        if m.top.bufferingStatus["percentage"] > m.bufferPercentage
            m.bufferPercentage = m.top.bufferingStatus["percentage"]
            ' Reset retry counter if buffering is progressing
            if m.playbackRetries > 0
                m.playbackRetries = 0
                m.bufferCheckTimer.duration = 30
            end if
        else if m.top.content.live = true
            m.top.callFunc("refresh")
        else
            ' Reset retry counter if more than 30 seconds have passed since last error
            currentTime = CreateObject("roDateTime").AsSeconds()
            if m.playbackRetries > 0 and (currentTime - m.lastBufferError) > 30
                print "Buffer stabilized - resetting retry count from " + m.playbackRetries.ToStr()
                m.playbackRetries = 0
                m.bufferCheckTimer.duration = 30
            end if
            ' Attempt to retry playback up to REPLAY_RETRIES times
            if m.playbackRetries < 3
                m.playbackRetries = m.playbackRetries + 1
                m.lastBufferError = currentTime
                print "Buffering stalled - retry attempt " + m.playbackRetries.ToStr() + " of " + 3.ToStr()
                ' Extend buffer check duration for subsequent retries to allow more time
                m.bufferCheckTimer.duration = 30 + (m.playbackRetries * 15)
                ' Stop and restart playback from current position
                currentPosition = m.top.position
                m.top.control = "STOP"
                m.top.seek = currentPosition
                m.top.control = "PLAY"
            else
                ' All retries exhausted, show error
                print "Buffering failed after " + 3.ToStr() + " retry attempts"
                showPlaybackErrorDialog(tr("There was an error retrieving the data for this item from the server."))
                ' Stop playback and exit player
                m.top.control = "STOP"
                m.top.backPressed = true
            end if
        end if
    end if
end sub

' stateAllowsOSD: Check if current video state allows showing the OSD
'
' @return {boolean} indicating if video state allows the OSD to show
function stateAllowsOSD() as boolean
    validStates = [
        "playing"
        "paused"
        "stopped"
    ]
    return inArray(validStates, m.top.state)
end function

' availSubtitleTrackIdx: Returns Roku's index for requested subtitle track
'
' @param {string} tracknameToFind - TrackName for subtitle we're looking to match
' @return {integer} indicating Roku's index for requested subtitle track. Returns SubtitleSelection.NONE if not found
function availSubtitleTrackIdx(tracknameToFind as string) as integer
    idx = 0
    for each availTrack in m.top.availableSubtitleTracks
        ' The TrackName must contain the URL we supplied originally, though
        ' Roku mangles the name a bit, so we check if the URL is a substring, rather
        ' than strict equality
        if Instr(1, availTrack.TrackName, tracknameToFind)
            return idx
        end if
        idx = idx + 1
    end for
    return -1
end function

sub skipCurrentSegment()
    seekPosition = m.currentSegmentEndTicks / 10000000#
    if seekPosition > (m.top.duration - 2)
        if m.global.queueManager.callFunc("getPosition") < m.global.queueManager.callFunc("getCount") - 1
            handleItemSkipAction("itemnext")
            return
        else
            seekPosition = m.top.duration - 1
        end if
    end if
    m.top.seek = seekPosition
end sub

sub onProgramDetailsLoaded()
    ' CurrentProgram can be invalid if we're coming from search results for a show that is not currently airing
    if not isChainValid(m.LoadProgramDetailsTask, "programDetails.json.CurrentProgram") then
        return
    end if
    titleText = ""
    if isValidAndNotEmpty(m.LoadProgramDetailsTask.programDetails.json.CurrentProgram.ChannelNumber)
        titleText += (bslib_toString(tr("CH")) + " " + bslib_toString(m.LoadProgramDetailsTask.programDetails.json.CurrentProgram.ChannelNumber) + " ")
    end if
    if isValidAndNotEmpty(m.LoadProgramDetailsTask.programDetails.json.CurrentProgram.Name)
        titleText += m.LoadProgramDetailsTask.programDetails.json.CurrentProgram.Name
    end if
    m.osd.itemTitleText = titleText
    if isValidAndNotEmpty(m.LoadProgramDetailsTask.programDetails.json.CurrentProgram.EpisodeTitle)
        m.osd.itemSubtitleText = m.LoadProgramDetailsTask.programDetails.json.CurrentProgram.EpisodeTitle
    else
        m.osd.itemSubtitleText = ""
    end if
    m.overview = m.LoadProgramDetailsTask.programDetails.json.CurrentProgram.Overview
end sub

sub showOSD()
    m.osd.visible = true
    m.osd.hasFocus = true
    m.osd.setFocus(true)
end sub

sub positionChapterList()
    optionControls = m.osd.findNode("optionControls")
    chapterList = m.top.findNode("chapterList")
    if optionControls = invalid or chapterList = invalid
        return
    end if
    optionControlsRect = optionControls.boundingRect()
    chapterList.translation = [
        optionControlsRect.x
        optionControlsRect.y + optionControlsRect.height
    ]
end sub

sub refreshLiveOSDContent()
    if not m.top.content.live then
        return
    end if
    m.LoadProgramDetailsTask.programId = m.top.id
    m.LoadProgramDetailsTask.control = "RUN"
end sub

sub changeSubtitleTimeOffset(offsetAmount as integer)
    ' If the subtitles are 60+ seconds off, the user needs to get better subtitles
    if abs(m.subtitleOffset + offsetAmount) >= 60000 then
        return
    end if
    m.subtitleOffset += offsetAmount
    m.subtitleSyncValue.text = (bslib_toString(tr("Current Offset")) + ": " + bslib_toString(m.subtitleOffset.toStr()) + " ms")
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if m.subtitleTimingButtons.visible
        if m.subtitleTimingButtons.isInFocusChain()
            if not press then
                return false
            end if
            if isStringEqual(key, "right")
                if m.subtitleSyncMinus500.hasfocus()
                    m.subtitleSyncMinus500.focus = false
                    m.subtitleSyncMinus100.focus = true
                    m.subtitleSyncMinus100.setfocus(true)
                    return true
                end if
                if m.subtitleSyncMinus100.hasfocus()
                    m.subtitleSyncMinus100.focus = false
                    m.subtitleSyncPlus100.focus = true
                    m.subtitleSyncPlus100.setfocus(true)
                    return true
                end if
                if m.subtitleSyncPlus100.hasfocus()
                    m.subtitleSyncPlus100.focus = false
                    m.subtitleSyncPlus500.focus = true
                    m.subtitleSyncPlus500.setfocus(true)
                    return true
                end if
                if m.subtitleSyncPlus500.hasfocus()
                    m.subtitleSyncPlus500.focus = false
                    m.subtitleSyncReset.focus = true
                    m.subtitleSyncReset.setfocus(true)
                    return true
                end if
            end if
            if isStringEqual(key, "left")
                if m.subtitleSyncMinus100.hasfocus()
                    m.subtitleSyncMinus100.focus = false
                    m.subtitleSyncMinus500.focus = true
                    m.subtitleSyncMinus500.setfocus(true)
                    return true
                end if
                if m.subtitleSyncPlus100.hasfocus()
                    m.subtitleSyncPlus100.focus = false
                    m.subtitleSyncminus100.focus = true
                    m.subtitleSyncMinus100.setfocus(true)
                    return true
                end if
                if m.subtitleSyncPlus500.hasfocus()
                    m.subtitleSyncPlus500.focus = false
                    m.subtitleSyncPlus100.focus = true
                    m.subtitleSyncPlus100.setfocus(true)
                    return true
                end if
                if m.subtitleSyncReset.hasfocus()
                    m.subtitleSyncReset.focus = false
                    m.subtitleSyncPlus500.focus = true
                    m.subtitleSyncPlus500.setfocus(true)
                    return true
                end if
            end if
            if isStringEqual(key, "OK")
                if m.subtitleSyncReset.hasfocus()
                    changeSubtitleTimeOffset((function(__bsCondition, abs, m)
                            if __bsCondition then
                                return - m.subtitleOffset
                            else
                                return abs(m.subtitleOffset)
                            end if
                        end function)(m.subtitleOffset > 0, abs, m))
                    return true
                end if
                if m.subtitleSyncMinus100.hasfocus()
                    changeSubtitleTimeOffset(-100)
                    return true
                end if
                if m.subtitleSyncMinus500.hasfocus()
                    changeSubtitleTimeOffset(-500)
                    return true
                end if
                if m.subtitleSyncPlus100.hasfocus()
                    changeSubtitleTimeOffset(100)
                    return true
                end if
                if m.subtitleSyncPlus500.hasfocus()
                    changeSubtitleTimeOffset(500)
                    return true
                end if
            end if
            hidesyncmenuAction()
            return true
        end if
    end if
    ' Keypress handler while user is inside the chapter menu
    if m.chapterMenu.hasFocus()
        if not press then
            return false
        end if
        if key = "OK"
            focusedChapter = m.chapterMenu.itemFocused
            selectedChapter = m.chapterMenu.content.getChild(focusedChapter)
            seekTime = selectedChapter.playstart
            ' Don't seek if user clicked on No Chapter Data
            if seekTime = m.playbackEnum.null then
                return true
            end if
            m.top.seek = seekTime
            m.positionText.text = secondsToHuman(seekTime, true)
            return true
        end if
        if key = "back"
            m.chapterList.visible = false
            m.osd.showChapterList = false
            m.chapterMenu.setFocus(false)
            m.osd.hasFocus = true
            m.osd.setFocus(true)
            return true
        end if
        if key = "play"
            handleVideoPlayPauseAction()
        end if
        return true
    end if
    if m.skipSegmentButton.hasfocus() and not m.top.trickPlayBar.visible
        if not press then
            return false
        end if
        if key = "OK"
            skipCurrentSegment()
            hideSegmentSkipButton()
            return true
        end if
    end if
    if not press then
        return false
    end if
    if key = "down" and not m.top.trickPlayBar.visible
        if not m.LoadMetaDataTask.isIntro
            ' Don't allow user to open menu prior to video loading
            if not stateAllowsOSD() then
                return true
            end if
            setSiblingData()
            if m.skipSegmentButton.visible
                hideSegmentSkipButton()
            end if
            refreshLiveOSDContent()
            showOSD()
            return true
        end if
    else if key = "up" and not m.top.trickPlayBar.visible
        if not m.LoadMetaDataTask.isIntro
            ' Don't allow user to open menu prior to video loading
            if not stateAllowsOSD() then
                return true
            end if
            setSiblingData()
            if m.skipSegmentButton.visible
                hideSegmentSkipButton()
            end if
            refreshLiveOSDContent()
            showOSD()
            return true
        end if
    else if key = "OK" and not m.top.trickPlayBar.visible
        if not m.LoadMetaDataTask.isIntro
            ' Don't allow user to open menu prior to video loading
            if not stateAllowsOSD() then
                return true
            end if
            ' Show OSD, but don't pause video
            setSiblingData()
            if m.skipSegmentButton.visible
                hideSegmentSkipButton()
            end if
            refreshLiveOSDContent()
            showOSD()
            return true
        end if
        return false
    end if
    ' Disable OSD for intro videos
    if not m.LoadMetaDataTask.isIntro
        if key = "play" and not m.top.trickPlayBar.visible
            ' Don't allow user to open menu prior to video loading
            if not stateAllowsOSD() then
                return true
            end if
            ' If video is paused, resume it and don't show OSD
            if m.top.state = "paused"
                m.top.control = "RESUME"
                return true
            end if
            ' Pause video and show OSD
            m.top.control = "PAUSE"
            setSiblingData()
            if m.skipSegmentButton.visible
                hideSegmentSkipButton()
            end if
            refreshLiveOSDContent()
            showOSD()
            return true
        end if
    end if
    if key = "back"
        ' If user presses back when any segment skip button is showing, hide button and disable it so it doesn't show again
        if m.skipSegmentButton.visible
            if isValid(m.currentSegmentType)
                m.mediaSegmentDismissed[m.currentSegmentType] = true
            end if
            hideSegmentSkipButton()
            return true
        end if
        m.PreloadTrickplayImagesTask.method = "REMOVE"
        m.PreloadTrickplayImagesTask.control = "RUN"
        currentTimeTimer = m.clock.findNode("currentTimeTimer")
        if isValid(currentTimeTimer) then
            currentTimeTimer.control = "stop"
        end if
        m.global.queueManager.callFunc("bypassNextPreferredAudioTrackIndexReset")
        m.global.queueManager.callFunc("clear")
        m.top.control = "STOP"
    end if
    return false
end function
'//# sourceMappingURL=./VideoPlayerView.brs.map