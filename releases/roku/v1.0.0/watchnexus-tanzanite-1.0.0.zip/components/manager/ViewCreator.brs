'import "pkg:/source/enums/MediaPlaybackState.bs"
'import "pkg:/source/enums/SubtitleSelection.bs"
'import "pkg:/source/enums/TaskControl.bs"
'import "pkg:/source/enums/TimerControl.bs"
'import "pkg:/source/enums/VideoControl.bs"


' Play Audio
sub CreateAudioPlayerView()
    if m.global.audioPlayer.id <> m.global.queueManager.callFunc("getCurrentItem").id
        m.global.audioPlayer.id = invalid
        m.global.audioPlayer.id = m.global.queueManager.callFunc("getCurrentItem").id
    end if
    ' Only bypass creating an audio player view if the current queue is only audio
    if m.global.queueManager.callFunc("getQueueUniqueTypes").count() = 1
        if audioMiniPlayerIsVisible(m.top) then
            return
        end if
    end if
    m.view = CreateObject("roSGNode", "AudioPlayerView")
    m.view.observeField("state", "onStateChange")
    m.global.sceneManager.callFunc("pushScene", m.view)
end sub

' Play Audio
sub JumpIntoAudioPlayerView()
    m.view = CreateObject("roSGNode", "AudioPlayerView")
    ' Hide the mini player
    if audioMiniPlayerIsVisible(m.view)
        m.audioMiniPlayer.callFunc("setVisible", false)
    end if
    m.view.returnOnStop = true
    m.global.sceneManager.callFunc("pushScene", m.view)
end sub

' Play Video
sub CreateVideoPlayerView()
    m.playbackData = {}
    m.selectedSubtitle = {}
    ' Hide the mini player if needed
    if audioMiniPlayerIsVisible(m.top)
        m.audioMiniPlayer.callFunc("setVisible", false)
    end if
    ' If we're playing audio, stop it
    if m.global.audioPlayer.state = "playing"
        m.global.audioPlayer.control = "STOP"
    end if
    ' If the user has set a preferred audio track index, use it
    preferredAudioTrackIndex = m.global.queueManager.callFunc("getPreferredAudioTrackIndex")
    if preferredAudioTrackIndex < 0 then
        preferredAudioTrackIndex = 0
    end if
    m.global.queueManager.callFunc("setSelectedAudioStreamIndex", preferredAudioTrackIndex)
    m.view = CreateObject("roSGNode", "VideoPlayerView")
    m.view.observeField("state", "onStateChange")
    m.view.observeField("selectPlaybackInfoPressed", "onSelectPlaybackInfoPressed")
    m.view.observeField("selectSubtitlePressed", "onSelectSubtitlePressed")
    m.view.observeField("selectAudioPressed", "onSelectAudioPressed")
    mediaSourceId = m.global.queueManager.callFunc("getCurrentItem").mediaSourceId
    if not isValid(mediaSourceId) or mediaSourceId = ""
        mediaSourceId = m.global.queueManager.callFunc("getCurrentItem").id
    end if
    m.getPlaybackInfoTask = createObject("roSGNode", "GetPlaybackInfoTask")
    m.getPlaybackInfoTask.videoID = mediaSourceId
    m.getPlaybackInfoTask.observeField("data", "onPlaybackInfoLoaded")
    m.global.sceneManager.callFunc("pushScene", m.view)
end sub
' -----------------
' Event Handlers
' -----------------

' onSelectAudioPressed: Display audio selection dialog
'
sub onSelectAudioPressed()
    preferredAudioTrackName = m.global.queueManager.callFunc("getPreferredAudioTrackName")
    audioData = {
        data: []
    }
    for each item in m.view.fullAudioData
        audioStreamItem = {
            "Index": item.Index
            "RokuTrackName": item.RokuTrackName
            "IsExternal": item.IsExternal
            "Track": {
                "description": item.DisplayTitle
            }
            "Type": "audioselection"
        }
        if isStringEqual(preferredAudioTrackName, "")
            if m.view.audioIndex = item.Index
                audioStreamItem.selected = true
            end if
        else
            if isStringEqual(item.RokuTrackName, preferredAudioTrackName)
                audioStreamItem.selected = true
            end if
        end if
        audioData.data.push(audioStreamItem)
    end for
    m.global.sceneManager.callFunc("radioDialog", tr("Select Audio"), audioData)
    m.global.sceneManager.observeField("returnData", "onSelectionMade")
end sub

' User requested subtitle selection popup
sub onSelectSubtitlePressed()
    subtitleData = {
        data: []
    }
    selectedSubtitleIsExternal = false
    for each item in m.view.fullSubtitleData
        item.type = "subtitleselection"
        if m.view.selectedSubtitle <> -1
            ' Subtitle is a track within the file
            if item.index = m.view.selectedSubtitle
                item.selected = true
                selectedSubtitleIsExternal = item.LookupCI("IsExternal")
            end if
        else
            ' Subtitle is from an external source
            availableSubtitleTrackIndex = availSubtitleTrackIdx(item.track.TrackName)
            if availableSubtitleTrackIndex <> -1
                ' Convert WatchNexus subtitle track name to Roku track name
                subtitleFullTrackName = m.view.availableSubtitleTracks[availableSubtitleTrackIndex].TrackName
                if subtitleFullTrackName = m.view.subtitleTrack
                    item.selected = true
                    selectedSubtitleIsExternal = item.LookupCI("IsExternal")
                end if
            end if
        end if
        item.StreamIndex = item.index
        ' Put the selected item at the top of the option list
        if isValid(item.selected) and item.selected
            subtitleData.data.Unshift(item)
        else
            subtitleData.data.push(item)
        end if
    end for
    ' Manually create the None option and place at top
    subtitleData.data.Unshift({
        "Index": -1
        "IsExternal": false
        "Track": {
            "description": "None"
        }
        "Type": "subtitleselection"
    })
    buttons = [
        tr("OK")
    ]
    if selectedSubtitleIsExternal
        if chainLookupReturn(m.global, "session.user.settings.`playback.subs.custom`", false)
            buttons.push(tr("Adjust Subtitle Timing"))
        end if
    end if
    m.global.sceneManager.callFunc("radioDialog", tr("Select Subtitles"), subtitleData, buttons)
    m.global.sceneManager.observeField("returnData", "onSelectionMade")
end sub

' User has selected something from the radioDialog popup
sub onSelectionMade()
    m.global.sceneManager.unobserveField("returnData")
    if not isValid(m.global.sceneManager.returnData) then
        return
    end if
    if not isValid(m.global.sceneManager.returnData.type) then
        return
    end if
    if LCase(m.global.sceneManager.returnData.type) = "subtitleselection"
        processSubtitleSelection()
        return
    end if
    if LCase(m.global.sceneManager.returnData.type) = "audioselection"
        processAudioSelection()
        return
    end if
end sub

' processAudioSelection: Audio track selection handler
'
sub processAudioSelection()
    selectedAudioTrack = m.global.sceneManager.returnData
    if not isChainValid(selectedAudioTrack, "index") then
        return
    end if
    m.global.queueManager.callFunc("setPreferredAudioTrackName", selectedAudioTrack.LookupCI("RokuTrackName"))
    for each audioTrack in m.view.availableAudioTracks
        if isStringEqual(audioTrack.LookupCI("name"), selectedAudioTrack.LookupCI("RokuTrackName"))
            m.global.queueManager.callFunc("setPreferredAudioTrackIndex", audioTrack.LookupCI("Track").toint())
            m.view.audioIndex = audioTrack.LookupCI("Track").toint()
            return
        end if
    end for
    m.global.queueManager.callFunc("setPreferredAudioTrackIndex", selectedAudioTrack.index)
    m.view.audioIndex = selectedAudioTrack.index
end sub

sub processSubtitleSelection()
    m.selectedSubtitle = m.global.sceneManager.returnData
    ' The selected encoded subtitle did not change.
    if m.view.selectedSubtitle <> -1 or m.selectedSubtitle.index <> -1
        if m.view.selectedSubtitle = m.selectedSubtitle.index then
            return
        end if
    end if
    ' The playbackData is now outdated and must be refreshed
    m.playbackData = invalid
    ' Find previously selected subtitle and identify if it was encoded
    for each item in m.view.fullSubtitleData
        if item.index = m.view.selectedSubtitle
            m.view.previousSubtitleWasEncoded = item.IsEncoded
            exit for
        end if
    end for
    if LCase(m.selectedSubtitle.track.description) = "none"
        m.view.globalCaptionMode = "Off"
        m.view.subtitleTrack = ""
        if m.view.selectedSubtitle <> -1
            m.view.selectedSubtitle = -1
        end if
        m.global.queueManager.callFunc("setPreferredSubtitleTrack", m.selectedSubtitle)
        return
    end if
    if m.selectedSubtitle.IsEncoded
        ' Roku can not natively display these subtitles, so turn off the caption mode on the device
        m.view.globalCaptionMode = "Off"
    else
        ' Roku can natively display these subtitles, ensure the caption mode on the device is on
        m.view.globalCaptionMode = "On"
        ' Roku may rearrange subtitle tracks. Look up track based on name to ensure we get the correct index
        availableSubtitleTrackIndex = availSubtitleTrackIdx(m.selectedSubtitle.Track.TrackName)
        if availableSubtitleTrackIndex = -1 then
            return
        end if
        m.view.subtitleTrack = m.view.availableSubtitleTracks[availableSubtitleTrackIndex].TrackName
    end if
    m.global.queueManager.callFunc("setPreferredSubtitleTrack", m.selectedSubtitle)
    m.view.selectedSubtitle = m.selectedSubtitle.Index
end sub

' User requested playback info
sub onSelectPlaybackInfoPressed()
    ' Check if we already have playback info and show it in a popup
    if isValid(m.playbackData) and isValid(m.playbackData.playbackinfo)
        m.global.sceneManager.callFunc("standardDialog", tr("Playback Info"), m.playbackData.playbackinfo)
        return
    end if
    m.getPlaybackInfoTask.control = "RUN"
end sub

' The playback info task has returned data
sub onPlaybackInfoLoaded()
    m.playbackData = m.getPlaybackInfoTask.data
    ' Check if we have playback info and show it in a popup
    if isValid(m.playbackData) and isValid(m.playbackData.playbackinfo)
        m.global.sceneManager.callFunc("standardDialog", tr("Playback Info"), m.playbackData.playbackinfo)
    end if
end sub

' Playback state change event handlers
sub onStateChange()
    ' If the state changed due to an error, we don't want to continue the queue
    if m.view.errorCode <> 0
        m.global.queueManager.callFunc("clear")
        return
    end if
    if LCase(m.view.state) = "finished"
        if isValid(m.view.returnOnStop)
            if m.view.returnOnStop then
                return
            end if
        end if
        ' Close any open dialogs
        if m.global.sceneManager.callFunc("isDialogOpen")
            m.global.sceneManager.callFunc("dismissDialog")
        end if
        ' Check if user chose not to continue to next episode
        currentView = m.global.sceneManager.callFunc("getActiveScene")
        if isChainValid(currentView, "disableNextEpisodeAutoPlay")
            if currentView.disableNextEpisodeAutoPlay
                m.global.queueManager.callFunc("bypassNextPreferredAudioTrackIndexReset")
                m.global.queueManager.callFunc("clear")
                ' Playback completed, return user to previous screen
                m.global.sceneManager.callFunc("popScene")
                m.global.audioPlayer.loopMode = ""
            end if
        end if
        ' If there is something next in the queue, play it
        if m.global.queueManager.callFunc("getPosition") < m.global.queueManager.callFunc("getCount") - 1
            stillwatchingPopupInactivityTime = chainLookupReturn(m.global.session, "user.settings.stillwatchingPopupInactivityTime", "0")
            if stillwatchingPopupInactivityTime <> "0"
                stillwatchingPopupInactivityTime = stillwatchingPopupInactivityTime.ToInt()
                m.deviceInfo = CreateObject("roDeviceInfo")
                if m.deviceInfo.TimeSinceLastKeypress() >= (stillwatchingPopupInactivityTime * 60)
                    m.stillWatchingTimer = createObject("roSGNode", "Timer")
                    m.stillWatchingTimer.repeat = false
                    m.stillWatchingTimer.duration = 60
                    m.stillWatchingTimer.observeField("fire", "stillWatchingTimerComplete")
                    m.stillWatchingTimer.control = "start"
                    m.global.sceneManager.callFunc("optionDialog", "stillwatching", tr("Are You Still Watching?"), [
                        tr("Playback will automatically stop in 1 minute if no buttons are pressed.")
                    ], [
                        tr("Yes, continue")
                        tr("No, stop playback")
                    ], {})
                    return
                end if
            end if
            m.global.sceneManager.callFunc("clearPreviousScene")
            m.global.queueManager.callFunc("moveForward")
            m.global.queueManager.callFunc("playQueue")
            return
        end if
        episodeToShowAtFinish = ""
        gotoNextEpisodeAfterCurrentEnds = chainLookupReturn(m.global.session, "user.settings.`playback.showNextUpAfterFinish`", false)
        if gotoNextEpisodeAfterCurrentEnds
            episodeToShowAtFinish = m.global.queueManager.callFunc("getEpisodeToShowAtFinish")
        end if
        m.global.queueManager.callFunc("bypassNextPreferredAudioTrackIndexReset")
        m.global.queueManager.callFunc("clear")
        if isValidAndNotEmpty(episodeToShowAtFinish)
            m.global.queueManager.callFunc("setLastKnownItemID", episodeToShowAtFinish.LookupCI("id"))
        end if
        ' Playback completed, return user to previous screen
        m.global.sceneManager.callFunc("popScene")
        m.global.audioPlayer.loopMode = ""
    end if
end sub

sub stillWatchingTimerComplete()
    m.stillWatchingTimer.control = "stop"
    ' Check if user pressed a button before the timer fired
    if m.deviceInfo.TimeSinceLastKeypress() <= 60 then
        return
    end if
    if m.global.sceneManager.callFunc("isDialogOpen")
        m.global.sceneManager.callFunc("dismissDialog")
    end if
    m.global.queueManager.callFunc("bypassNextPreferredAudioTrackIndexReset")
    m.global.queueManager.callFunc("clear")
    m.global.sceneManager.callFunc("popScene")
end sub

' Roku translates the info provided in subtitleTracks into availableSubtitleTracks
' Including ignoring tracks, if they are not understood, thus making indexing unpredictable.
' This function translates between our internel selected subtitle index
' and the corresponding index in availableSubtitleTracks.
function availSubtitleTrackIdx(tracknameToFind as string) as integer
    idx = 0
    for each availTrack in m.view.availableSubtitleTracks
        ' The TrackName must contain the URL we supplied originally, though
        ' Roku mangles the name a bit, so we check if the URL is a substring, rather
        ' than strict equality
        if Instr(1, availTrack.TrackName, tracknameToFind)
            return idx
        end if
        idx = idx + 1
    end for
    return -1
end function

function audioMiniPlayerIsVisible(baseNode as dynamic) as boolean
    m.audioMiniPlayer = invalid
    scene = baseNode.getScene()
    if not isValid(scene) then
        return false
    end if
    m.audioMiniPlayer = scene.findNode("audioMiniPlayer")
    if not isValid(m.audioMiniPlayer) then
        return false
    end if
    return m.audioMiniPlayer.callFunc("isVisible")
end function
'//# sourceMappingURL=./ViewCreator.brs.map