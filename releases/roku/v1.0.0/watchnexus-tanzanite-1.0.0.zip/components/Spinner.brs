sub init()
    m.top.poster.uri = "pkg:/images/spinner.png"
    m.top.control = "start"
    m.top.clockwise = true
    m.top.spinInterval = 1
end sub
'//# sourceMappingURL=./Spinner.brs.map