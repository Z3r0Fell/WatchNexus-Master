'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/PosterLoadStatus.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.channelLogo = m.top.findNode("channelLogo")
    m.borderTop = m.top.findNode("borderTop")
    m.borderTop.color = "#777777"
    m.backdrop = m.top.findNode("backdrop")
    m.backdrop.color = "0x00000090"
    m.channelTitle = m.top.findNode("channelTitle")
    m.channelTitle.font.size = 27
    m.channelTitle.color = "#cccccc"
end sub

sub onWidthChanged()
    logoWidth = int(m.top.width / 3)
    titleTranslationHorizontal = logoWidth + 10
    titleWidth = m.top.width - titleTranslationHorizontal
    m.channelLogo.width = logoWidth
    m.channelTitle.maxWidth = titleWidth
    m.channelTitle.translation = [
        titleTranslationHorizontal
        0
    ]
    m.borderTop.width = m.top.width
    m.backdrop.width = m.top.width
end sub

sub onHeightChanged()
    m.channelLogo.height = m.top.height
    m.backdrop.height = m.top.height
    m.channelTitle.height = m.top.height
end sub

sub contentChanged()
    ' Reset all values due to Roku's component reuse
    m.channelLogo.uri = ""
    m.channelTitle.text = ""
    itemData = m.top.content
    if not isValid(itemData) then
        return
    end if
    if isValidAndNotEmpty(itemData.LookupCI("hdsmalliconurl"))
        m.channelLogo.uri = itemData.LookupCI("hdsmalliconurl")
    end if
    if isValid(itemData.LookupCI("title"))
        m.channelTitle.text = itemData.LookupCI("title")
    end if
end sub
'//# sourceMappingURL=./ChannelInfo.brs.map