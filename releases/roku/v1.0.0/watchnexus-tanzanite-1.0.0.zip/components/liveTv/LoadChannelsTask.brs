'import "pkg:/source/api/baserequest.bs"
'import "pkg:/source/api/sdk.bs"
'import "pkg:/source/utils/config.bs"

sub init()
    m.top.filter = "All"
    m.top.sortField = "SortName"
    m.top.functionName = "loadChannels"
end sub

sub loadChannels()
    m.top.totalRecordCount = 0
    results = []
    sort_field = m.top.sortField
    if m.top.sortAscending = true
        sort_order = "Ascending"
    else
        sort_order = "Descending"
    end if
    params = {
        includeItemTypes: "LiveTvChannel"
        SortBy: sort_field
        SortOrder: sort_order
        UserId: m.global.session.user.id
        EnableFavoriteSorting: true
        EnableUserData: false
        AddCurrentProgram: false
        recursive: true
    }
    ' Handle special case when getting names starting with numeral
    if m.top.NameStartsWith <> ""
        if m.top.NameStartsWith = "#"
            params.searchterm = "A"
        else
            params.searchterm = m.top.nameStartsWith
        end if
    end if
    'Append voice search when there is text
    if m.top.searchTerm <> ""
        params.searchTerm = m.top.searchTerm
    end if
    if m.top.filter = "Favorites"
        params.append({
            isFavorite: true
        })
    end if
    data = api_items_Get(params)
    if data.TotalRecordCount = invalid
        m.top.channels = results
        return
    end if
    m.top.totalRecordCount = data.TotalRecordCount
    for each item in data.Items
        channel = createObject("roSGNode", "ChannelData")
        channel.json = item
        results.push(channel)
    end for
    m.top.channels = results
end sub
'//# sourceMappingURL=./LoadChannelsTask.brs.map