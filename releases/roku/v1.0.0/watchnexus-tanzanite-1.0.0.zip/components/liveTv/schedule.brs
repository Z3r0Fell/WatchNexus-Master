'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/KeyCode.bs"
'import "pkg:/source/enums/String.bs"
'import "pkg:/source/enums/TaskControl.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.state = "RUN"
    m.channelScheduleLimit = 50
    m.channelScheduleLoadedCount = 0
    m.EPGLaunchCompleteSignaled = false
    m.scheduleGrid = m.top.findNode("scheduleGrid")
    m.detailsPane = m.top.findNode("detailsPane")
    m.gridData = createObject("roSGNode", "ContentNode")
    m.scheduleGrid.content = m.gridData
    m.detailsPane.observeField("watchSelectedChannel", "onWatchChannelSelected")
    m.detailsPane.observeField("recordSelectedChannel", "onRecordChannelSelected")
    m.detailsPane.observeField("recordSeriesSelectedChannel", "onRecordSeriesChannelSelected")
    m.gridStartDate = CreateObject("roDateTime")
    m.scheduleGrid.contentStartTime = m.gridStartDate.AsSeconds() - 1800
    m.gridEndDate = createObject("roDateTime")
    m.gridEndDate.FromSeconds(m.gridStartDate.AsSeconds() + (24 * 60 * 60))
    m.scheduleGrid.observeField("programFocused", "onProgramFocused")
    m.scheduleGrid.observeField("programSelected", "onProgramSelected")
    m.scheduleGrid.observeField("leftEdgeTargetTime", "onGridScrolled")
    m.scheduleGrid.channelInfoWidth = 350
    m.scheduleGrid.focusBitmapBlendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    m.scheduleGrid.programTitleFocusedColor = "#ffffff"
    m.scheduleGrid.timeLabelColor = "#aaaaaa"
    m.scheduleGrid.timeLabelFont.size = 30
    m.gridMoveAnimation = m.top.findNode("gridMoveAnimation")
    m.gridMoveAnimationPosition = m.top.findNode("gridMoveAnimationPosition")
    m.LoadChannelsTask = createObject("roSGNode", "LoadChannelsTask")
    m.LoadChannelsTask.observeField("channels", "onChannelListLoaded")
    m.LoadScheduleTask = createObject("roSGNode", "LoadScheduleTask")
    m.LoadScheduleTask.startTime = m.gridStartDate.ToISOString()
    m.LoadScheduleTask.endTime = m.gridEndDate.ToISOString()
    m.LoadProgramDetailsTask = createObject("roSGNode", "LoadProgramDetailsTask")
    m.LoadProgramDetailsTask.observeField("programDetails", "onProgramDetailsLoaded")
    m.loadedChannels = {}
    m.top.filter = "All"
    loadChannelList()
    m.top.lastFocus = m.scheduleGrid
end sub

sub loadChannelList()
    if not isStringEqual(m.state, "RUN") then
        return
    end if
    startLoadingSpinner()
    m.LoadChannelsTask.observeField("channels", "onChannelListLoaded")
    m.LoadChannelsTask.control = "RUN"
end sub

sub onFilterSet()
    ' Do nothing if the selected filter didn't change
    if not isValid(m.top.filter) then
        return
    end if
    if isStringEqual(m.LoadChannelsTask.filter, m.top.filter) then
        return
    end if
    m.scheduleGrid.jumpToChannel = 0
    if m.LoadChannelsTask.state = "RUN" then
        m.LoadChannelsTask.control = "STOP"
    end if
    m.LoadChannelsTask.filter = m.top.filter
    m.gridData = createObject("roSGNode", "ContentNode")
    m.scheduleGrid.content = m.gridData
    m.LoadChannelsTask.channels = []
    m.LoadScheduleTask.schedule = []
    m.LoadScheduleTask.channelIds = ""
    m.loadedChannels = {}
    m.channelIdList = []
    m.channelIndex = {}
    loadChannelList()
end sub

'Voice Search set
sub onSearchTermSet()
    m.scheduleGrid.jumpToChannel = 0
    'Reset filter if user says all
    if isStringEqual(m.top.searchTerm, tr("all")) or isStringEqual(m.LoadChannelsTask.searchTerm, tr("all"))
        m.top.searchTerm = " "
        m.LoadChannelsTask.searchTerm = " "
        'filter if the searterm is not invalid
    else if isValid(m.top.searchTerm) and not isStringEqual(m.LoadChannelsTask.searchTerm, m.top.searchTerm)
        if m.LoadChannelsTask.state = "RUN" then
            m.LoadChannelsTask.control = "STOP"
        end if
        m.LoadChannelsTask.searchTerm = m.top.searchTerm
    end if
    m.gridData.removeChildren(m.gridData.getChildren(-1, 0))
    m.channelScheduleLoadedCount = 0
    m.loadedChannels = {}
    m.channelIdList = []
    m.channelIndex = {}
    loadChannelList()
end sub

' List of channels loaded
sub onChannelListLoaded()
    m.LoadChannelsTask.control = "STOP"
    m.LoadChannelsTask.unobserveField("channels")
    counter = 0
    m.channelIdList = []
    m.channelIndex = {}
    'if search returns no channels
    if m.LoadChannelsTask.channels.count() = 0
        stopLoadingSpinner()
        return
    end if
    for each item in m.LoadChannelsTask.channels
        m.gridData.appendChild(item)
        m.channelIndex[item.Id] = counter
        m.channelIdList.push(item.Id)
        counter++
    end for
    loadScheduleData()
    if m.EPGLaunchCompleteSignaled = false
        m.top.signalBeacon("EPGLaunchComplete") ' Required Roku Performance monitoring
        m.EPGLaunchCompleteSignaled = true
    end if
    m.LoadChannelsTask.channels = []
end sub

sub loadScheduleData()
    if not isStringEqual(m.state, "RUN") then
        return
    end if
    m.LoadScheduleTask.control = "STOP"
    m.LoadScheduleTask.observeField("schedule", "onScheduleLoaded")
    if m.channelScheduleLoadedCount >= 1 then
        startingIndex = m.channelScheduleLoadedCount - 1
    else
        startingIndex = 0
    end if
    m.LoadScheduleTask.channelIds = m.channelIdList.slice(startingIndex, startingIndex + m.channelScheduleLimit).join(", ")
    m.LoadScheduleTask.control = "RUN"
    m.channelScheduleLimit = 500
end sub

' When LoadScheduleTask completes (initial or more data) and we have a schedule to display
sub onScheduleLoaded()
    m.LoadScheduleTask.unobserveField("schedule")
    ' make sure we actually have a schedule (i.e. filter by favorites, but no channels have been favorited)
    if m.scheduleGrid.content.GetChildCount() <= 0
        return
    end if
    for each item in m.LoadScheduleTask.schedule
        channel = m.scheduleGrid.content.GetChild(m.channelIndex[item.ChannelId])
        if not isValid(channel) then
            continue for
        end if
        if channel.PosterUrl <> ""
            item.channelLogoUri = channel.PosterUrl
        end if
        if channel.Title <> ""
            item.channelName = channel.Title
        end if
        channel.appendChild(item)
        m.loadedChannels[item.ChannelId] = 1
    end for
    m.scheduleGrid.showLoadingDataFeedback = false
    group = m.global.sceneManager.callFunc("getActiveScene")
    group.lastFocus = m.scheduleGrid
    stopLoadingSpinner()
    m.channelScheduleLoadedCount = m.loadedChannels.count()
    m.LoadScheduleTask.schedule = invalid
    if m.LoadChannelsTask.totalRecordCount > m.channelScheduleLoadedCount
        loadScheduleData()
    end if
end sub

sub onProgramFocused()
    m.top.watchChannel = invalid
    ' Make sure we have channels (i.e. filter set to favorite yet there are none)
    if m.scheduleGrid.content.getChildCount() <= 0
        channel = invalid
    else
        channel = m.scheduleGrid.content.GetChild(m.scheduleGrid.programFocusedDetails.focusChannelIndex)
    end if
    m.detailsPane.channel = channel
    m.top.focusedChannel = channel
    ' Exit if Channels not yet loaded
    if channel = invalid or channel.getChildCount() = 0
        m.detailsPane.programDetails = invalid
        return
    end if
    prog = channel.GetChild(m.scheduleGrid.programFocusedDetails.focusIndex)
    if prog <> invalid and prog.fullyLoaded = false
        m.LoadProgramDetailsTask.programId = prog.Id
        m.LoadProgramDetailsTask.channelIndex = m.scheduleGrid.programFocusedDetails.focusChannelIndex
        m.LoadProgramDetailsTask.programIndex = m.scheduleGrid.programFocusedDetails.focusIndex
        m.LoadProgramDetailsTask.control = "RUN"
    end if
    m.detailsPane.programDetails = prog
end sub

' Update the Program Details with full information
sub onProgramDetailsLoaded()
    if not isStringEqual(m.state, "RUN") then
        return
    end if
    if m.LoadProgramDetailsTask.programDetails = invalid then
        return
    end if
    channel = m.scheduleGrid.content.GetChild(m.LoadProgramDetailsTask.programDetails.channelIndex)
    ' If TV Show does not have its own image, use the channel logo
    if m.LoadProgramDetailsTask.programDetails.PosterUrl = invalid or m.LoadProgramDetailsTask.programDetails.PosterUrl = ""
        m.LoadProgramDetailsTask.programDetails.PosterUrl = channel.PosterUrl
    end if
    channel.ReplaceChild(m.LoadProgramDetailsTask.programDetails, m.LoadProgramDetailsTask.programDetails.programIndex)
    m.LoadProgramDetailsTask.programDetails = invalid
    m.scheduleGrid.showLoadingDataFeedback = false
end sub

sub onProgramSelected()
    ' If there is no program data - view the channel
    if m.detailsPane.programDetails = invalid
        m.top.watchChannel = m.scheduleGrid.content.GetChild(m.scheduleGrid.programFocusedDetails.focusChannelIndex)
        return
    end if
    ' Move Grid Down
    focusProgramDetails(true)
end sub

' Move the TV Guide Grid down or up depending whether details are selected
sub focusProgramDetails(setFocused)
    h = m.detailsPane.height
    if h < 400 then
        h = 400
    end if
    h = h + 160 + 80
    if setFocused = true
        m.gridMoveAnimationPosition.keyValue = [
            [
                0
                600
            ]
            [
                0
                h
            ]
        ]
        m.detailsPane.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.detailsPane
        m.detailsPane.hasFocus = true
        m.top.lastFocus = m.detailsPane
    else
        m.detailsPane.hasFocus = false
        m.gridMoveAnimationPosition.keyValue = [
            [
                0
                h
            ]
            [
                0
                600
            ]
        ]
        m.scheduleGrid.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.scheduleGrid
        m.top.lastFocus = m.scheduleGrid
    end if
    m.gridMoveAnimation.control = "start"
end sub

' Handle user selecting "Watch Channel" from Program Details
sub onWatchChannelSelected()
    if m.detailsPane.watchSelectedChannel = false then
        return
    end if
    ' Set focus back to grid before showing channel, to ensure grid has focus when we return
    focusProgramDetails(false)
    m.top.watchChannel = m.detailsPane.channel
end sub

' As user scrolls grid, check if more data requries to be loaded
sub onGridScrolled()
    ' If we're within 12 hours of end of grid, load next 24hrs of data
    if m.scheduleGrid.leftEdgeTargetTime + (12 * 60 * 60) > m.gridEndDate.AsSeconds()
        ' Ensure the task is not already (still) running,
        if m.LoadScheduleTask.state <> "run"
            m.LoadScheduleTask.startTime = m.gridEndDate.ToISOString()
            m.gridEndDate.FromSeconds(m.gridEndDate.AsSeconds() + (24 * 60 * 60))
            m.LoadScheduleTask.endTime = m.gridEndDate.ToISOString()
            m.LoadScheduleTask.control = "RUN"
        end if
    end if
end sub

' Handle user selecting "Record Channel" from Program Details
sub onRecordChannelSelected()
    if m.detailsPane.recordSelectedChannel = false then
        return
    end if
    ' Set focus back to grid before showing channel, to ensure grid has focus when we return
    focusProgramDetails(false)
    m.scheduleGrid.showLoadingDataFeedback = true
    m.RecordProgramTask = createObject("roSGNode", "RecordProgramTask")
    m.RecordProgramTask.programDetails = m.detailsPane.programDetails
    m.RecordProgramTask.recordSeries = false
    m.RecordProgramTask.observeField("recordOperationDone", "onRecordOperationDone")
    m.RecordProgramTask.control = "RUN"
end sub

' Handle user selecting "Record Series" from Program Details
sub onRecordSeriesChannelSelected()
    if m.detailsPane.recordSeriesSelectedChannel = false then
        return
    end if
    ' Set focus back to grid before showing channel, to ensure grid has focus when we return
    focusProgramDetails(false)
    m.scheduleGrid.showLoadingDataFeedback = true
    m.RecordProgramTask = createObject("roSGNode", "RecordProgramTask")
    m.RecordProgramTask.programDetails = m.detailsPane.programDetails
    m.RecordProgramTask.recordSeries = true
    m.RecordProgramTask.observeField("recordOperationDone", "onRecordOperationDone")
    m.RecordProgramTask.control = "RUN"
end sub

sub onRecordOperationDone()
    if m.RecordProgramTask.recordSeries = true and m.LoadScheduleTask.state <> "run"
        m.LoadScheduleTask.control = "RUN"
    else
        ' This reloads just the details for the currently selected program, so that we don't have to
        ' reload the entire grid...
        channel = m.scheduleGrid.content.GetChild(m.scheduleGrid.programFocusedDetails.focusChannelIndex)
        prog = channel.GetChild(m.scheduleGrid.programFocusedDetails.focusIndex)
        m.LoadProgramDetailsTask.programId = prog.Id
        m.LoadProgramDetailsTask.channelIndex = m.scheduleGrid.programFocusedDetails.focusChannelIndex
        m.LoadProgramDetailsTask.programIndex = m.scheduleGrid.programFocusedDetails.focusIndex
        m.LoadProgramDetailsTask.control = "RUN"
    end if
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        return false
    end if
    detailsGrp = m.top.findNode("detailsPane")
    gridGrp = m.top.findNode("scheduleGrid")
    if isStringEqual(key, "back")
        if detailsGrp.isInFocusChain()
            focusProgramDetails(false)
            detailsGrp.setFocus(false)
            gridGrp.setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = gridGrp
            return true
        end if
        m.state = "STOP"
        m.LoadChannelsTask.control = "STOP"
        m.LoadScheduleTask.control = "STOP"
        m.gridData = createObject("roSGNode", "ContentNode")
        m.scheduleGrid.content = m.gridData
        m.LoadChannelsTask.channels = []
        m.LoadScheduleTask.schedule = []
        m.LoadScheduleTask.channelIds = ""
        m.loadedChannels = {}
        m.channelIdList = []
        m.channelIndex = {}
        m.global.sceneManager.callFunc("popScene")
        return true
    end if
    return false
end function
'//# sourceMappingURL=./schedule.brs.map