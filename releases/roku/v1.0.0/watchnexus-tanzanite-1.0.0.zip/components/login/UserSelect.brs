'import "pkg:/source/enums/AnimationControl.bs"
'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/KeyCode.bs"
'import "pkg:/source/enums/String.bs"
'import "pkg:/source/utils/config.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.top.optionsAvailable = false
    m.unhideUsers = m.top.findNode("unhideUsers")
    m.unhideUsers.color = "#101420"
    m.hiddenUsers = m.top.findNode("hiddenUsers")
    m.manageHiddenUsers = m.top.findNode("manageHiddenUsers")
    m.hiddenUsers.focusBitmapBlendColor = "0xff6867FF"
    m.hiddenUsers.focusedColor = "#ffffff"
    m.manualLogin = m.top.findNode("manualLogin")
    m.manualLogin.background = "#c8fafa"
    m.manualLogin.color = "#101010"
    m.manualLogin.focusBackground = "0xff6867FF"
    m.manualLogin.focusColor = "#ffffff"
    m.hiddenUserAnimation = m.top.findNode("hiddenUserAnimation")
    m.hiddenUserSlider = m.top.findNode("hiddenUserSlider")
    m.viewContentSlider = m.top.findNode("viewContentSlider")
end sub

sub onHiddenUserListChanged()
    if not isValidAndNotEmpty(m.top.hiddenUserList)
        m.hiddenUsers.content = CreateObject("roSGNode", "ContentNode")
        if m.hiddenUsers.isInFocusChain()
            m.hiddenUserSlider.reverse = true
            m.viewContentSlider.reverse = true
            m.hiddenUserAnimation.control = "start"
            m.manualLogin.focus = true
            m.manualLogin.setFocus(true)
        end if
        m.manageHiddenUsers.visible = false
        return
    end if
    m.manageHiddenUsers.visible = true
    hiddenUserList = CreateObject("roSGNode", "ContentNode")
    for each user in m.top.hiddenUserList
        if user.id = "" then
            continue for
        end if
        row = CreateObject("roSGNode", "PublicUserData")
        row.title = user.Name
        row.id = user.id
        row.Name = user.Name
        row.isPublic = user.isPublic
        row.imageURL = user.imageURL
        hiddenUserList.appendChild(row)
    end for
    m.hiddenUsers.content = hiddenUserList
end sub

sub itemContentChanged()
    stopLoadingSpinner()
    m.top.findNode("UserRow").ItemContent = m.top.itemContent
    if m.top.itemContent.count() = 0
        m.top.findNode("UserRow").setFocus(false)
        m.manualLogin.setFocus(true)
        m.manualLogin.focus = true
    end if
    redraw()
end sub

sub redraw()
    userCount = m.top.itemContent.Count()
    topBorder = 310
    leftBorder = 130
    itemWidth = 300
    itemSpacing = 40
    if userCount < 5
        leftBorder = (1920 - ((userCount * itemWidth) + ((userCount - 1) * itemSpacing))) / 2
    end if
    m.top.findNode("UserRow").translation = [
        leftBorder
        topBorder
    ]
end sub

' JFScreen hook called when the screen is displayed by the screen manager
sub OnScreenShown()
    scene = m.top.getScene()
    overhang = scene.findNode("overhang")
    if isValid(overhang)
        overhang.isVisible = false
    end if
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        return false
    end if
    if key = "right"
        if m.hiddenUsers.hasFocus()
            m.manageHiddenUsers.color = "0xff6867FF"
            m.manageHiddenUsers.setFocus(true)
            m.viewContentSlider.reverse = true
            m.hiddenUserSlider.reverse = true
            m.hiddenUserAnimation.control = "start"
            return true
        end if
    end if
    if key = "OK"
        if m.manualLogin.hasFocus()
            m.manualLogin.selected = not m.manualLogin.selected
            return true
        end if
        if m.manageHiddenUsers.hasFocus()
            m.viewContentSlider.reverse = false
            m.hiddenUserSlider.reverse = false
            m.hiddenUserAnimation.control = "start"
            m.hiddenUsers.setFocus(true)
            m.manageHiddenUsers.color = "#ffffff"
            return true
        end if
        if m.hiddenUsers.isInFocusChain()
            m.top.showUser = m.hiddenUsers.content.getChild(m.hiddenUsers.itemFocused)
            return true
        end if
        return false
    end if
    if key = "options"
        userRow = m.top.findNode("UserRow")
        userList = userRow.itemContent
        user = userList[userRow.rowItemFocused[1]]
        if not isValid(user) then
            return false
        end if
        if user.isPublic
            m.top.hideUser = user
            return true
        end if
        m.top.forgetUser = user.id
        return true
    end if
    if key = "back"
        m.top.backPressed = true
        return true
    end if
    if key = "up"
        if m.manualLogin.hasFocus()
            if m.top.itemContent.count() = 0 then
                return false
            end if
            m.top.findNode("UserRow").setFocus(true)
            m.manualLogin.focus = false
            return true
        end if
        if m.manageHiddenUsers.hasFocus()
            m.manualLogin.setFocus(true)
            m.manualLogin.focus = true
            m.manageHiddenUsers.color = "#ffffff"
            return true
        end if
        return false
    end if
    if key = "down"
        if m.top.findNode("UserRow").isInFocusChain()
            m.manualLogin.setFocus(true)
            m.manualLogin.focus = true
            return true
        end if
        if m.manualLogin.hasFocus()
            if not m.manageHiddenUsers.visible
                return false
            end if
            m.manageHiddenUsers.setFocus(true)
            m.manualLogin.focus = false
            m.manageHiddenUsers.color = "0xff6867FF"
            return true
        end if
        return false
    end if
    return false
end function
'//# sourceMappingURL=./UserSelect.brs.map