'import "pkg:/source/api/baserequest.bs"
'import "pkg:/source/api/Image.bs"
'import "pkg:/source/enums/AnimationControl.bs"
'import "pkg:/source/enums/AnimationState.bs"
'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/ItemType.bs"
'import "pkg:/source/enums/KeyCode.bs"
'import "pkg:/source/enums/TaskControl.bs"
'import "pkg:/source/utils/config.bs"
'import "pkg:/source/utils/deviceCapabilities.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.isFirstRun = true
    m.top.overhangTitle = ""
    m.top.optionsAvailable = false
    m.postTask = createObject("roSGNode", "PostTask")
    m.favoritesOptionText = tr("Add To Favorites")
    m.loadItemsTask1 = createObject("roSGNode", "LoadItemsTask")
    m.loadItemsTask1.observeField("content", "onMyListLoaded")
    m.loadItemsTask1.itemsToLoad = "isInMyList"
    m.loadMetaDataTask = CreateObject("roSGNode", "LoadItemsTask")
    m.loadMetaDataTask.itemsToLoad = "metaData"
    m.loadMetaDataTask.observeField("content", "onMetaDataLoaded")
    m.homeRows = m.top.findNode("homeRows")
    m.homeRows.focusBitmapBlendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    m.buttons = m.top.findNode("buttons")
    m.toggleButtonsAnimation = m.top.findNode("toggleButtonsAnimation")
    m.buttonsFade = m.top.findNode("buttonsFade")
    m.buttonsMove = m.top.findNode("buttonsMove")
    setButtonColors()
end sub

sub refresh()
    m.homeRows.focusBitmapBlendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    m.homeRows.callFunc("updateHomeRows")
end sub

sub setButtonColors()
    m.searchButton = m.top.findNode("searchButton")
    m.searchButton.textColor = "#ffffff"
    m.searchButton.background = "#101010"
    m.searchButton.focusTextColor = "#ffffff"
    m.searchButton.focusBackground = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    m.settingsButton = m.top.findNode("settingsButton")
    m.settingsButton.textColor = "#ffffff"
    m.settingsButton.background = "#101010"
    m.settingsButton.focusTextColor = "#ffffff"
    m.settingsButton.focusBackground = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
end sub

sub loadLibraries()
    m.homeRows.callFunc("loadLibraries")
end sub

' JFScreen hook called when the screen is displayed by the screen manager
sub OnScreenShown()
    m.homeRows.rowLabelColor = chainLookupReturn(m.global.session, "user.settings.colorHomeRowHeaders", "#ffffff")
    scene = m.top.getScene()
    overhang = scene.findNode("overhang")
    if isValid(overhang)
        overhang.visible = true
        overhang.title = ""
        overhang.currentUserProfileImage = UserImageURL(m.global.session.user.id)
        overhang.currentUser = m.global.session.user.name
    end if
    if isValid(m.top.lastFocus)
        if LCase(m.top.lastFocus.id) = "overhang"
            overhang.callFunc("highlightUser")
        end if
        m.top.lastFocus.setFocus(true)
    else
        m.top.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.top
    end if
    if not m.isFirstRun
        refresh()
    end if
    ' post the device profile the first time this screen is loaded
    if m.isFirstRun
        m.isFirstRun = false
        m.postTask.arrayData = getDeviceCapabilities()
        m.postTask.apiUrl = "/Sessions/Capabilities/Full"
        m.postTask.control = "RUN"
        m.postTask.observeField("responseCode", "postFinished")
    end if
end sub

' JFScreen hook called when the screen is hidden by the screen manager
sub OnScreenHidden()
    scene = m.top.getScene()
    overhang = scene.findNode("overhang")
    if isValid(overhang)
        overhang.callFunc("dehighlightUser")
        overhang.currentUser = ""
        overhang.title = ""
    end if
end sub

' Triggered by m.postTask after completing a post.
' Empty the task data when finished.
sub postFinished()
    m.postTask.unobserveField("responseCode")
    m.postTask.callFunc("empty")
end sub

sub onRowFocusedChange()
    if m.top.rowFocused > 0
        if m.buttons.opacity > 0
            toggleButtonsVisibility()
        end if
        return
    end if
    if m.buttons.opacity < 1
        toggleButtonsVisibility(true)
    end if
end sub

sub toggleButtonsVisibility(runInReverse = false as boolean)
    m.buttonsFade.reverse = runInReverse
    m.buttonsMove.reverse = runInReverse
    if not isStringEqual(m.toggleButtonsAnimation.state, "running")
        m.toggleButtonsAnimation.control = "start"
    end if
end sub

sub onMyListLoaded()
    isInMyListData = m.loadItemsTask1.content
    m.loadItemsTask1.content = []
    if not isValidAndNotEmpty(isInMyListData) then
        return
    end if
    focusedItem = m.homeRows.content.getChild(m.homeRows.rowItemFocused[0]).getChild(m.homeRows.rowItemFocused[1])
    if not isValid(focusedItem) then
        return
    end if
    dialogData = []
    paramData = {
        id: focusedItem.LookupCI("id")
    }
    if isInMyListData[0]
        dialogData.push(tr("Remove From My List"))
    else
        if inArray([
            "episode"
            "movie"
            "season"
            "series"
            "video"
            "musicvideo"
            "recording"
            "boxset"
        ], focusedItem.LookupCI("type"))
            dialogData.push(tr("Add To My List"))
        end if
    end if
    dialogData.push(m.favoritesOptionText)
    if not inArray([
        "collectionfolder"
        "channel"
        "folder"
        "playlist"
        "program"
        "tvchannel"
        "userview"
    ], focusedItem.LookupCI("type"))
        dialogData.push(tr("Add To Playlist"))
    end if
    if inArray([
        "episode"
        "movie"
        "season"
        "series"
        "video"
        "musicvideo"
        "recording"
        "boxset"
        "audiobook"
        "book"
    ], focusedItem.LookupCI("type"))
        showBothOptions = false
        if isChainValid(focusedItem, "PlayedPercentage")
            if focusedItem.PlayedPercentage > 0
                showBothOptions = true
            end if
        end if
        if showBothOptions
            dialogData.push(tr("Mark As Unplayed"))
            dialogData.push(tr("Mark As Played"))
        else
            if isChainValid(focusedItem, "isWatched")
                if focusedItem.isWatched
                    dialogData.push(tr("Mark As Unplayed"))
                else
                    dialogData.push(tr("Mark As Played"))
                end if
            end if
        end if
    end if
    if inArray([
        "episode"
        "season"
    ], focusedItem.LookupCI("type"))
        dialogData.push(tr("Go To Series"))
        dialogData.push(tr("Go To Season"))
        paramData.SeasonId = focusedItem.json.LookupCI("SeasonId")
        paramData.SeriesId = focusedItem.json.LookupCI("SeriesId")
    end if
    if inArray([
        "musicalbum"
    ], focusedItem.LookupCI("type"))
        dialogData.push(tr("Play Instant Mix"))
        dialogData.push(tr("Go To Artist"))
        genreData = focusedItem.json.LookupCI("Genre")
        if isValidAndNotEmpty(genreData)
            if isValidAndNotEmpty(genreData[0])
                if isValidAndNotEmpty(genreData[0].Name)
                    dialogData.push(tr("Go To Genre") + (": " + bslib_toString(genreData[0].LookupCI("Name"))))
                    paramData.GenreName = genreData[0].LookupCI("Name")
                    paramData.GenreId = genreData[0].LookupCI("Id")
                    paramData.LibraryId = chainLookup(focusedItem, "json.LibraryId")
                end if
            end if
        end if
        paramData.ArtistId = focusedItem.json.LookupCI("AlbumArtistId")
        paramData.ArtistName = focusedItem.json.LookupCI("albumartist")
        paramData.AlbumId = focusedItem.LookupCI("id")
    end if
    m.global.sceneManager.callFunc("optionDialog", "libraryitem", (function(focusedItem, tr)
            __bsConsequent = focusedItem.LookupCI("title")
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return tr("Options")
            end if
        end function)(focusedItem, tr), [], dialogData, paramData)
end sub

sub setLastFocus(lastFocusElement)
    group = m.global.sceneManager.callFunc("getActiveScene")
    if isValid(group)
        group.lastFocus = lastFocusElement
    end if
end sub

function audioMiniPlayerIsVisibleInScene()
    scene = m.top.getScene()
    audioMiniPlayer = scene.findNode("audioMiniPlayer")
    if not isValid(audioMiniPlayer) then
        return false
    end if
    return audioMiniPlayer.callFunc("isVisible")
end function

' Special handling for key presses on the home screen.
function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        return false
    end if
    if m.buttons.isInFocusChain()
        if isStringEqual(key, "replay")
            if not audioMiniPlayerIsVisibleInScene() then
                return true
            end if
            m.searchButton.focus = false
            m.settingsButton.focus = false
        end if
        if isStringEqual(key, "OK")
            if m.searchButton.hasFocus()
                m.top.getScene().jumpTo = {
                    selectionType: "search"
                }
                return true
            end if
            if m.settingsButton.hasFocus()
                m.top.getScene().jumpTo = {
                    selectionType: "settings"
                }
                return true
            end if
        end if
        if isStringEqual(key, "down")
            m.searchButton.focus = false
            m.settingsButton.focus = false
            m.homeRows.setfocus(true)
            setLastFocus(m.homeRows)
            return true
        end if
        if isStringEqual(key, "right")
            if m.searchButton.hasFocus()
                m.searchButton.focus = false
                m.settingsButton.focus = true
                m.settingsButton.setfocus(true)
                setLastFocus(m.settingsButton)
                return true
            end if
            if m.settingsButton.hasFocus()
                m.settingsButton.focus = false
                scene = m.top.getScene()
                if not isValid(scene) then
                    return false
                end if
                overhang = scene.findNode("overhang")
                if not isValid(overhang) then
                    return false
                end if
                overhang.callFunc("highlightUser")
                overhang.setfocus(true)
                setLastFocus(overhang)
                return true
            end if
        end if
        if isStringEqual(key, "left")
            if m.settingsButton.hasFocus()
                m.searchButton.focus = true
                m.settingsButton.focus = false
                m.searchButton.setfocus(true)
                setLastFocus(m.searchButton)
                return true
            end if
        end if
        return false
    end if
    ' If the user hit back and is not on the first item of the row,
    ' assume they want to go to the first item of the row.
    ' Otherwise, they are exiting the app.
    if isStringEqual(key, "back") and m.homeRows.rowItemFocused[1] > 0
        m.homeRows.jumpToRowItem = [
            m.homeRows.rowItemFocused[0]
            0
        ]
        return true
    end if
    if isStringEqual(key, "options")
        if m.homeRows.hasFocus()
            focusedItem = m.homeRows.content.getChild(m.homeRows.rowItemFocused[0]).getChild(m.homeRows.rowItemFocused[1])
            if not isValidAndNotEmpty(focusedItem) then
                return false
            end if
            m.loadMetaDataTask.itemId = focusedItem.LookupCI("id")
            m.loadMetaDataTask.control = "RUN"
            return true
        end if
    end if
    if isStringEqual(key, "up")
        ' In case the user pressed up rapidly and the focused row wasn't able to update in time
        if m.buttons.opacity < 1
            toggleButtonsVisibility(true)
        end if
        m.searchButton.focus = true
        m.searchButton.setfocus(true)
        setLastFocus(m.searchButton)
        return true
    end if
    return false
end function

sub onMetaDataLoaded()
    data = m.loadMetaDataTask.content[0]
    if chainLookupReturn(data, "json.UserData.IsFavorite", false) then
        m.favoritesOptionText = tr("Remove From Favorites")
    else
        m.favoritesOptionText = tr("Add To Favorites")
    end if
    focusedItem = m.homeRows.content.getChild(m.homeRows.rowItemFocused[0]).getChild(m.homeRows.rowItemFocused[1])
    m.loadItemsTask1.itemId = focusedItem.LookupCI("id")
    m.loadItemsTask1.control = "RUN"
end sub
'//# sourceMappingURL=./Home.brs.map