'import "pkg:/source/api/baserequest.bs"
'import "pkg:/source/enums/CaptionMoveDirection.bs"
'import "pkg:/source/enums/MediaPlaybackState.bs"
'import "pkg:/source/enums/String.bs"
'import "pkg:/source/utils/config.bs"

sub init()
    m.top.playerState = "stopped"
    m.top.observeField("url", "fetchCaption")
    m.top.currentCaption = []
    m.top.currentPos = 0
    m.captionTimer = m.top.findNode("captionTimer")
    m.captionTimer.ObserveField("fire", "updateCaption")
    m.captionList = []
    m.reader = createObject("roUrlTransfer")
    m.font = CreateObject("roSGNode", "Font")
    m.tags = CreateObject("roRegex", "{\\an\d*}|&lt;.*?&gt;|<.*?>", "s")
    ' Caption Style
    m.fontSizeDict = {
        "Default": 60
        "Large": 60
        "Extra Large": 70
        "Medium": 50
        "Small": 40
    }
    m.percentageDict = {
        "Default": 1.0
        "100%": 1.0
        "75%": 0.75
        "50%": 0.5
        "25%": 0.25
        "Off": 0
    }
    m.textColorDict = {
        "Default": &HFFFFFFFF
        "White": &HFFFFFFFF
        "Black": &H000000FF
        "Red": &HFF0000FF
        "Green": &H008000FF
        "Blue": &H0000FFFF
        "Yellow": &HFFFF00FF
        "Magenta": &HFF00FFFF
        "Cyan": &H00FFFFFF
    }
    m.bgColorDict = {
        "Default": &H000000FF
        "White": &HFFFFFFFF
        "Black": &H000000FF
        "Red": &HFF0000FF
        "Green": &H008000FF
        "Blue": &H0000FFFF
        "Yellow": &HFFFF00FF
        "Magenta": &HFF00FFFF
        "Cyan": &H00FFFFFF
    }
    deviceInfo = CreateObject("roDeviceInfo")
    m.fontSize = m.fontSizeDict[deviceInfo.GetCaptionsOption("Text/Size")]
    m.textColor = m.textColorDict[deviceInfo.GetCaptionsOption("Text/Color")]
    m.textOpac = m.percentageDict[deviceInfo.GetCaptionsOption("Text/Opacity")]
    m.bgColor = m.bgColorDict[deviceInfo.GetCaptionsOption("Background/Color")]
    m.bgOpac = m.percentageDict[deviceInfo.GetCaptionsOption("Background/Opacity")]
    setFont()
end sub

sub setFont()
    fs = CreateObject("roFileSystem")
    if fs.Exists("tmp:/font")
        m.font.uri = "tmp:/font"
        m.font.size = m.fontSize
    else
        m.font = "font:LargeSystemFont"
    end if
end sub

sub fetchCaption()
    m.captionTimer.control = "stop"
    re = CreateObject("roRegex", "(http.*?\.vtt)", "s")
    url = re.match(m.top.url)[0]
    if url <> invalid
        m.reader.setUrl(url)
        text = m.reader.GetToString()
        m.captionList = parseVTT(text)
        m.captionTimer.control = "start"
    else
        m.captionTimer.control = "stop"
    end if
end sub

function newlabel(txt)
    label = CreateObject("roSGNode", "Label")
    label.text = txt
    label.font = m.font
    label.font.size = m.fontSize
    label.color = m.textColor
    label.opacity = m.textOpac
    return label
end function

function newLayoutGroup(labels)
    newlg = CreateObject("roSGNode", "LayoutGroup")
    newlg.appendchildren(labels)
    newlg.layoutDirection = "vert"
    newlg.horizalignment = "left"
    newlg.vertalignment = "top"
    newlg.itemSpacings = "[5]"
    return newlg
end function

function newRect(lg, id as string)
    rectxy = lg.BoundingRect()
    rect = CreateObject("roSGNode", "Rectangle")
    rect.addreplace("id", id)
    rect.appendchild(lg)
    lg.translation = [
        5
        5
    ]
    rect.color = m.bgColor
    rect.opacity = m.bgOpac
    rect.width = rectxy.width + 10
    rect.height = rectxy.height + 10
    if lg.getchildCount() = 0
        rect.width = 0
        rect.height = 0
    end if
    return rect
end function

sub updateCaption()
    if LCase(m.top.playerState.right(1)) = "w"
        m.top.playerState = m.top.playerState.left(len(m.top.playerState) - 1)
        return
    end if
    m.top.currentCaption = []
    if not isStringEqual(m.top.playerState, "playingon") then
        return
    end if
    m.top.currentPos = m.top.currentPos + 100
    captions = []
    for each entry in m.captionList
        if entry["start"] <= m.top.currentPos and m.top.currentPos < entry["end"]
            labels = []
            for each text in entry["text"]
                labels.push(newlabel(text))
            end for
            lines = newLayoutGroup(labels)
            rect = newRect(lines, entry.LookupCI("id"))
            finalStyles = prepareStyles(entry["styles"], rect, labels.count())
            rect.translation = finalStyles.translation
            adjustForCaptionOverlaps(rect, captions)
            captions.push(rect)
        end if
    end for
    m.top.currentCaption = captions
end sub

sub adjustForCaptionOverlaps(newCaption, existingCaptions, moveDirection = 1)
    newCaptionBounds = newCaption.sceneBoundingRect()
    for i = existingCaptions.count() - 1 to 0 step -1
        comparisonCaption = existingCaptions[i]
        ' Don't compare the caption to itself
        if isStringEqual(newCaption.lookupCI("id"), comparisonCaption.lookupCI("id")) then
            continue for
        end if
        comparisonCaptionBounds = comparisonCaption.sceneBoundingRect()
        overlapping = isOverlapping(newCaption, comparisonCaption)
        if overlapping
            ' If we're in the top half of the screen, push the other caption down
            ' otherwise push the other caption up
            if newCaptionBounds.y < 540
                moveDirection = 2
            end if
            if moveDirection = 2
                calculatedVerticalPosition = newCaptionBounds.y + newCaptionBounds.height + 5
            else
                calculatedVerticalPosition = newCaptionBounds.y - comparisonCaptionBounds.height - 5
            end if
            if calculatedVerticalPosition < 0 then
                calculatedVerticalPosition = 0
            end if
            comparisonCaption.translation = [
                comparisonCaption.translation[0]
                calculatedVerticalPosition
            ]
            adjustForCaptionOverlaps(comparisonCaption, existingCaptions, moveDirection)
        end if
    end for
end sub

function isOverlapping(node1, node2) as boolean
    node1Bounds = node1.sceneBoundingRect()
    node2Bounds = node2.sceneBoundingRect()
    return node1Bounds.x < (node2Bounds.x + node2Bounds.width) and node2Bounds.x < (node1Bounds.x + node1Bounds.width) and node1Bounds.y < (node2Bounds.y + node2Bounds.height) and node2Bounds.y < (node1Bounds.y + node1Bounds.height)
end function

function prepareStyles(styles as object, rect, lineCount = 1 as integer) as object
    captionStyles = styles
    finalStyles = {
        translation: [
            960
            1020
        ]
    }
    verticalPosition = 1020
    horizontalPositon = 960 - (rect.BoundingRect().width / 2)
    if not isValidAndNotEmpty(captionStyles)
        return finalStyles
    end if
    captionLine = chainLookupReturn(captionStyles, "line", "")
    captionPosition = chainLookupReturn(captionStyles, "position", "")
    ' Line
    if not isStringEqual(captionLine, "")
        captionLineHeight = (rect.BoundingRect().height / lineCount)
        verticalPosition = processLineCue(captionLine, captionLineHeight)
    end if
    ' Position
    if not isStringEqual(captionPosition, "")
        horizontalPositon = processPositionCue(captionPosition, rect.BoundingRect().width)
    end if
    finalStyles.translation = [
        horizontalPositon
        verticalPosition
    ]
    return finalStyles
end function

function processPositionCue(captionPosition as string, captionLineWidth as float) as integer
    calculatedPosition = 1920 * (val(captionPosition) / 100)
    if calculatedPosition + captionLineWidth > 1920
        calculatedPosition = 1920 - captionLineWidth
    end if
    if calculatedPosition < 0
        calculatedPosition = 0
    end if
    return calculatedPosition
end function

function processLineCue(captionLine as string, captionLineHeight as float) as integer
    ' A percentage
    if captionLine.Instr("%") <> -1
        calculatedPosition = 1080 * (val(captionLine) / 100)
        if calculatedPosition + captionLineHeight > 1080
            calculatedPosition = 1080 - captionLineHeight
        end if
        return calculatedPosition
    end if
    ' Note: Non-numeric values are treated as 0
    lineValue = val(captionLine)
    if lineValue = 0 then
        return 0
    end if
    ' A positive line value. Count from the top
    if lineValue >= 0
        calculatedPosition = lineValue * captionLineHeight
        if calculatedPosition + captionLineHeight > 1080
            calculatedPosition = 1080 - captionLineHeight
        end if
        return calculatedPosition
    end if
    ' A negative line value. Count from the bottom
    calculatedPosition = 1080 - Abs(lineValue * captionLineHeight)
    if calculatedPosition < 0
        calculatedPosition = 0
    end if
    return calculatedPosition
end function

function isTime(text)
    return text.right(1) = chr(31)
end function

function toMs(t)
    t = t.replace(".", ":")
    t = t.left(12)
    timestamp = t.tokenize(":")
    return 3600000 * timestamp[0].toint() + 60000 * timestamp[1].toint() + 1000 * timestamp[2].toint() + timestamp[3].toint()
end function

function extractStyles(lineData as string) as object
    returnData = {
        endTimestamp: ""
        styles: {}
    }
    lineDataArray = lineData.split(" ")
    returnData.endTimestamp = lineDataArray.shift()
    for each style in lineDataArray
        styleData = style.split(":")
        ' We don't support RTL text, so positionAlign properties must be removed
        styleDataPositionAlign = styleData[1].split(",")
        returnData.styles.addreplace(styleData[0], styleDataPositionAlign[0])
    end for
    return returnData
end function

function parseVTT(lines)
    lines = lines.replace(" --> ", chr(31) + chr(10))
    lines = lines.replace(": ", ":")
    lines = lines.split(chr(10))
    curStart = -1
    curEnd = -1
    entries = []
    currentLine = []
    entry = {}
    isNewLine = false
    for i = 0 to lines.count() - 1
        if isTime(lines[i])
            currentLine = []
            curStart = toMs(lines[i])
            lineData = extractStyles(lines[i + 1])
            curEnd = toMs(lineData.LookupCI("endTimestamp"))
            curstyles = chainLookup(lineData, "styles")
            entry = {
                "start": curStart
                "end": curEnd
                "styles": curstyles
                "id": ("caption" + bslib_toString(i))
            }
            isNewLine = true
            i += 1
            continue for
        end if
        if isNewLine
            trimmed = lines[i].trim()
            finalText = m.tags.replaceAll(trimmed, "")
            ' We reached a blank line
            if isStringEqual(finalText, "")
                entry.AddReplace("text", currentLine)
                entries.push(entry)
                ' This is a false positive in bslint due to
                ' https://github.com/rokucommunity/bslint/issues/47
                ' bs:disable-next-line
                isNewLine = false
                continue for
            end if
            ' We're inside a text block
            currentLine.push(finalText)
            ' We reached the end of the file and it doesn't end with a blank line
            if i = (lines.count() - 1)
                entry.AddReplace("text", currentLine)
                entries.push(entry)
                exit for
            end if
        end if
    end for
    return entries
end function
'//# sourceMappingURL=./captionTask.brs.map