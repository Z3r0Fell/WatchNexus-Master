'import "pkg:/source/api/sdk.bs"
'import "pkg:/source/utils/config.bs"

sub init()
    m.top.functionName = "loadAlbum"
end sub

sub loadAlbum()
    data = api_items_Get({
        "UserId": m.global.session.user.id
        "parentId": m.top.id
        "includeitemtypes": "Audio"
        "sortBy": "SortName"
    })
    results = []
    row = CreateObject("roSGNode", "ContentNode")
    if not isChainValid(data, "items")
        m.top.albumDetails = row
        return
    end if
    if data.Items.Count() = 0
        m.top.albumDetails = row
        return
    end if
    for each item in data.Items
        tmp = CreateObject("roSGNode", "MusicSongData")
        tmp.id = item.LookupCI("id")
        tmp.title = item.LookupCI("name")
        tmp.type = item.LookupCI("type")
        tmp.AlbumId = item.LookupCI("AlbumId")
        tmp.ArtistItems = item.LookupCI("ArtistItems")
        tmp.artists = item.LookupCI("artists")
        tmp.RunTimeTicks = item.LookupCI("RunTimeTicks")
        tmp.trackNumber = item.LookupCI("IndexNumber")
        tmp.playCount = chainLookupReturn(item, "UserData.PlayCount", 0)
        results.push(tmp)
    end for
    row.appendChildren(results)
    m.top.albumDetails = row
end sub
'//# sourceMappingURL=./LoadAlbumTask.brs.map