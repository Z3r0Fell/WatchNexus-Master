'import "pkg:/source/utils/misc.bs"

sub init()
    getData()
end sub

sub getData()
    ' If we have no album data, return a blank node
    if not isValid(m.top.MusicArtistAlbumData)
        m.top.content = CreateObject("roSGNode", "ContentNode")
        return
    end if
    m.top.content = m.top.MusicArtistAlbumData
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        return false
    end if
    if key = "up"
        if m.top.itemFocused <= 4
            m.top.escape = key
            return true
        end if
    else if key = "left"
        if m.top.itemFocused mod 5 = 0
            m.top.escape = key
            return true
        end if
    else if key = "right"
        if m.top.itemFocused + 1 mod 5 = 0
            m.top.escape = key
            return true
        end if
    else if key = "down"
        totalCount = 0
        if isValid(m.top.MusicArtistAlbumData)
            totalCount = m.top.MusicArtistAlbumData.getChildCount()
        end if
        totalRows = div_ceiling(totalCount, 5)
        currentRow = div_ceiling(m.top.itemFocused + 1, 5)
        if currentRow = totalRows
            m.top.escape = key
            return true
        end if
    end if
    return false
end function
'//# sourceMappingURL=./AlbumGrid.brs.map