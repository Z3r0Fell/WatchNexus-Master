'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/KeyCode.bs"
'import "pkg:/source/enums/TaskControl.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.top.optionsAvailable = false
    setupMainNode()
    setupButtons()
    m.remoteButtonsActive = true
    m.albumHeader = m.top.findNode("albumHeader")
    m.albumHeader.text = tr("Albums")
    m.appearsOnHeader = m.top.findNode("appearsOnHeader")
    m.appearsOnHeader.text = tr("AppearsOn")
    m.similarArtist = m.top.findNode("similarArtist")
    m.similarArtist.focusBitmapBlendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    m.similarArtist.observeField("escape", "onSimilarArtistEscape")
    m.LoadSimilarArtistTask = CreateObject("roSGNode", "LoadItemsTask")
    m.LoadSimilarArtistTask.itemsToLoad = "similarartists"
    m.LoadSimilarArtistTask.observeField("content", "onSimilarArtistLoaded")
    m.appearsOn = m.top.findNode("appearsOn")
    m.appearsOn.focusBitmapBlendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    m.appearsOn.observeField("escape", "onAppearsOnEscape")
    m.appearsOn.observeField("MusicArtistAlbumData", "onAppearsOnData")
    m.albums = m.top.findNode("albums")
    m.albums.focusBitmapBlendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    m.albums.observeField("escape", "onAlbumsEscape")
    m.albums.observeField("MusicArtistAlbumData", "onAlbumsData")
    m.pageLoadAnimation = m.top.findNode("pageLoad")
    m.pageLoadAnimation.control = "start"
    m.sectionNavigation = m.top.findNode("sectionNavigation")
    m.sectionNavigation.observeField("escape", "onSectionNavigationEscape")
    m.sectionNavigation.observeField("selected", "onSectionNavigationSelected")
    m.sectionScroller = m.top.findNode("sectionScroller")
    m.sectionScroller.observeField("displayedIndex", "onSectionScrollerChange")
    m.overhang = m.top.getScene().findNode("overhang")
    ' Load background image
    m.LoadBackdropImageTask = CreateObject("roSGNode", "LoadItemsTask")
    m.LoadBackdropImageTask.itemsToLoad = "backdropImage"
    m.backDrop = m.top.findNode("backdrop")
    m.artistImage = m.top.findNode("artistImage")
    m.dscr = m.top.findNode("overview")
    m.dscr.ellipsisText = tr("... (Press * to read more)")
    m.dscr.observeField("isTextEllipsized", "onEllipsisChanged")
end sub

sub onAlbumsData()
    if not isValid(m.albums.MusicArtistAlbumData) or m.albums.MusicArtistAlbumData.getChildCount() = 0
        m.sectionScroller.removeChild(m.top.findNode("albumsSlide"))
        m.sectionNavigation.removeChild(m.top.findNode("albumsLink"))
        m.top.findNode("appearsOnSlide").callFunc("scrollUpToOnDeck")
    end if
end sub

sub onSimilarArtistLoaded()
    data = m.LoadSimilarArtistTask.content
    m.LoadSimilarArtistTask.unobserveField("content")
    if not isValidAndNotEmpty(data)
        m.sectionScroller.removeChild(m.top.findNode("similarArtistSlide"))
        m.sectionNavigation.removeChild(m.top.findNode("similarArtistLink"))
        return
    end if
    similarArtistData = CreateObject("roSGNode", "ContentNode")
    similarArtistData.appendChildren(data)
    m.similarArtist.content = similarArtistData
end sub

sub onAppearsOnData()
    ' We have no appears on data
    if not isValid(m.appearsOn.MusicArtistAlbumData) or m.appearsOn.MusicArtistAlbumData.getChildCount() = 0
        m.sectionScroller.removeChild(m.top.findNode("appearsOnSlide"))
        m.sectionNavigation.removeChild(m.top.findNode("appearsOnLink"))
    end if
end sub

sub onSectionScrollerChange()
    m.overhang.isVisible = (m.sectionScroller.displayedIndex = 0)
end sub

sub OnScreenShown()
    m.sectionScroller.focus = true
    if m.sectionScroller.displayedIndex = 0
        m.previouslySelectedButtonIndex = m.top.selectedButtonIndex
        m.top.selectedButtonIndex = 0
        m.buttonGrp.setFocus(true)
    else
        m.overhang.opacity = "0"
        m.overhang.isVisible = false
        m.overhang.opacity = "1"
    end if
    stopLoadingSpinner()
end sub

sub OnScreenHidden()
    if not m.overhang.isVisible
        m.overhang.disableMoveAnimation = true
        m.overhang.isVisible = true
        m.overhang.disableMoveAnimation = false
        m.overhang.opacity = "1"
    end if
end sub

sub onAlbumsEscape()
    if m.albums.escape = "up"
        m.sectionNavigation.selected = m.sectionScroller.displayedIndex - 1
    else if m.albums.escape = "left"
        m.sectionNavigation.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.sectionNavigation
    else if m.albums.escape = "down"
        if m.sectionScroller.displayedIndex + 1 < m.sectionNavigation.getChildCount()
            m.sectionNavigation.selected = m.sectionScroller.displayedIndex + 1
        end if
    end if
end sub

sub onAppearsOnEscape()
    if m.appearsOn.escape = "up"
        m.sectionNavigation.selected = m.sectionScroller.displayedIndex - 1
    else if m.appearsOn.escape = "left"
        m.sectionNavigation.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.sectionNavigation
    else if m.appearsOn.escape = "down"
        if m.sectionScroller.displayedIndex + 1 < m.sectionNavigation.getChildCount()
            m.sectionNavigation.selected = m.sectionScroller.displayedIndex + 1
        end if
    end if
end sub

sub onSimilarArtistEscape()
    if m.similarArtist.escape = "up"
        m.sectionNavigation.selected = m.sectionScroller.displayedIndex - 1
    else if m.similarArtist.escape = "left"
        m.sectionNavigation.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.sectionNavigation
    end if
end sub

' Setup playback buttons, default to Play button selected
sub setupButtons()
    m.buttonGrp = m.top.findNode("buttons")
    m.buttonCount = m.buttonGrp.getChildCount()
    m.playButton = m.top.findNode("play")
    m.playButton.focusBackground = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
    m.previouslySelectedButtonIndex = -1
    buttons = [
        "instantMix"
        "albumsLink"
        "appearsOnLink"
        "similarArtistLink"
        "detailsLink"
    ]
    for each button in buttons
        thisButton = m.top.findNode(button)
        if isValid(thisButton)
            thisButton.focusBackground = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0xff6867FF")
        end if
    end for
    m.top.observeField("selectedButtonIndex", "onButtonSelectedChange")
    m.top.selectedButtonIndex = 0
end sub

' Event handler when user selected a different playback button
sub onButtonSelectedChange()
    ' Change previously selected button back to default image
    if m.previouslySelectedButtonIndex > -1
        previousSelectedButton = m.buttonGrp.getChild(m.previouslySelectedButtonIndex)
        previousSelectedButton.focus = false
    end if
    ' Change selected button image to selected image
    selectedButton = m.buttonGrp.getChild(m.top.selectedButtonIndex)
    selectedButton.focus = true
end sub

sub setupMainNode()
    m.main = m.top.findNode("toplevel")
    m.main.translation = [
        120
        175
    ]
end sub

' Event fired when page data is loaded
sub pageContentChanged()
    item = m.top.pageContent
    ' Use metadata to load backdrop image
    m.LoadBackdropImageTask.itemId = item.json.id
    m.LoadBackdropImageTask.observeField("content", "onBackdropImageLoaded")
    m.LoadBackdropImageTask.control = "RUN"
    m.LoadSimilarArtistTask.itemId = item.json.id
    m.LoadSimilarArtistTask.control = "RUN"
    ' Populate scene data
    setScreenTitle(item.json)
    setPosterImage(item.posterURL)
end sub

sub setScreenTitle(json)
    if isValid(json)
        m.top.overhangTitle = json.name
    end if
end sub

sub setPosterImage(posterURL)
    if not isValid(posterURL) or posterURL = ""
        posterURL = "pkg:/images/missingArtist.png"
    end if
    m.artistImage.uri = posterURL
end sub

sub onBackdropImageLoaded()
    data = m.LoadBackdropImageTask.content[0]
    m.LoadBackdropImageTask.unobserveField("content")
    if isValid(data) and data <> ""
        setBackdropImage(data)
    end if
end sub

' Add backdrop image to screen
sub setBackdropImage(data)
    if isValid(data)
        if m.backDrop.uri <> data
            m.backDrop.uri = data
        end if
    end if
end sub

' Event fired when page data is loaded
sub artistOverviewChanged()
    overviewContent = m.top.artistOverview
    if isValid(overviewContent)
        setFieldTextValue("overview", overviewContent)
    end if
end sub

sub onEllipsisChanged()
    if m.dscr.isTextEllipsized
        dscrShowFocus()
    end if
end sub

sub onSectionNavigationEscape()
    if m.sectionNavigation.escape = "right"
        m.sectionNavigation.setFocus(false)
        m.remoteButtonsActive = false
        m.sectionScroller.focus = true
    end if
end sub

sub onSectionNavigationSelected()
    m.sectionScroller.displayedIndex = m.sectionNavigation.selected
end sub

sub dscrShowFocus()
    if m.dscr.isTextEllipsized
        m.dscr.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.dscr
        m.dscr.opacity = 1.0
    end if
end sub

sub createFullDscrDlg()
    if isAllValid([
        m.top.overhangTitle
        m.dscr.text
    ])
        m.global.sceneManager.callFunc("standardDialog", m.top.overhangTitle, {
            data: [
                "<p>" + m.dscr.text + "</p>"
            ]
        })
    end if
end sub

sub onButtonGroupFocus()
    m.previouslySelectedButtonIndex = m.top.selectedButtonIndex
    m.top.selectedButtonIndex = 0
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if m.buttonGrp.isInFocusChain()
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.buttonGrp
        if key = "replay"
            if m.top.selectedButtonIndex = 0 then
                return false
            end if
            selectedButton = m.buttonGrp.getChild(m.top.selectedButtonIndex)
            selectedButton.focus = false
            m.previouslySelectedButtonIndex = m.top.selectedButtonIndex
            m.top.selectedButtonIndex = 0
            return false
        end if
        if key = "OK"
            if press
                selectedButton = m.buttonGrp.getChild(m.top.selectedButtonIndex)
                selectedButton.selected = not selectedButton.selected
                return true
            end if
        end if
        if key = "left"
            if m.top.selectedButtonIndex > 0
                m.previouslySelectedButtonIndex = m.top.selectedButtonIndex
                m.top.selectedButtonIndex = m.top.selectedButtonIndex - 1
                return true
            end if
            if press
                selectedButton = m.buttonGrp.getChild(m.top.selectedButtonIndex)
                selectedButton.focus = false
                m.sectionNavigation.setFocus(true)
                group = m.global.sceneManager.callFunc("getActiveScene")
                group.lastFocus = m.sectionNavigation
                return true
            end if
            return false
        end if
        if key = "right"
            if m.top.pageContent.count() = 1 then
                return false
            end if
            if m.buttonGrp.getChild(m.top.selectedButtonIndex).escape = "right"
                m.buttonGrp.getChild(m.top.selectedButtonIndex).escape = ""
                m.previouslySelectedButtonIndex = m.top.selectedButtonIndex
                if m.top.selectedButtonIndex < m.buttonCount - 1
                    m.top.selectedButtonIndex = m.top.selectedButtonIndex + 1
                    group = m.global.sceneManager.callFunc("getActiveScene")
                    group.lastFocus = m.buttonGrp
                end if
                return true
            end if
        end if
        if key = "down"
            if m.sectionNavigation.getChildCount() > 1
                selectedButton = m.buttonGrp.getChild(m.top.selectedButtonIndex)
                selectedButton.focus = false
                m.top.selectedButtonIndex = 0
                m.sectionNavigation.selected = m.sectionScroller.displayedIndex + 1
            end if
        end if
    end if
    if not press then
        return false
    end if
    if key = "options"
        if m.dscr.isTextEllipsized
            createFullDscrDlg()
            return true
        end if
    end if
    if isStringEqual(key, "OK")
        if isValid(m.similarArtist) and m.similarArtist.isInFocusChain()
            m.top.similarArtistSelected = m.similarArtist.content.getChild(m.similarArtist.itemFocused)
            return true
        end if
    end if
    if isStringEqual(key, "play")
        itemToPlay = invalid
        if isValid(m.albums) and m.albums.isInFocusChain()
            itemToPlay = m.albums.MusicArtistAlbumData.getChild(m.albums.itemFocused)
        else if isValid(m.appearsOn) and m.appearsOn.isInFocusChain()
            itemToPlay = m.appearsOn.MusicArtistAlbumData.getChild(m.appearsOn.itemFocused)
        else if isValid(m.similarArtist) and m.similarArtist.isInFocusChain()
            itemToPlay = m.similarArtist.content.getChild(m.similarArtist.itemFocused)
        end if
        if isValid(itemToPlay)
            m.top.quickPlayNode = itemToPlay
            return true
        end if
    end if
    return false
end function
'//# sourceMappingURL=./ArtistView.brs.map