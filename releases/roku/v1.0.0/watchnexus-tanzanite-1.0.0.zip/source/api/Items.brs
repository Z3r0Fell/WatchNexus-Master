'import "pkg:/source/api/sdk.bs"
'import "pkg:/source/enums/PlaybackMethod.bs"
'import "pkg:/source/enums/SubtitleSelection.bs"

function ItemGetPlaybackInfo(id as string, startTimeTicks = 0 as longinteger)
    params = {
        "UserId": m.global.session.user.id
        "StartTimeTicks": startTimeTicks
        "IsPlayback": true
        "AutoOpenLiveStream": true
        "MaxStreamingBitrate": "140000000"
    }
    resp = APIRequest(Substitute("Items/{0}/PlaybackInfo", id), params)
    return getJson(resp)
end function

function ItemPostPlaybackInfo(id as string, mediaSourceId = "" as string, audioTrackIndex = -1 as integer, subtitleTrackIndex = -1 as integer, startTimeTicks = 0 as longinteger, options = {} as object)
    transcodeCodec = ""
    if isStringEqual(m.global.queueManager.callFunc("getForceTranscode"), "forceTranscodeDisableRemux")
        transcodeCodec = m.global.queueManager.callFunc("getTranscodeCodec")
    end if
    burnInSubtitles = chainLookupReturn(m.global, "session.user.settings.`playback.subs.burnin`", true)
    body = {
        "DeviceProfile": getDeviceProfile(transcodeCodec)
        "AlwaysBurnInSubtitleWhenTranscoding": burnInSubtitles
    }
    params = {
        "UserId": m.global.session.user.id
        "StartTimeTicks": startTimeTicks
        "IsPlayback": true
        "AutoOpenLiveStream": true
        "MaxStreamingBitrate": "140000000"
        "MaxStaticBitrate": "140000000"
        "SubtitleStreamIndex": subtitleTrackIndex
    }
    if isStringEqual(m.global.queueManager.callFunc("getForceTranscode"), "forceLiveTvRemux")
        ' We are playing live tv and direct play failed, let's try again but with force remuxing...
        params.EnableDirectPlay = false
    end if
    if chainLookupReturn(options, "emptySubtitleProfiles", false)
        body.DeviceProfile.SubtitleProfiles = []
    end if
    if mediaSourceId <> ""
        params.MediaSourceId = mediaSourceId
    else
        ' Note: WatchNexus v10.9 remuxs LiveTV and does not allow DirectPlay.
        ' Because of this, we need to tell the server "EnableDirectPlay = false" so that we receive the
        ' transcoding URL (which is just a remux and not a transcode; unless it is)
        ' The web handles this by disabling EnableDirectPlay on a Retry, but we don't currently Retry a Live
        ' TV stream, thus we just turn it off on the first try here.
        serverVersion = ServerInfo().LookupCI("version")
        if not serverVersionMeetsMinimumRequirements(serverVersion, [
            10
            10
            0
        ])
            params.EnableDirectPlay = false
        end if
    end if
    if audioTrackIndex > -1 then
        params.AudioStreamIndex = audioTrackIndex
    end if
    req = APIRequest(Substitute("Items/{0}/PlaybackInfo", id), params)
    req.SetRequest("POST")
    return postJson(req, FormatJson(body))
end function

function searchMedia(query as string)
    if query <> ""
        ' Everything except Live TV shows (but including TV Channels)
        data = api_items_Get({
            "userid": m.global.session.user.id
            "searchTerm": query
            "fields": "ChildCount, ItemCounts, Genres, RecursiveItemCount"
            "IncludeItemTypes": "LiveTvChannel,Movie,BoxSet,Series,Episode,Video,Audio,MusicAlbum,MusicArtist,Playlist"
            "EnableTotalRecordCount": false
            "ImageTypeLimit": 1
            "Recursive": true
            "limit": 100
        })
        people = api_persons_Get({
            "userid": m.global.session.user.id
            "searchTerm": query
            "EnableTotalRecordCount": false
            "ImageTypeLimit": 1
            "limit": 100
        })
        if isValid(data) and isValid(people)
            ' we've got both regular stuff and people
            data.Items.Append(people.Items)
        else if isValid(people)
            ' we only have people
            data = people
        end if
        ' Separate query so that we can get all programs just like the Web Client
        liveTv = api_items_Get({
            "userid": m.global.session.user.id
            "searchTerm": query
            "IncludeItemTypes": "LiveTvProgram"
            "EnableTotalRecordCount": false
            "ImageTypeLimit": 1
            "Recursive": true
            "limit": 100
            "IsMovie": false
            "IsSeries": false
            "IsSports": false
            "IsNews": false
            "IsKids": false
        })
        if isValid(data) and isValid(liveTv)
            ' we've got both regular stuff and live tv
            data.Items.Append(liveTv.Items)
        else if isValid(liveTv)
            ' we only have live tv
            data = liveTv
        else if not isValid(data)
            ' we have neither
            return []
        end if
        results = []
        for each item in data.Items
            tmp = CreateObject("roSGNode", "SearchData")
            tmp.image = PosterImage(item.id)
            tmp.id = item.LookupCI("id")
            tmp.title = item.LookupCI("name")
            tmp.AlbumArtist = item.LookupCI("AlbumArtist")
            tmp.album = item.LookupCI("album")
            tmp.type = item.LookupCI("type")
            tmp.RunTimeTicks = item.LookupCI("RunTimeTicks")
            tmp.ProductionYear = item.LookupCI("ProductionYear")
            tmp.EndDate = item.LookupCI("EndDate")
            tmp.OfficialRating = item.LookupCI("OfficialRating")
            tmp.IndexNumber = item.LookupCI("IndexNumber")
            tmp.seriesname = item.LookupCI("seriesname")
            tmp.SeasonName = item.LookupCI("SeasonName")
            tmp.IndexNumberEnd = item.LookupCI("IndexNumberEnd")
            tmp.ParentIndexNumber = item.LookupCI("ParentIndexNumber")
            tmp.json = item
            results.push(tmp)
        end for
        data.Items = results
        return data
    end if
    return []
end function

' MetaData about an item
function ItemMetaData(id as string)
    url = Substitute("Items/{0}", id)
    resp = APIRequest(url, {
        userid: m.global.session.user.id
        fields: "Chapters,Trickplay"
    })
    data = getJson(resp)
    if not isValidAndNotEmpty(data) then
        return invalid
    end if
    imgParams = {}
    if data.type <> "Audio"
        if data.UserData <> invalid and data.UserData.PlayedPercentage <> invalid
            param = {
                "PercentPlayed": data.UserData.PlayedPercentage
            }
            imgParams.Append(param)
        end if
    end if
    if data.type = "Movie" or data.type = "MusicVideo"
        tmp = CreateObject("roSGNode", "MovieData")
        tmp.image = PosterImage(data.id, imgParams)
        tmp.json = data
        return tmp
    else if data.type = "Series"
        tmp = CreateObject("roSGNode", "SeriesData")
        tmp.image = PosterImage(data.id)
        tmp.json = data
        return tmp
    else if data.type = "Episode"
        tmp = CreateObject("roSGNode", "TVEpisodeData")
        tmp.image = PosterImage(data.id, imgParams)
        tmp.json = data
        return tmp
    else if data.type = "Recording"
        tmp = CreateObject("roSGNode", "RecordingData")
        tmp.image = PosterImage(data.id, imgParams)
        tmp.json = data
        return tmp
    else if data.type = "BoxSet" or data.type = "Playlist"
        tmp = CreateObject("roSGNode", "CollectionData")
        tmp.image = PosterImage(data.id, imgParams)
        tmp.json = data
        return tmp
    else if data.type = "Season"
        tmp = CreateObject("roSGNode", "TVSeasonData")
        tmp.image = PosterImage(data.id)
        tmp.json = data
        return tmp
    else if data.type = "Video"
        tmp = CreateObject("roSGNode", "VideoData")
        tmp.image = PosterImage(data.id)
        tmp.json = data
        return tmp
    else if data.type = "Trailer"
        tmp = CreateObject("roSGNode", "VideoData")
        tmp.json = data
        return tmp
    else if data.type = "Folder"
        tmp = CreateObject("roSGNode", "FolderData")
        tmp.json = data
        return tmp
    else if data.type = "TvChannel" or data.type = "Program"
        tmp = CreateObject("roSGNode", "ChannelData")
        tmp.image = PosterImage(data.id)
        tmp.isFavorite = data.UserData.isFavorite
        tmp.json = data
        return tmp
    else if data.type = "Person"
        tmp = CreateObject("roSGNode", "PersonData")
        tmp.image = PosterImage(data.id, {
            "MaxWidth": 300
            "MaxHeight": 450
        })
        tmp.json = data
        return tmp
    else if data.type = "MusicArtist"
        ' User clicked on an artist and wants to see the list of their albums
        tmp = CreateObject("roSGNode", "MusicArtistData")
        tmp.image = PosterImage(data.id)
        tmp.json = data
        return tmp
    else if data.type = "MusicAlbum"
        ' User clicked on an album and wants to see the list of songs
        tmp = CreateObject("roSGNode", "MusicAlbumSongListData")
        tmp.image = PosterImage(data.id)
        tmp.json = data
        return tmp
    else if data.type = "Audio"
        ' User clicked on a song and wants it to play
        tmp = CreateObject("roSGNode", "MusicSongData")
        ' Try using song's parent for poster image
        tmp.image = PosterImage(data.ParentId, {
            "MaxWidth": 500
            "MaxHeight": 500
        })
        ' Song's parent poster image is no good, try using the song's poster image
        if tmp.image = invalid
            tmp.image = PosterImage(data.id, {
                "MaxWidth": 500
                "MaxHeight": 500
            })
        end if
        tmp.json = data
        return tmp
    else if data.type = "AudioBook"
        tmp = CreateObject("roSGNode", "MusicSongData")
        ' Try using song's parent for poster image
        tmp.image = PosterImage(data.id, {
            "MaxWidth": 500
            "MaxHeight": 500
        })
        ' Song's parent poster image is no good, try using the song's poster image
        if not isValid(tmp.image)
            tmp.image = PosterImage(data.ParentId, {
                "MaxWidth": 500
                "MaxHeight": 500
            })
        end if
        tmp.json = data
        return tmp
    else if data.type = "Recording"
        ' We know it's "Recording", but we don't do any special preprocessing
        ' for this data type at the moment, so just return the json.
        return data
    else
        print "Items.brs::ItemMetaData processed unhandled type: " data.type
        ' Return json if we don't know what it is
        return data
    end if
end function

' Music Artist Data
function ArtistOverview(name as string)
    req = createObject("roUrlTransfer")
    url = Substitute("Artists/{0}", req.escape(name))
    resp = APIRequest(url)
    data = getJson(resp)
    if data = invalid then
        return invalid
    end if
    return data.overview
end function

' Get list of albums belonging to an artist
function MusicAlbumList(id as string)
    params = {
        "UserId": m.global.session.user.id
        "AlbumArtistIds": id
        "includeitemtypes": "MusicAlbum"
        "sortBy": "SortName"
        "Recursive": true
    }
    data = api_items_Get(params)
    results = []
    row = CreateObject("roSGNode", "ContentNode")
    if not isValid(data) then
        return invalid
    end if
    if not isValidAndNotEmpty(chainLookup(data, "Items")) then
        return invalid
    end if
    for each item in data.Items
        tmp = CreateObject("roSGNode", "MusicAlbumData")
        tmp.image = PosterImage(item.id)
        tmp.id = item.LookupCI("id")
        tmp.title = item.LookupCI("name")
        tmp.type = item.LookupCI("type")
        tmp.RunTimeTicks = item.LookupCI("RunTimeTicks")
        tmp.shortdescriptionline1 = item.LookupCI("name")
        if isChainValid(tmp, "image.url")
            tmp.HDGRIDPOSTERURL = tmp.image.url
            tmp.hdposterurl = tmp.image.url
            tmp.SDGRIDPOSTERURL = tmp.image.url
            tmp.sdposterurl = tmp.image.url
        end if
        results.push(tmp)
    end for
    row.appendChildren(results)
    return row
end function

' Get list of albums an artist appears on
function AppearsOnList(id as string)
    params = {
        "UserId": m.global.session.user.id
        "ContributingArtistIds": id
        "ExcludeItemIds": id
        "includeitemtypes": "MusicAlbum"
        "sortBy": "PremiereDate,ProductionYear,SortName"
        "SortOrder": "Descending"
        "Recursive": true
    }
    data = api_items_Get(params)
    results = []
    row = CreateObject("roSGNode", "ContentNode")
    if not isValid(data) then
        return invalid
    end if
    if not isValidAndNotEmpty(chainLookup(data, "Items")) then
        return invalid
    end if
    for each item in data.Items
        tmp = CreateObject("roSGNode", "MusicAlbumData")
        tmp.image = PosterImage(item.id)
        tmp.id = item.LookupCI("id")
        tmp.title = item.LookupCI("name")
        tmp.type = item.LookupCI("type")
        tmp.RunTimeTicks = item.LookupCI("RunTimeTicks")
        tmp.shortdescriptionline1 = item.LookupCI("name")
        if isChainValid(tmp, "image.url")
            tmp.HDGRIDPOSTERURL = tmp.image.url
            tmp.hdposterurl = tmp.image.url
            tmp.SDGRIDPOSTERURL = tmp.image.url
            tmp.sdposterurl = tmp.image.url
        end if
        results.push(tmp)
    end for
    row.appendChildren(results)
    return row
end function

' Get list of songs belonging to an artist
function GetSongsByArtist(id as string, params = {} as object)
    paramArray = {
        "UserId": m.global.session.user.id
        "AlbumArtistIds": id
        "includeitemtypes": "Audio"
        "sortBy": "SortName"
        "Recursive": true
    }
    ' overwrite defaults with the params provided
    for each param in params
        paramArray.AddReplace(param, params[param])
    end for
    data = api_items_Get(paramArray)
    results = []
    row = CreateObject("roSGNode", "ContentNode")
    if not isValid(data) then
        return invalid
    end if
    if not isValidAndNotEmpty(chainLookup(data, "Items")) then
        return invalid
    end if
    for each item in data.Items
        tmp = CreateObject("roSGNode", "MusicSongData")
        tmp.id = item.LookupCI("id")
        tmp.title = item.LookupCI("name")
        tmp.type = item.LookupCI("type")
        tmp.RunTimeTicks = item.LookupCI("RunTimeTicks")
        tmp.trackNumber = item.LookupCI("IndexNumber")
        results.push(tmp)
    end for
    row.appendChildren(results)
    return row
end function

' Get Items that are under the provided item
function PlaylistItemList(id as string)
    url = Substitute("Playlists/{0}/Items", id)
    resp = APIRequest(url, {
        "UserId": m.global.session.user.id
    })
    results = []
    data = getJson(resp)
    row = CreateObject("roSGNode", "ContentNode")
    if data = invalid then
        return row
    end if
    if data.Items = invalid then
        return row
    end if
    if data.Items.Count() = 0 then
        return row
    end if
    for each item in data.Items
        tmp = CreateObject("roSGNode", "PlaylistItemData")
        tmp.id = item.LookupCI("id")
        tmp.title = item.LookupCI("name")
        tmp.artists = item.LookupCI("artists")
        tmp.album = item.LookupCI("album")
        tmp.type = item.LookupCI("type")
        tmp.RunTimeTicks = item.LookupCI("RunTimeTicks")
        tmp.ProductionYear = item.LookupCI("ProductionYear")
        tmp.OfficialRating = item.LookupCI("OfficialRating")
        tmp.IndexNumber = item.LookupCI("IndexNumber")
        tmp.seriesname = item.LookupCI("seriesname")
        tmp.SeasonName = item.LookupCI("SeasonName")
        tmp.IndexNumberEnd = item.LookupCI("IndexNumberEnd")
        tmp.ParentIndexNumber = item.LookupCI("ParentIndexNumber")
        tmp.played = chainLookupReturn(item, "UserData.played", false)
        results.push(tmp)
    end for
    row.appendChildren(results)
    return row
end function

' Get Songs that are on an Album
function MusicSongList(id as string)
    params = {
        "UserId": m.global.session.user.id
        "parentId": id
        "includeitemtypes": "Audio"
        "sortBy": "SortName"
    }
    data = api_items_Get(params)
    results = []
    row = CreateObject("roSGNode", "ContentNode")
    if not isValid(data) then
        return invalid
    end if
    if not isValidAndNotEmpty(chainLookup(data, "Items")) then
        return invalid
    end if
    for each item in data.Items
        tmp = CreateObject("roSGNode", "MusicSongData")
        tmp.id = item.LookupCI("id")
        tmp.title = item.LookupCI("name")
        tmp.type = item.LookupCI("type")
        tmp.AlbumId = item.LookupCI("AlbumId")
        tmp.ArtistItems = item.LookupCI("ArtistItems")
        tmp.artists = item.LookupCI("artists")
        tmp.RunTimeTicks = item.LookupCI("RunTimeTicks")
        tmp.trackNumber = item.LookupCI("IndexNumber")
        tmp.playCount = chainLookupReturn(item, "UserData.PlayCount", 0)
        results.push(tmp)
    end for
    row.appendChildren(results)
    return row
end function

' Get Audio Item Data
function AudioItem(id as string)
    return api_items_GetByID(id, {
        "UserId": m.global.session.user.id
        "includeitemtypes": "Audio"
        "sortBy": "SortName"
    })
end function

' Get Instant Mix based on item
function CreateInstantMix(id as string)
    return api_items_GetInstantMix(id, {
        "UserId": m.global.session.user.id
        "Limit": 201
    })
end function

' Get Mix of items from artist
function CreateArtistMix(id as string)
    params = {
        "UserId": m.global.session.user.id
        "ArtistIds": id
        "Recursive": "true"
        "MediaTypes": "Audio"
        "Filters": "IsNotFolder"
        "SortBy": "SortName"
        "Limit": 300
        "Fields": "Chapters"
        "ExcludeLocationTypes": "Virtual"
        "EnableTotalRecordCount": false
        "CollapseBoxSetItems": false
    }
    return api_items_Get(params)
end function

' Get Intro Videos for an item
function GetIntroVideos(id as string)
    return api_items_GetIntros(id, {
        "UserId": m.global.session.user.id
    })
end function

function AudioStream(id as string)
    songData = AudioItem(id)
    if songData <> invalid
        content = createObject("RoSGNode", "AudioStreamData")
        if songData.title <> invalid
            content.title = songData.title
        end if
        content.hasLyrics = songData.hasLyrics
        if isValid(songData.HasLyrics)
            content.lyricData = api_audio_GetLyrics(id)
        end if
        playbackInfo = ItemPostPlaybackInfo(songData.id, songData.mediaSources[0].id)
        if playbackInfo <> invalid
            content.id = playbackInfo.PlaySessionId
            if useTranscodeAudioStream(playbackInfo)
                ' Transcode the audio
                content.url = buildURL(playbackInfo.mediaSources[0].TranscodingURL)
            else
                ' Direct Stream the audio
                params = {
                    "Static": "true"
                    "Container": songData.mediaSources[0].container
                    "MediaSourceId": songData.mediaSources[0].id
                }
                content.streamformat = songData.mediaSources[0].container
                content.url = buildURL(Substitute("Audio/{0}/stream", songData.id), params)
            end if
        else
            return invalid
        end if
        return content
    else
        return invalid
    end if
end function

function useTranscodeAudioStream(playbackInfo)
    return playbackInfo.mediaSources[0] <> invalid and playbackInfo.mediaSources[0].TranscodingURL <> invalid
end function

function BackdropImage(id as string)
    imgParams = {
        "maxHeight": "720"
        "maxWidth": "1280"
    }
    return ImageURL(id, "Backdrop", imgParams)
end function

function getFirstEpisodeImage(showId as string, seasonId as string)
    listOfEpisodes = api_shows_GetEpisodes(showId, {
        seasonId: seasonId
        UserId: m.global.session.user.id
        limit: 5
        enableUserData: false
        imageTypeLimit: 1
        EnableImageTypes: "Primary"
    })
    for each episode in listOfEpisodes.LookupCI("items")
        if isChainValid(episode, "imagetags.primary")
            return ImageURL(episode.LookupCI("id"), "Primary", {
                tag: chainLookup(episode, "imagetags.primary")
            })
        end if
    end for
    return invalid
end function

' Returns a list of TV Shows for a given TV Show and season
' Accepts strings for the TV Show Id and the season Id
function TVEpisodes(showId as string, seasonId as string) as dynamic
    ' Get and validate data
    data = api_shows_GetEpisodes(showId, {
        "seasonId": seasonId
        "UserId": m.global.session.user.id
        "fields": "MediaStreams,MediaSources"
    })
    if data = invalid or data.Items = invalid then
        return invalid
    end if
    results = []
    for each item in data.Items
        tmp = CreateObject("roSGNode", "TVEpisodeData")
        tmp.image = PosterImage(item.id, {
            "maxWidth": 400
            "maxheight": 250
        })
        if isValid(tmp.image)
            tmp.image.posterDisplayMode = "scaleToZoom"
        end if
        tmp.json = item
        tmpMetaData = ItemMetaData(item.id)
        ' validate meta data
        if isValid(tmpMetaData) and isValid(tmpMetaData.overview)
            tmp.overview = tmpMetaData.overview
        end if
        results.push(tmp)
    end for
    data.Items = results
    return data
end function

' Returns a list of extra features for a TV Show season
' Accepts a string that is a TV Show season id
function TVSeasonExtras(seasonId as string) as dynamic
    ' Get and validate TV extra features data
    data = api_items_GetSpecialFeatures(seasonId, {
        userid: m.global.session.user.id
    })
    if not isValid(data) then
        return invalid
    end if
    results = []
    for each item in data
        tmp = CreateObject("roSGNode", "TVEpisodeData")
        tmp.image = PosterImage(item.id, {
            "maxWidth": 400
            "maxheight": 250
        })
        tmp.json = item
        ' Force item type to Video so episode auto queue is not attempted
        tmp.type = "Video"
        tmpMetaData = ItemMetaData(item.id)
        ' Validate meta data
        if isValid(tmpMetaData) and isValid(tmpMetaData.overview)
            tmp.overview = tmpMetaData.overview
        end if
        results.push(tmp)
    end for
    return {
        Items: results
    }
end function

function TVEpisodeShuffleList(show_id as string)
    url = Substitute("Shows/{0}/Episodes", show_id)
    resp = APIRequest(url, {
        "UserId": m.global.session.user.id
        "Limit": 200
        "sortBy": "Random"
        "isMissing": false
    })
    data = getJson(resp)
    results = []
    for each item in data.Items
        tmp = CreateObject("roSGNode", "TVEpisodeData")
        tmp.json = item
        results.push(tmp)
    end for
    data.Items = results
    return data
end function
'//# sourceMappingURL=./Items.brs.map