' these are needed for ServerInfo() inside session.server.Populate()
'import "pkg:/source/api/baserequest.bs"
'import "pkg:/source/api/userauth.bs"
'import "pkg:/source/enums/LiveTVScreen.bs"
'import "pkg:/source/enums/String.bs"
'import "pkg:/source/utils/misc.bs"
' Initialize the global session array
sub session_Init()
    m.global.addFields({
        session: {
            "memoryLevel": "normal"
            server: {}
            user: {
                Configuration: {}
                Policy: {}
                settings: {}
                lastRunVersion: invalid
            }
        }
    })
    session_user_settings_SaveDefaults()
end sub

' Empty the global session array
sub session_Delete()
    session_server_Delete()
    session_user_Logout()
end sub

' Update one value from the global session array (m.global.session)
sub session_Update(key as string, value = {} as object)
    ' validate parameters
    if key = "" or (key <> "user" and key <> "server") or value = invalid
        print "Error in session.Update(): Invalid parameters provided"
        return
    end if
    ' make copy of global session array
    tmpSession = m.global.session
    ' update the temp session array
    tmpSession.AddReplace(key, value)
    ' use the temp session array to update the global node
    m.global.setFields({
        session: tmpSession
    })
end sub
' Empty the global server session array
sub session_server_Delete()
    session_Update("server")
end sub

' Add or update one value from the global server session array (m.global.session.server)
sub session_server_Update(key as string, value as dynamic)
    ' validate parameters
    if key = "" or value = invalid then
        return
    end if
    ' make copy of global server session array
    tmpSessionServer = m.global.session.server
    ' update the temp server array
    tmpSessionServer[key] = value
    session_Update("server", tmpSessionServer)
end sub

' Add or update the jellyfin server URL from the global server session array (m.global.session.server)
' Returns a boolean based on if a connection to the WatchNexus server was made
function session_server_UpdateURL(value as string) as boolean
    ' validate parameters
    if value = "" then
        return false
    end if
    session_server_Update("url", value)
    success = session_server_Populate()
    if not success
        session_server_Delete()
    end if
    return success
end function

' Use the saved server url to populate the global server session array (m.global.session.server)
' Returns a boolean based on if a connection to the WatchNexus server was made
function session_server_Populate() as boolean
    ' validate server url
    if m.global.session.server.url = invalid or m.global.session.server.url = "" then
        return false
    end if
    ' get server info using API
    myServerInfo = ServerInfo()
    ' validate data returned from API
    if myServerInfo.id = invalid then
        return false
    end if
    ' make copy of global server session
    tmpSessionServer = m.global.session.server
    ' update the temp array
    tmpSessionServer.AddReplace("id", myServerInfo.Id)
    tmpSessionServer.AddReplace("name", myServerInfo.ServerName)
    tmpSessionServer.AddReplace("localURL", myServerInfo.LocalAddress)
    tmpSessionServer.AddReplace("os", myServerInfo.OperatingSystem)
    tmpSessionServer.AddReplace("startupWizardCompleted", myServerInfo.StartupWizardCompleted)
    tmpSessionServer.AddReplace("version", myServerInfo.Version)
    tmpSessionServer.AddReplace("hasError", myServerInfo.error)
    ' check urls for https
    isServerHTTPS = false
    if tmpSessionServer.url.left(8) = "https://" then
        isServerHTTPS = true
    end if
    tmpSessionServer.AddReplace("isHTTPS", isServerHTTPS)
    isLocalServerHTTPS = false
    if myServerInfo.LocalAddress <> invalid and myServerInfo.LocalAddress.left(8) = "https://" then
        isLocalServerHTTPS = true
    end if
    tmpSessionServer.AddReplace("isLocalHTTPS", isLocalServerHTTPS)
    ' update global server session using the temp array
    session_Update("server", tmpSessionServer)
    return true
end function
' Add or update one value from the global user session array (m.global.session.user)
sub session_user_Update(key as string, value as dynamic)
    ' validate parameters
    if key = "" or value = invalid then
        return
    end if
    ' make copy of global user session
    tmpSessionUser = m.global.session.user
    ' update the temp user array
    tmpSessionUser[key] = value
    ' keep friendlyName in sync
    if LCase(key) = "name"
        regex = CreateObject("roRegex", "[^a-zA-Z0-9\-\_]", "")
        tmpSessionUser["friendlyName"] = regex.ReplaceAll(value, "")
    end if
    ' update global user session using the temp array
    session_Update("user", tmpSessionUser)
    ' keep auth header in sync
    if LCase(key) = "name"
        session_user_SetServerDeviceName()
    end if
end sub

' Update the global session after user is authenticated.
' Accepts a UserData.xml object from get_token() or an assocArray from AboutMe()
sub session_user_Login(userData as object, saveCredentials = false as boolean)
    ' validate parameters
    if userData = invalid or userData.id = invalid then
        return
    end if
    ' make copy of global user session array
    tmpSession = m.global.session
    oldUserSettings = tmpSession.user.settings
    if userData.json = invalid
        ' we were passed data from AboutMe()
        myAuthToken = tmpSession.user.authToken
        tmpSession.AddReplace("user", userData)
        tmpSession.user.AddReplace("authToken", myAuthToken)
    else
        ' we were passed data from a UserData object
        tmpSession.AddReplace("user", userData.json.User)
        tmpSession.user.AddReplace("authToken", userData.json.AccessToken)
    end if
    ' remove special characters from name
    regex = CreateObject("roRegex", "[^a-zA-Z0-9\-\_]", "")
    friendlyName = regex.ReplaceAll(tmpSession.user.name, "")
    tmpSession.user.AddReplace("friendlyName", friendlyName)
    tmpSession.user.AddReplace("settings", oldUserSettings)
    ' update global user session
    session_Update("user", tmpSession.user)
    ' grab lastRunVersion for this user
    lastRunVersion = get_user_setting("LastRunVersion")
    if isValid(lastRunVersion)
        session_user_Update("LastRunVersion", lastRunVersion)
    end if
    ' update user session settings with values from registry
    userSettings = RegistryReadAll(tmpSession.user.id)
    for each setting in userSettings
        ' don't add auth token to user session
        if setting <> "token"
            session_user_settings_Save(setting, userSettings[setting])
        end if
    end for
    set_user_setting("serverId", m.global.session.server.id)
    if saveCredentials
        set_user_setting("token", tmpSession.user.authToken)
        set_user_setting("username", tmpSession.user.name)
    end if
    if m.global.session.user.settings["global.rememberme"]
        set_setting("active_user", tmpSession.user.id)
    end if
    user = CreateObject("roSGNode", "UserData")
    user.json = tmpSession
    user.callFunc("saveToRegistry")
    ' Save device id so we don't calculate it every time we need it
    session_user_SetServerDeviceName()
    ' Load user preferences from server
    session_user_LoadUserPreferences()
end sub

' Sets the global server device name value used by the API
sub session_user_SetServerDeviceName()
    localGlobal = m.global
    ' default device name is the unique id for the device
    deviceName = localGlobal.device.id
    if isChainValid(localGlobal, "session.user.friendlyName")
        deviceName = deviceName + localGlobal.session.user.friendlyName
    end if
    ' update global if needed
    if localGlobal.device.serverDeviceName <> deviceName
        tmpDevice = localGlobal.device
        tmpDevice.AddReplace("serverDeviceName", deviceName)
        m.global.setFields({
            device: tmpDevice
        })
    end if
end sub

' Load and parse Display Settings from server
sub session_user_LoadUserPreferences()
    id = m.global.session.user.id
    ' Currently using client "emby", which is what website uses so we get same Display prefs as web.
    ' May want to change to specific Roku display settings
    url = Substitute("DisplayPreferences/usersettings?userId={0}&client=emby", id)
    resp = APIRequest(url)
    jsonResponse = getJson(resp)
    if isValid(jsonResponse) and isValid(jsonResponse.CustomPrefs)
        ' save useEpisodeImagesInNextUpAndResume to global session
        tmpSetting = jsonResponse.CustomPrefs.useEpisodeImagesInNextUpAndResume
        if isValid(tmpSetting)
            tmpConfig = m.global.session.user.Configuration
            tmpConfig.AddReplace("useEpisodeImagesInNextUpAndResume", toBoolean(tmpSetting))
            session_user_Update("Configuration", tmpConfig)
        end if
        session_user_SaveUserGuideSettings(jsonResponse.CustomPrefs)
        session_user_SaveUserHomeSections(jsonResponse.CustomPrefs)
    else
        homeSection0 = chainLookupReturn(m.global, "session.user.settings.homeScreenSection0", "smalllibrarytiles")
        homeSection1 = chainLookupReturn(m.global, "session.user.settings.homeScreenSection1", "resume")
        homeSection2 = chainLookupReturn(m.global, "session.user.settings.homeScreenSection2", "nextup")
        homeSection3 = chainLookupReturn(m.global, "session.user.settings.homeScreenSection3", "latestmedia")
        homeSection4 = chainLookupReturn(m.global, "session.user.settings.homeScreenSection4", "livetv")
        homeSection5 = chainLookupReturn(m.global, "session.user.settings.homeScreenSection5", "mylist")
        homeSection6 = chainLookupReturn(m.global, "session.user.settings.homeScreenSection6", "favorites")
        homeSection7 = chainLookupReturn(m.global, "session.user.settings.homeScreenSection7", "none")
        ' User has no custom prefs. Save default home section values.
        session_user_SaveUserHomeSections({
            homesection0: homeSection0
            homesection1: homeSection1
            homesection2: homeSection2
            homesection3: homeSection3
            homesection4: homeSection4
            homesection5: homeSection5
            homesection6: homeSection6
            homesection7: homeSection7
        })
    end if
end sub

' Saves user's Live TV guide settings as Roku guide user settings.
sub session_user_SaveUserGuideSettings(customPrefs as object)
    displayLive = "true"
    displayRepeat = "false"
    displayScreen = "guide"
    if isValid(customPrefs)
        userPreferenceDisplayLive = customPrefs["guide-indicator-live"]
        userPreferenceDisplayRepeat = customPrefs["guide-indicator-repeat"]
        userPreferenceDisplayScreen = customPrefs["landing-livetv"]
        if isValidAndNotEmpty(userPreferenceDisplayLive)
            displayLive = userPreferenceDisplayLive
        end if
        if isValidAndNotEmpty(userPreferenceDisplayRepeat)
            displayRepeat = userPreferenceDisplayRepeat
        end if
        if isStringEqual(userPreferenceDisplayScreen, "channels")
            ' Live TV has five options but Roku only supports guide and channels in this context
            displayScreen = userPreferenceDisplayScreen
        end if
    end if
    set_user_setting("ui.guide.indicator.live", displayLive)
    set_user_setting("ui.guide.indicator.repeat", displayRepeat)
    set_user_setting("display.livetv.landing", displayScreen)
end sub

' Saves user's web client home sections as Roku user settings.
' Handles unsupported sections and ignores duplicates.
sub session_user_SaveUserHomeSections(customPrefs as object)
    userPreferences = customPrefs
    rowTypes = []
    useWebSectionArrangement = m.global.session.user.settings["ui.home.useWebSectionArrangement"]
    if isValid(useWebSectionArrangement)
        if not useWebSectionArrangement
            userPreferences.delete("homesection0")
        end if
    end if
    homeSection0 = chainLookupReturn(m.global, "session.user.settings.homeScreenSection0", "smalllibrarytiles")
    homeSection1 = chainLookupReturn(m.global, "session.user.settings.homeScreenSection1", "resume")
    homeSection2 = chainLookupReturn(m.global, "session.user.settings.homeScreenSection2", "nextup")
    homeSection3 = chainLookupReturn(m.global, "session.user.settings.homeScreenSection3", "latestmedia")
    homeSection4 = chainLookupReturn(m.global, "session.user.settings.homeScreenSection4", "livetv")
    homeSection5 = chainLookupReturn(m.global, "session.user.settings.homeScreenSection5", "mylist")
    homeSection6 = chainLookupReturn(m.global, "session.user.settings.homeScreenSection6", "favorites")
    homeSection7 = chainLookupReturn(m.global, "session.user.settings.homeScreenSection7", "none")
    ' If user has no section preferences, use default settings
    if not userPreferences.doesExist("homesection0")
        userPreferences = {
            homesection0: homeSection0
            homesection1: homeSection1
            homesection2: homeSection2
            homesection3: homeSection3
            homesection4: homeSection4
            homesection5: homeSection5
            homesection6: homeSection6
            homesection7: homeSection7
        }
    end if
    for i = 0 to 7
        homeSectionKey = "homesection" + i.toStr()
        ' If home section doesn't exist, create it as a none row
        if not userPreferences.DoesExist(homeSectionKey)
            userPreferences.AddReplace(homeSectionKey, "none")
        end if
        rowType = LCase(userPreferences[homeSectionKey])
        ' Just in case we get invalid data
        if not isValid(rowType) then
            rowType = "none"
        end if
        ' Small size library item buttons - Currently unsupported, use small library titles
        if rowType = "librarybuttons"
            rowType = "smalllibrarytiles"
        end if
        ' None is the only section type allowed to have duplicates
        ' For all other types, only accept the 1st entry
        if inArray(rowTypes, rowType)
            set_user_setting(homeSectionKey, "none")
        else
            set_user_setting(homeSectionKey, rowType)
            if rowType <> "none"
                rowTypes.push(rowType)
            end if
        end if
    end for
end sub

' Empty the global user session array and reload defaults
sub session_user_Logout()
    session_Update("user", {
        Configuration: {}
        Policy: {}
        settings: {}
    })
    ' reload default user settings
    session_user_settings_SaveDefaults()
end sub
' Delete the user setting from the global session (m.global.session.user.settings)
sub session_user_settings_Delete(name as string)
    ' validate parameters
    if name = "" then
        return
    end if
    tmpSettingArray = m.global.session.user.settings
    ' update the temp user array
    tmpSettingArray.Delete(name)
    ' update global user session using the temp array
    session_user_Update("settings", tmpSettingArray)
end sub

' Read the user setting from the global session (m.global.session.user.settings)
function session_user_settings_Read(name as string) as dynamic
    ' validate parameters
    if name = "" then
        return invalid
    end if
    if m.global.session.user.settings[name] <> invalid
        return m.global.session.user.settings[name]
    else
        return invalid
    end if
end function

' retrieve all default user settings from Config Tree
sub session_user_settings_SaveDefaults()
    configTree = GetConfigTree()
    if configTree = invalid then
        return
    end if
    for each item in configTree
        if item.default <> invalid and item.settingName <> invalid
            session_user_settings_Save(item.settingName, item.default)
        else if item.children <> invalid and item.children.Count() > 0
            for each child in item.children
                if child.default <> invalid and child.settingName <> invalid
                    session_user_settings_Save(child.settingName, child.default)
                else if child.children <> invalid and child.children.Count() > 0
                    for each child in child.children
                        if child.default <> invalid and child.settingName <> invalid
                            session_user_settings_Save(child.settingName, child.default)
                        else if child.children <> invalid and child.children.Count() > 0
                            for each child in child.children
                                if child.default <> invalid and child.settingName <> invalid
                                    session_user_settings_Save(child.settingName, child.default)
                                else if child.children <> invalid and child.children.Count() > 0
                                    for each child in child.children
                                        if child.default <> invalid and child.settingName <> invalid
                                            session_user_settings_Save(child.settingName, child.default)
                                        else if child.children <> invalid and child.children.Count() > 0
                                            for each child in child.children
                                                if child.default <> invalid and child.settingName <> invalid
                                                    session_user_settings_Save(child.settingName, child.default)
                                                end if
                                            end for
                                        end if
                                    end for
                                end if
                            end for
                        end if
                    end for
                end if
            end for
        end if
    end for
    ' load globals
    session_user_settings_LoadGlobals()
    ' Reset server device name state
    session_user_SetServerDeviceName()
end sub

' Grab global vars from registry and overwrite defaults
sub session_user_settings_LoadGlobals()
    ' search main registry block for all keys that start with "global."
    jfRegistry = RegistryReadAll("WatchNexus")
    for each item in jfRegistry
        if Left(item, 7) = "global."
            session_user_settings_Save(item, get_setting(item))
        end if
    end for
end sub

' Saves the user setting to the global session.
' This also converts strings to boolean as necessary before saving to global session
sub session_user_settings_Save(name as string, value as string)
    if name = invalid or value = invalid then
        return
    end if
    tmpSettingArray = m.global.session.user.settings
    tmpSettingArray[name] = toBoolean(value)
    session_user_Update("settings", tmpSettingArray)
end sub
'//# sourceMappingURL=./session.brs.map