$serviceName = "WatchNexus"
$exePath = Join-Path $PSScriptRoot "WatchNexus.Core.dll"
Write-Host "Installing WatchNexus as Windows service..."
$env:ASPNETCORE_URLS = "http://0.0.0.0:8001"
sc.exe create $serviceName binPath= "dotnet $exePath" start= auto
sc.exe description $serviceName "WatchNexus Media Pipeline v2.7.3"
Write-Host "Service installed. Start with: sc.exe start $serviceName"
