# WatchNexus v2.7.3 - Windows Release

## Quick Start
```
start-watchnexus.bat
```
Open http://localhost:8001 in your browser.

## Requirements
- .NET 10 runtime for Windows x64
- Install: https://dotnet.microsoft.com/download/dotnet/10.0
