# WatchNexus v2.7.3-alpha - Windows Release

## Quick Start
```
start-watchnexus.bat
```
Open http://localhost:8001 in your browser.

## Pre-seeded Admin Accounts
- admin@watchnexus.ca / password123
- admin@friendlymedia.net / password123

## Requirements
- .NET 10 runtime for Windows x64
- Install: https://dotnet.microsoft.com/download/dotnet/10.0

## Install as Windows Service
Run PowerShell as Administrator:
```powershell
.\install-service.ps1
```
