@echo off
echo === WatchNexus v2.7.3-alpha ===
echo Starting on http://localhost:8001...
set ASPNETCORE_URLS=http://0.0.0.0:8001
dotnet WatchNexus.Core.dll
pause
